<?php 
	session_start();
?>
<?php
	if($_SERVER['REQUEST_METHOD']=="POST")
	{
		if(!empty(test_input($_POST['unameText']))&&!empty(test_input($_POST['passText'])))
		{
			$key="uname";
			$user=getUserByKeyValue($key,$_POST['unameText']);
			if(md5($_POST['passText'])==$user['password'])
			{
				if($user['type']=="admin")
				{
					setUserInformationToSession($user);
					$_SESSION['panel']="profile";
					RequestFrontController($user['type']."Dashboard");
				}
				else if($user['type']=="user")
				{
					setUserInformationToSession($user);
					RequestFrontController($user['type']."Dashboard");
				}
				else
				{
					setUserInformationToSession($user);
					RequestFrontController($user['type']."Dashboard");
				}
			}
			else
			{
				$_POST['error']="1";
			}
		
		}
		else
		{
			$_POST['error']="1";
		}
	}
	function RequestFrontController($controller)
	{
		header("Location: ?controller=".$controller);
	}
	function setUserInformationToSession($user)
	{
		$_SESSION['id']  =$user['id'];
		$_SESSION['fname']=$user['fname'];
		$_SESSION['lname']=$user['lname'];
		$_SESSION['uname']=$user['uname'];
		$_SESSION['email']  =$user['email'];
		$_SESSION['birthdate']=$user['birthdate'];
		$_SESSION['gender']=$user['gender'];
		$_SESSION['age']=$user['age'];
		$_SESSION['type']=$user['type'];
		$_SESSION['picture']=$user['picture'];
		$_SESSION['password']=$user['password'];
	}

?>
<html>
<head>
	<link rel="stylesheet" href="app/view/css/log.css"/>
	<script type="text/javascript">
	
	</script>
</head>
<body>
	<div id="login">
		<form method="post">
			<table>
				<tr>
					<td colspan="2">
						<h2>Sign In</h2>
					</td>
				</tr>
				<tr>
					<td colspan="2">
						<input type="text" id="username" name="unameText" placeholder="Enter Username" class="textInput" />
					</td>
				</tr>
				<tr>
					<td colspan="2">
						<input type="password" id="password" name="passText" placeholder="Enter password" class="textInput" />
					</td>
				</tr>
				<tr>
					<td align="left">
						<a href="?controller=register" id="createAccount">Don't Have Account ?</a>
					</td>
					<td align="right">
						<input type="submit" id="login-btn" value="Sign In" onclick="seeError()" />
					</td>
				</tr>
				<tr>
					<td colspan="2" align="center">
						<?php  if(isset( $_POST['error'])) { ?>
							
						   failed
						     <?php  }  ?>	  					
					</td>
				</tr>
			</table>		
		</form>
	</body>
<html>