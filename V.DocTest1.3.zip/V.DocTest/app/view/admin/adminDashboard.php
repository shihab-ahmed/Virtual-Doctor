<?php 
	session_start();
	if(!adminPanelCookieExist())
	{
		adminPanelCookieSet("profile");
	}

	if($_SESSION['success'])
	{
		$_SERVER['REQUEST_METHOD']="GET";
		$_SESSION['success']=0;
	}
	if($_SERVER['REQUEST_METHOD']=="POST")
	{
		$isValid = true;
		
		if (validateFirstName(test_input($_POST['fname'])))$fname = test_input($_POST['fname']);
		else
		{
			$isValid = false;
		}
		if (validateLastName(test_input($_POST['lname'])))$lname = test_input($_POST['lname']);
		else
		{
			$isValid = false;
		}
		if (validateUserName($_POST['uname']) && !GetNameTaken("uname",$_POST['uname']))$uname = test_input($_POST['uname']);
		else
		{
			$isValid = false;
		}
		if (validateEmail($_POST['email']))$email = test_input($_POST['email']);
		else
		{
			$isValid = false;
		}
		if (validateDate($_POST['date']))$date = test_input($_POST['date']);
		else
		{
			$isValid = false;
		}
		if (validateGender())$gender = test_input($_POST['gender']);
		else
		{
			$isValid = false;
		}
		if (validatePassword($_POST['pass'],$_POST['cpass']))$pass = md5(test_input($_POST['pass']));
		else
		{
			$isValid = false;

		}
		if (validateImage())$file = $_POST['target_file'];
		else
		{
			$isValid = false;
			echo "string";
		}
		$type = $_COOKIE['adminPanel'];
		if($type=="doctor")
		{
			if(isset($_POST['category']))$category = $_POST['category'];
			else
			{
				$isValid=false;
			}
			if(isset($_POST['experience']))
			{
				if(validateYearsOfExperience($_POST['experience']))
				{
					$experience = $_POST['experience'];
				}
				else
				{
					$isValid = false;
				}
			}
			else
			{
				$isValid=false;
			}
			if(isset($_POST['about']))$about = $_POST['about'];
			else
			{
				$isValid=false;
			}
		}

		if($isValid)
		{
			
			if($type=="doctor")
			{

				if(addDoctor($fname,$lname,$uname,$email,$pass,$date,$gender,$file,$type,$_POST['previousYear'],$category,$experience,$about))
				{
					echo "all ok";
					if(move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $file)) 
				    {
				        echo "your account has been created";
				       	$_SESSION['success']=1;
				       
				    }
				    else
				    {
				        //echo "Sorry, there was an error uploading your file.";
				    }
				}
				else
				{

				}
			}
			else
			{
				if(addUser($fname,$lname,$uname,$email,$pass,$date,$gender,$file,$type,$_POST['previousYear']))
				{
				  if(move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $file)) 
				    {
				        echo "your account has been created";
				        $_SESSION['success']=1;
				       // $_SERVER['REQUEST_METHOD']="GasdET";
				    }
				    else
				    {
				        //echo "Sorry, there was an error uploading your file.";
				    }
					
				}
				else
				{
					//echo "Account creation failed";
				}
			}
			
		}
		
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>User Dashboard</title>
		<script type="text/javascript">
			function panelController()
			{
				var value = "<?php echo adminPanelCookieGet();?>";
				if(value=="profile") includePanelProfile();
				if(value=="doctor") includePanelDoctor();
				if(value=="admin") includePanelAdmin();
				if(value=="userList") includePanelUserList();
				if(value=="report") includePanelReport();
				if(value=="changeProfile") includePanelChangeProfile();
			}
			function includeProfile()
			{
				var key = "uname";
				var value = "<?php echo $_SESSION['uname']?>";
				var task="1";
				var xmlhttp = new XMLHttpRequest();
		        xmlhttp.onreadystatechange = function()
		        {
		            if (this.readyState == 4 && this.status == 200)
		            {
		                var objArr=	JSON.parse(this.responseText);
		                
		                
		                document.getElementById("name").innerHTML=objArr[0].fname+" "+objArr[0].lname;
		                document.getElementById("email").innerHTML=objArr[0].email;
		                document.getElementById("birthdate").innerHTML=objArr[0].birthdate;
		                document.getElementById("age").innerHTML=objArr[0].age;
		                document.getElementById("gender").innerHTML=objArr[0].gender;
						

		            }
		        };
		        xmlhttp.open("GET","?js&request=getSingleUser&value="+value+"&key="+key, false);
		        xmlhttp.send();
			}
			function includePanelChangeProfile()
			{
				var xmlhttp = new XMLHttpRequest();
				document.getElementById("panel").innerHTML="";
		        xmlhttp.onreadystatechange = function()
		        {
		            if (this.readyState == 4 && this.status == 200)
		            {
		               document.getElementById("panel").innerHTML=(this.responseText);
		               
		            }
		        };
		        xmlhttp.open("GET","?js&request=changeProfileAdmin", false);
		        xmlhttp.send();
			}
			function includePanelProfile()
			{
				var xmlhttp = new XMLHttpRequest();
				document.getElementById("panel").innerHTML="";
		        xmlhttp.onreadystatechange = function()
		        {
		            if (this.readyState == 4 && this.status == 200)
		            {
		               document.getElementById("panel").innerHTML=(this.responseText);
		               	includeProfile();
		               
		            }
		        };
		        xmlhttp.open("GET","?js&request=addProfilePanel", false);
		        xmlhttp.send();
			}
			function includePanelDoctor()
			{
				var xmlhttp = new XMLHttpRequest();
				document.getElementById("panel").innerHTML="";
		        xmlhttp.onreadystatechange = function()
		        {
		            if (this.readyState == 4 && this.status == 200)
		            {
		                document.getElementById("panel").innerHTML=(this.responseText);
		               	
		               
		            }
		        };
		        xmlhttp.open("GET","?js&request=addDoctorPanel", false);
		        xmlhttp.send();
			}
			function includePanelAdmin()
			{
				var xmlhttp = new XMLHttpRequest();
				document.getElementById("panel").innerHTML="";
		        xmlhttp.onreadystatechange = function()
		        {
		            if (this.readyState == 4 && this.status == 200)
		            {
		                document.getElementById("panel").innerHTML=(this.responseText);
		                var notice="<?php echo $_SESSION['success']; ?>";
		                if(notice==1)alert("User added");
		            }
		        };
		        xmlhttp.open("GET","?js&request=addAdminPanel", false);
		        xmlhttp.send();
			}
			function includePanelUserList()
			{
				var xmlhttp = new XMLHttpRequest();
				document.getElementById("panel").innerHTML="";
		        xmlhttp.onreadystatechange = function()
		        {
		            if (this.readyState == 4 && this.status == 200)
		            {
		                document.getElementById("panel").innerHTML=(this.responseText);
		                userList("","");
		            }
		        };
		        xmlhttp.open("GET","?js&request=userListPanel", false);
		        xmlhttp.send();
			}
			function userList(key,value)
			{
				var xmlhttp = new XMLHttpRequest();
				xmlhttp.onreadystatechange = function()
		        {
		            if (this.readyState == 4 && this.status == 200)
		            {
		            	document.getElementById("list").innerHTML="";
		               	var objArr=	JSON.parse(this.responseText);
						
				        for(var x in objArr)
						{
							
							var tr = document.createElement("tr");

							var tdName = document.createElement("td");
							var tdEmail = document.createElement("td");
							var tdAge = document.createElement("td");
							var tdGender = document.createElement("td");
							var tdType = document.createElement("td");
							var tdDel = document.createElement("td");

							var btn = document.createElement("input"); 
							btn.type="button";
							btn.value="delete";
							btn.id=objArr[x].uname;
							btn.name=objArr[x].type;
							btn.class=objArr[x].picture;
							btn.onclick = function(){DeleteUser(this.id,this.name,this.class)};
					

							tdName.innerHTML= objArr[x].fname+" "+objArr[x].lname;
							tdEmail.innerHTML= objArr[x].email;
							tdAge.innerHTML= objArr[x].age;
							tdGender.innerHTML= objArr[x].gender;
							tdType.innerHTML= objArr[x].type;
							tdDel.appendChild(btn);	

							tr.appendChild(tdName);
							tr.appendChild(tdEmail);
							tr.appendChild(tdAge);
							tr.appendChild(tdGender);
							tr.appendChild(tdType);
							tr.appendChild(tdDel);

							document.getElementById("list").appendChild(tr);
						}
		               
		            }
		        };
		        if(value=="")
		        {
		        	xmlhttp.open("GET","?js&request=getAllUser", true);
		        }
		        else
		        {
		        	xmlhttp.open("GET","?js&request=getUserUsingLike&key="+key+"&value="+value, true);
		        }
		       
		        xmlhttp.send();
			}
			function DeleteUser(value,type,pic)
			{
				var key="uname";
			    var xmlhttp = new XMLHttpRequest();
				xmlhttp.onreadystatechange = function() 
			 	{
		            if (this.readyState == 4 && this.status == 200) 
		            {
		            	userList("","");
		            }               
		          
			    };
				xmlhttp.open("GET","?js&request=deleteUser&key="+key+"&value="+value+"&type="+type+"&pic="+pic, false);
		        xmlhttp.send();
			}
			function searchUser()
			{
				var value=document.getElementById("value").value;
				var key=document.getElementById("key").value;
				if(value=="")
				{
					userList("","");
				}
				else
				{
					userList(key,value);
				}
			}
			function includePanelReport()
			{
				var xmlhttp = new XMLHttpRequest();
				document.getElementById("panel").innerHTML="";
		        xmlhttp.onreadystatechange = function()
		        {
		            if (this.readyState == 4 && this.status == 200)
		            {
		                document.getElementById("panel").innerHTML=(this.responseText);
		            }
		        };
		        xmlhttp.open("GET","?js&request=reportPanel", false);
		        xmlhttp.send();
			}
			function clearData()
			{
				document.getElementById('form').reset();
			}
			function validateUser()
			{
				var isValid=true;
				var fname=document.getElementById("fname").value;
				if(fname=="")
				{
					isValid=false;
					var abbr = document.createElement("abbr");
					abbr.title="only alphabet[a-z]"
					abbr.innerHTML="*";
					document.getElementById("fnameWarning").innerHTML="";
					document.getElementById("fnameWarning").appendChild(abbr);
				}
				else
				{
					for (var i = 0; i < fname.length; i++) 
					{
						if( fname.charAt(i).charCodeAt(0)<65 || fname.charAt(i).charCodeAt(0)>122)
						{
							isValid=false;
							var abbr = document.createElement("abbr");
							abbr.title="only alphabet[a-z]"
							abbr.innerHTML="*";
							document.getElementById("fnameWarning").innerHTML="";
							document.getElementById("fnameWarning").appendChild(abbr);
							break;
						}
					}
				}

				if(isValid)
				{
					document.getElementById("fnameWarning").innerHTML="";
				}
				var lname=document.getElementById("lname").value;
				if(lname=="")
				{
					isValid=false;
					var abbr = document.createElement("abbr");
					abbr.title="only alphabet[a-z]"
					abbr.innerHTML="*";
					document.getElementById("lnameWarning").innerHTML="";
					document.getElementById("lnameWarning").appendChild(abbr);
				}
				else
				{
					for (var i = 0; i < lname.length; i++) 
					{
						if( lname.charAt(i).charCodeAt(0)<65 || lname.charAt(i).charCodeAt(0)>122)
						{
							isValid=false;
							var abbr = document.createElement("abbr");
							abbr.title="only alphabet[a-z]"
							abbr.innerHTML="*";
							document.getElementById("lnameWarning").innerHTML="";
							document.getElementById("lnameWarning").appendChild(abbr);
							break;
						}
					}
				}

				if(isValid)
				{
					document.getElementById("lnameWarning").innerHTML="";
				}
				var uname=document.getElementById("uname").value;
				if(uname=="")
				{
					isValid=false;
					var abbr = document.createElement("abbr");
					abbr.title="First letter alphabet[a-z] and Unique name"
					abbr.innerHTML="*";
					document.getElementById("unameWarning").innerHTML="";
					document.getElementById("unameWarning").appendChild(abbr);
				}
				else
				{
					if( uname.charAt(0).charCodeAt(0)<65 || uname.charAt(0).charCodeAt(0)>122)
					{
						isValid=false;
						var abbr = document.createElement("abbr");
						abbr.title="only alphabet[a-z]"
						abbr.innerHTML="*";
						document.getElementById("unameWarning").innerHTML="";
						document.getElementById("unameWarning").appendChild(abbr);
						
					}
				}
				if(isValid)
				{
					document.getElementById("unameWarning").innerHTML="";
				}
				var email=document.getElementById("email").value;
				if(email=="")
				{
					isValid=false;
					var abbr = document.createElement("abbr");
					abbr.title="ex@something.com"
					abbr.innerHTML="*";
					document.getElementById("emailWarning").innerHTML="";
					document.getElementById("emailWarning").appendChild(abbr);
				}
				if(isValid)
				{
					document.getElementById("emailWarning").innerHTML="";
				}
				var date=document.getElementById("date").value;
				if(date=="")
				{
					isValid=false;
					var abbr = document.createElement("abbr");
					abbr.title="required"
					abbr.innerHTML="*";
					document.getElementById("dateWarning").innerHTML="";
					document.getElementById("dateWarning").appendChild(abbr);
				}
				if(isValid)
				{
					document.getElementById("dateWarning").innerHTML="";
				}
				var radios = document.getElementsByName('gender');
				var gender="";
				for (var i = 0, length = radios.length; i < length; i++) 
				{
				    if (radios[i].checked) 
				    {
				        gender=(radios[i].value);
				        break;
				    }
				}
				if(gender=="")
				{
					isValid=false;
					var abbr = document.createElement("abbr");
					abbr.title="required"
					abbr.innerHTML="*";
					document.getElementById("genderWarning").innerHTML="";
					document.getElementById("genderWarning").appendChild(abbr);
				}
				if(isValid)
				{
					document.getElementById("genderWarning").innerHTML="";
				}
				var pass=document.getElementById("pass").value;
				if(pass=="")
				{
					isValid=false;
					var abbr = document.createElement("abbr");
					abbr.title="required(<10 word)"
					abbr.innerHTML="*";
					document.getElementById("passWarning").innerHTML="";
					document.getElementById("passWarning").appendChild(abbr);
				}
				if(isValid)
				{
					document.getElementById("passWarning").innerHTML="";
				}
				var cpass=document.getElementById("cpass").value;
				if(cpass=="")
				{
					isValid=false;
					var abbr = document.createElement("abbr");
					abbr.title="required(<10 word)"
					abbr.innerHTML="*";
					document.getElementById("cpassWarning").innerHTML="";
					document.getElementById("cpassWarning").appendChild(abbr);
				}
				if(isValid)
				{
					document.getElementById("cpassWarning").innerHTML="";
				}
				var fileToUpload = document.getElementById("fileToUpload");
				var file = fileToUpload.files[0];

				if(file!=null)
				{
					var fileName=file.name;
					var fileSize=file.size;
				}
				else
				{
					isValid=false;
					var abbr = document.createElement("abbr");
					abbr.title="only alphabet[a-z]"
					abbr.innerHTML="*";
					document.getElementById("fileWarning").innerHTML="";
					document.getElementById("fileWarning").appendChild(abbr);
				}
				if(isValid)
				{
					document.getElementById("fileWarning").innerHTML="";
					if(cpass!=pass)
					{
						isValid=false;
						document.getElementById("status").innerHTML="";
						document.getElementById("status").innerHTML="Confirm pass doesnt match";
					}
				}
				var value="<?php echo adminPanelCookieGet();?>";

				if(isValid)
				{
					var form=document.getElementById("form");
					document.getElementById("status").innerHTML="";
					document.getElementById("status").innerHTML="Account Created";
					form.submit();
				}

			}
			function SeeIfNameTaken()
			{
				var xmlhttp = new XMLHttpRequest();
				xmlhttp.onreadystatechange = function()
		        {
		            if (this.readyState == 4 && this.status == 200)
		            {
		                var objArr=	(this.responseText);
		                document.getElementById("unameWarning").innerHTML=objArr;
		          
		            }
		        };
		        var uname=document.getElementById("uname").value;
		        xmlhttp.open("GET","?js&request=nameTaken&uname="+uname, true);
		        xmlhttp.send();
			}
		</script>
</head>
<body onload="panelController()">
	<table border="1">
		<tbody>
			<tr>
				<td>
					<table>
						<tbody>
							<tr>
								<td>
									<div onclick="includePanelProfile()">
										<img src="" id="profilePic">
										<p id="userName"></p>
										<script>
										document.getElementById("userName").innerHTML="<?php echo $_SESSION['fname']." ".$_SESSION['lname']?>";
										document.getElementById("profilePic").src="<?php echo $_SESSION['picture']?>";
										</script>
									</div>
								</td>
							</tr>

							<tr>
								<td>
									<ul>
										<li onclick="includePanelDoctor()">Add Doctor</li>
										<li onclick="includePanelAdmin()">Add Admin</li>
										<li onclick="includePanelUserList()">Show User</li>
										<li onclick="includePanelReport()">Report</li>
										<li >Logout</li>
									</ul>
								</td>
							</tr>
						</tbody>
					</table>
				</td>
				<td id="panel">					
				</td>
			</tr>
		</tbody>
	</table>
</body>
</html>
