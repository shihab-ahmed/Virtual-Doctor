<form method="post" enctype="multipart/form-data" id="form">
	<table>
		<tbody>
			<tr>
				<td>
					First Name :
				</td>
				<td>
					<input type="text" name="fname" id="fname">
				</td>
				<td id="fnameWarning">
							
				</td>
			<tr>
				<td>
					Last Name :
				</td>
				<td>
					<input type="text" name="lname" id="lname">
				</td>
				<td id="lnameWarning">
							
				</td>
			</tr>
			<tr>
				<td>
					User Name :
				</td>
				<td>
					<input type="text" name="uname" id="uname" onkeydown="SeeIfNameTaken()">
				</td>
				<td id="unameWarning">
							
				</td>
			</tr>
			<tr>
				<td>
					Email :
				</td>
				<td>
					<input type="Email" name="email" id="email">
				</td>
				<td id="emailWarning">
							
				</td>
			</tr>
			<tr>
				<td>
					Date :
				</td>
				<td>
					<input type="date" name="date" id="date">
				</td>
				<td id="dateWarning">
							
				</td>
			</tr>
			<tr>
				<td>
					Gender :
				</td>
				<td>
					<input type="radio" name="gender" value="male" checked=""> Male
					<input type="radio" name="gender" value="female">Female
				</td>
				<td id="genderWarning">
							
				</td>
			</tr>
			<tr>
				<td>
					Password :
				</td>
				<td>
					<input type="Password" name="pass" id="pass">
				</td>
				<td id="passWarning">
							
				</td>
			</tr>
			<tr>
				<td>
					Confirm Password :
				</td>
				<td>
					<input type="Password" name="cpass" id="cpass">
				</td>
				<td id="cpassWarning">
							
				</td>
			</tr>
			<tr>
				<td>
					Profile Picture :
				</td>
				<td>
					 <input type="file" name="fileToUpload" id="fileToUpload">
				</td>
				<td id="fileWarning">
							
				</td>
			</tr>
			<tr>
				<td>
				</td>
				<td >
					<input type="button" onclick="validateUser()" value="Sign Up" name="signUp" />
				</td>
			</tr>
				<tr>
					<td>
						
					</td>
					<td id="status">
										       
					</td>
				</tr>
		</tbody>
	</table>
</form>