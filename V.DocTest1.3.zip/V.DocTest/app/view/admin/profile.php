<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<p id="name">a</p>
	<p id="email">a</p>
	<p id="birthdate">a</p>
	<p id="age">a</p>
	<p id="gender">a</p>
	<input type="button" value="Change" onclick="includePanelChangeProfile()" name="">
</body>
</html>