<form method="post"  enctype="multipart/form-data">
	<fieldset>
		<legend>Edit Profile</legend>
		<table>
			<tbody>
				<tr>
					<td>
						First Name :
					</td>
					<td>
						<input type="text" name="fname">
					</td>
				</tr>
				<tr>
					<td>
						Last Name :
					</td>
					<td>
						<input type="text" name="lname">
					</td>
				</tr>
				<tr>
					<td>
						Email :
					</td>
					<td>
						<input type="Email" name="email">
					</td>
				</tr>
				<tr>
					<td>
						Date(yyyy-mm-dd) :
					</td>
					<td>
						<input type="text" name="date">
					</td>
				</tr>
				<tr>
					<td>
						Gender :
					</td>
					<td>
						<input type="radio" name="gender" value="male"> Male
						<input type="radio" name="gender" value="female">Female
					</td>
				</tr>
				<tr>
					<td>
						Profile Picture :
					</td>
					<td>
						 <input type="file" name="fileToUpload" id="fileToUpload">
				</tr>
				<tr>
					<td>									
					</td>
					<td >
						<input type="button" value="Change"/>
					</td>
				</tr>
			</tbody>
		</table>
	</fieldset>
</form>
</td>
</tr>
<tr>
<td>
<form  method="post">
	<fieldset>
		<legend>Change Password</legend>
		<table>
			<tbody>
				<tr>
					<td>
						Current Password :
					</td>
					<td>
						<input type="Password" name="opass">
					</td>
				</tr>
				<tr>
					<td>
						Password :
					</td>
					<td>
						<input type="Password" name="pass">
					</td>
				</tr>
				<tr>
					<td>
						Confirm Password :
					</td>
					<td>
						<input type="Password" name="cpass">
					</td>
				</tr>
				<tr>
					<td>									
					</td>
					<td >
						<input type="submit" value="Change"/>
					</td>
				</tr>
			</tbody>
		</table>
	</fieldset>
</form>	