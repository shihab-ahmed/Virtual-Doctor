<?php 
	require_once($_REQUEST['root']."/lib/data_access_helper.php");
	function getUserByKeyValueFromDb($key,$value)
	{
		
		$query = "SELECT `id`, `fname`, `lname`, `uname`, `email`, `password`, `birthdate`, `gender`, `age`, `picture`, `type` FROM `user` WHERE $key='$value'";  
		$result = executeQuery($query);	
		return $result;
	}
	function getUserByKeyValueUsingLikeFromDb($key,$value)
	{
		
		$query="SELECT id,fname,lname,uname,email,password,birthdate,gender,age,picture,type,picture FROM `user` WHERE $key LIKE '$value%'";  
		$result = executeQuery($query);	
		return $result;
	}
	function getAllUserFromDb()
	{
		$query="SELECT id,fname,lname,uname,email,password,birthdate,gender,age,picture,type FROM `user`";
		$result = executeQuery($query);	
		return $result;
	}
?>

