
<table>
	<tbody>
		<tr>
			<td>
				First Name :
			</td>
			<td>
				<input type="text" name="fname" id="fname">
			</td>
		<tr>
			<td>
				Last Name :
			</td>
			<td>
				<input type="text" name="lname" id="lname">
			</td>
		</tr>
		<tr>
			<td>
				User Name :
			</td>
			<td>
				<input type="text" name="uname" id="uname">
			</td>
		</tr>
		<tr>
			<td>
				Email :
			</td>
			<td>
				<input type="Email" name="email" id="email">
			</td>
		</tr>
		<tr>
			<td>
				Date :
			</td>
			<td>
				<input type="date" name="date" id="date">
			</td>
		</tr>
		<tr>
			<td>
				Gender :
			</td>
			<td>
				<input type="radio" name="gender" value="male" checked=""> Male
				<input type="radio" name="gender" value="female">Female
			</td>
		</tr>
		<tr>
			<td>
				Password :
			</td>
			<td>
				<input type="Password" name="pass" id="pass">
			</td>
		</tr>
		<tr>
			<td>
				Confirm Password :
			</td>
			<td>
				<input type="Password" name="cpass" id="cpass">
			</td>
		</tr>
		<tr>
			<td>
				Profile Picture :
			</td>
			<td>
				 <input type="file" name="fileToUpload" id="fileToUpload">
			</td>
		</tr>
		<tr>
			<td>
			</td>
			<td >
				<input type="button" onclick="requestToAddAdmin()" value="Sign Up" name="signUp" />
			</td>
		</tr>
	</tbody>
</table>	