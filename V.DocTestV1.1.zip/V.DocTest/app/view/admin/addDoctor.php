<?php
	
?>

<form method="post"  enctype="multipart/form-data">
	<table>
		<tbody>
			<tr>
				<td>
					First Name :
				</td>
				<td>
					<input type="text" name="fname">
				</td>
			<tr>
				<td>
					Last Name :
				</td>
				<td>
					<input type="text" name="lname">
				</td>
			</tr>
			<tr>
				<td>
					User Name :
				</td>
				<td>
					<input type="text" name="uname">
				</td>
			</tr>
			<tr>
				<td>
					Email :
				</td>
				<td>
					<input type="Email" name="email">
				</td>
			</tr>
			<tr>
				<td>
					Date:
				</td>
				<td>
					<input type="date" name="date">
				</td>
			</tr>
			<tr>
				<td>
					Gender :
				</td>
				<td>
					<input type="radio" name="gender" value="male"> Male
					<input type="radio" name="gender" value="female">Female
				</td>
			</tr>
			<tr>
				<td>
					Password :
				</td>
				<td>
					<input type="Password" name="pass">
				</td>
			</tr>
			<tr>
				<td>
					Confirm Password :
				</td>
				<td>
					<input type="Password" name="cpass">
				</td>
			</tr>
			<tr>
				<td>
					Specialist :
				</td>
				<td>
					<select id="category" name="category">
						<option>Audiologist</option>
						<option>Allergist</option>
						<option>Dentist</option>
						<option>Endocrinologists</option>
						<option>Gynecologist</option>
						<option>Neonatologist</option>
						<option>Neurologist</option>
						<option>Surgeon</option>
					</select>

				</td>
			</tr>
			<tr>
				<td>
					Experience(Year) :
				</td>
				<td>
					<input type="text" name="experience">
				</td>
			</tr>
			<tr>
				<td>
					About :
				</td>
				<td>
					<input type="text" name="about">
				</td>
			</tr>
			<tr>
				<td>
					Profile Picture :
				</td>
				<td>
					 <input type="file" name="fileToUpload" id="fileToUpload">
				</td>
			</tr>
			<tr>
				<td>
				</td>
				<td >
					<input type="submit" value="Sign Up" name="signUp" />
				</td>
			</tr>
		</tbody>
	</table>
</form>			