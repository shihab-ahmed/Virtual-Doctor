<?php 
	session_start();
	if(!adminPanelCookieExist())
	{
		adminPanelCookieSet("profile");
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>User Dashboard</title>
		<script type="text/javascript">
			function panelController()
			{
				var value = "<?php echo adminPanelCookieGet();?>";
				if(value=="profile") includeProfile();
				if(value=="doctor") includePanelDoctor();
				if(value=="admin") includePanelAdmin();
				if(value=="userList") includePanelUserList();
				if(value=="report") includePanelReport();
			}
			function includeProfile()
			{
				var key = "uname";
				var value = "<?php echo $_SESSION['uname']?>";
				var task="1";
				var xmlhttp = new XMLHttpRequest();
				document.getElementById("panel").innerHTML="";
		        xmlhttp.onreadystatechange = function()
		        {
		            if (this.readyState == 4 && this.status == 200)
		            {
		                var objArr=	JSON.parse(this.responseText);

		                var pName= document.createElement("p");
		                var pEmail= document.createElement("p");
		                var pBirthdate= document.createElement("p");
		                var pGender= document.createElement("p");
		                var pAge= document.createElement("p");
		                
		                pName.innerHTML=objArr[0].fname+" "+objArr[0].lname;
		                pEmail.innerHTML=objArr[0].email;
		                pBirthdate.innerHTML=objArr[0].birthdate;
		                pAge.innerHTML=objArr[0].age;
		                pGender.innerHTML=objArr[0].gender;
						
						var panel = document.getElementById("panel");
						panel.appendChild(pName);
						panel.appendChild(pEmail);
						panel.appendChild(pBirthdate);
						panel.appendChild(pAge);
						panel.appendChild(pGender);

		            }
		        };
		        xmlhttp.open("GET","?js&request=getSingleUser&value="+value+"&key="+key, false);
		        xmlhttp.send();
			}
			function includePanelDoctor()
			{
				var xmlhttp = new XMLHttpRequest();
				document.getElementById("panel").innerHTML="";
		        xmlhttp.onreadystatechange = function()
		        {
		            if (this.readyState == 4 && this.status == 200)
		            {
		                document.getElementById("panel").innerHTML=(this.responseText);
		            }
		        };
		        xmlhttp.open("GET","?js&request=addDoctorPanel", false);
		        xmlhttp.send();
			}
			function includePanelAdmin()
			{
				var xmlhttp = new XMLHttpRequest();
				document.getElementById("panel").innerHTML="";
		        xmlhttp.onreadystatechange = function()
		        {
		            if (this.readyState == 4 && this.status == 200)
		            {
		                document.getElementById("panel").innerHTML=(this.responseText);
		            }
		        };
		        xmlhttp.open("GET","?js&request=addAdminPanel", false);
		        xmlhttp.send();
			}
			function includePanelUserList()
			{
				var xmlhttp = new XMLHttpRequest();
				document.getElementById("panel").innerHTML="";
		        xmlhttp.onreadystatechange = function()
		        {
		            if (this.readyState == 4 && this.status == 200)
		            {
		                document.getElementById("panel").innerHTML=(this.responseText);
		            }
		        };
		        xmlhttp.open("GET","?js&request=userListPanel", false);
		        xmlhttp.send();
			}
			function includePanelReport()
			{
				var xmlhttp = new XMLHttpRequest();
				document.getElementById("panel").innerHTML="";
		        xmlhttp.onreadystatechange = function()
		        {
		            if (this.readyState == 4 && this.status == 200)
		            {
		                document.getElementById("panel").innerHTML=(this.responseText);
		            }
		        };
		        xmlhttp.open("GET","?js&request=reportPanel", false);
		        xmlhttp.send();
			}
		</script>
</head>
<body onload="panelController()">
	<table border="1">
		<tbody>
			<tr>
				<td>
					<table>
						<tbody>
							<tr>
								<td>
									<div onclick="includeProfile()">
										<img src="" id="profilePic">
										<p id="userName"></p>
										<script>
										document.getElementById("userName").innerHTML="<?php echo $_SESSION['fname']." ".$_SESSION['lname']?>";
										document.getElementById("profilePic").src="<?php echo $_SESSION['picture']?>";
										</script>
									</div>
								</td>
							</tr>

							<tr>
								<td>
									<ul>
										<li onclick="includePanelDoctor()">Add Doctor</li>
										<li onclick="includePanelAdmin()">Add Admin</li>
										<li onclick="includePanelUserList()">Show User</li>
										<li onclick="includePanelReport()">Report</li>
										<li >Logout</li>
									</ul>
								</td>
							</tr>
						</tbody>
					</table>
				</td>
				<td id="panel">					
				</td>
			</tr>
		</tbody>
	</table>
</body>
</html>
