<table>
	<tr>
		<td>
			<input type="text" id="value" placeholder="search" onkeydown="searchUser()">
			<select id="key">
				<option value="uname">User Name</option>
				<option value="fname">First Name</option>
				<option value="lname">Last Name</option>
			</select>
		</td>
	</tr>
	<tr>
		<table id="list">
			
		</table>
	</tr>
</table>