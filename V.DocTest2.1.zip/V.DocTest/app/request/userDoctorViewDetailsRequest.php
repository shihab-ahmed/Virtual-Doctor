<?php
	define('APP_ROOT', "$_SERVER[DOCUMENT_ROOT]/V.DocTest");
	$Root=APP_ROOT;
	require_once(APP_ROOT."/core/core_service.php");
?>
<?php 
	if(isset($_REQUEST['task']))
	{
		if($_REQUEST['task']==1)
		{
			showUserByKeyValue($_REQUEST['key'],$_REQUEST['value']);
		}
		if($_REQUEST['task']==2)
		{
			getDoctorInformation($_REQUEST['key'],$_REQUEST['value']);
		}
		if($_REQUEST['task']==3)
		{
			sendContactRequest($_REQUEST['docname'],$_REQUEST['uname']);
		}
	}
	function showUserByKeyValue($key,$value)
	{
		echo getAllUserUsingLike($key,$value);
	}
	function getDoctorInformation($key,$value)
	{
		//echo $value;
		echo getDoctorDetailsUsingKeyValue($key,$value);
	}
	function sendContactRequest($docname,$uname)
	{
		$status = "pending";
		$isSeenUser = "0";
		$isSeen = "0"; 

		if(sendContactRequestToDoctor($uname,$docname,$status,$isSeenUser,$isSeen))
		{
			echo "Request sent";
		}
		else
		{
			echo "failed to send request";
		}
	}
 ?>