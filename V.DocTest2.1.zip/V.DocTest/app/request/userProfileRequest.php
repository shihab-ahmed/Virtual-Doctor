<?php
	define('APP_ROOT', "$_SERVER[DOCUMENT_ROOT]/V.DocTest");
	$Root=APP_ROOT;
	require_once(APP_ROOT."/core/core_service.php");
?>
<?php
	if(isset($_REQUEST['task']))
	{
		if($_REQUEST['task']==1)
		{
			getProfile();
		}
		if($_REQUEST['task']==2)
		{
			getContact();
		}
		if($_REQUEST['task']==3)
		{
			getUserByKey();
		}
		if($_REQUEST['task']==4)
		{
			getAppointment();
		}
		if($_REQUEST['task']==5)
		{
			getPrescription();
		}
	}
	function getProfile()
	{
		//echo "string";
		echo getUserByKeyValueJSON($_REQUEST['key'],$_REQUEST['value']);
	}
	function getContact()
	{
		echo getContactListUsingDoubleKey($_REQUEST['key'],$_REQUEST['value'],$_REQUEST['key2'],$_REQUEST['value2']);
	}
	function getUserByKey()
	{
		echo getUserByKeyValueJSON($_REQUEST['key'],$_REQUEST['value']);
	}
	function getAppointment()
	{
		echo getAppointmentListUsingDoubleKey($_REQUEST['key'],$_REQUEST['value'],$_REQUEST['key2'],$_REQUEST['value2']);
	}
	function getPrescription()
	{
		echo getPrescriptionList($_REQUEST['key'],$_REQUEST['value']);
	}
	
	
 ?>