<?php
	define('APP_ROOT', "$_SERVER[DOCUMENT_ROOT]/V.DocTest");
	$Root=APP_ROOT;
	require_once(APP_ROOT."/core/core_service.php");
?>
<?php 
	echo getUserByKeyValueJSON($_REQUEST['key'],$_REQUEST['value'])
 ?>