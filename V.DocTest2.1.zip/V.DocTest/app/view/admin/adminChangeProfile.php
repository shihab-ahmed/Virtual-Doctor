<?php 
	session_start();
 ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<script type="text/javascript">
		function includeProfile()
		{
			var key = "uname";
			var value = "<?php echo $_SESSION['uname']?>";
			var task="1";
			var xmlhttp = new XMLHttpRequest();
	        xmlhttp.onreadystatechange = function()
	        {
	            if (this.readyState == 4 && this.status == 200)
	            {
	            	//alert(this.responseText);
	                var objArr=	JSON.parse(this.responseText);
	                document.getElementById("userName").innerHTML=objArr[0].fname+" "+objArr[0].lname;
	                //document.getElementById("profilePic").src=objArr[0].picture;
					
	            }
	        };
	        xmlhttp.open("GET","../../request/adminProfileRequest?value="+value+"&key="+key, false);
	        xmlhttp.send();
		}
		function gotoProfile()
		{
			window.location.href="adminDashboard.php";
		}
		function gotoChangeProfile()
		{
			window.location.href="adminChangeProfile.php";
		}
		function gotoAddAdmin()
		{
			window.location.href="addAdminDashboard.php";
		}
		function gotoAddDoctor()
		{
			window.location.href="addDoctorDashboard.php";
		}
		function gotoShowUser()
		{
			window.location.href="showUser.php";
		}
		function gotoReportUser()
		{
			window.location.href="ReportUser.php";
		}
		function gotoLogout()
		{
			window.location.href="../logout.php";
		}
	</script>
</head>
<body onload="includeProfile()">
	<table border="1">
		<tbody>
			<tr>
				<td>
					<table>
						<tbody>
							<tr>
								<td>
									<div onclick="gotoProfile()">
										<img src="" id="profilePic">
										<p id="userName"></p>
										</script>
									</div>
								</td>
							</tr>

							<tr>
								<td>
									<ul>
										<li onclick="gotoAddDoctor()">Add Doctor</li>
										<li onclick="gotoAddAdmin()">Add Admin</li>
										<li onclick="gotoShowUser()">Show User</li>
										<li onclick="gotoReportUser()">Report</li>
										<li onclick="gotoLogout()">Logout</li>
									</ul>
								</td>
							</tr>
						</tbody>
					</table>
				</td>
				<td id="panel">	
					<table>
						<tr>
							<td>
								<form action="../../request/adminProfileChangeRequest.php" method="post"  enctype="multipart/form-data">
									<fieldset>
										<legend>Edit Profile</legend>
										<table>
											<tbody>
												<tr>
													<td>
														First Name :
													</td>
													<td>
														<input type="text" name="fname" id="fname">
													</td>
													<td id="fnameWarning">
														
													</td>
												</tr>
												<tr>
													<td>
														Last Name :
													</td>
													<td>
														<input type="text" name="lname" id="lname">
													</td>
													<td id="lnameWarning">
														
													</td>
												</tr>
												<tr>
												<td>
													Email :
												</td>
												<td>
													<input type="Email" name="email" id="email">
												</td>
												<td id="emailWarning">
															
												</td>
											</tr>
											<tr>
												<td>
													Date :
												</td>
												<td>
													<input type="date" name="date" id="date">
												</td>
												<td id="dateWarning">
															
												</td>
											</tr>
											<tr>
												<td>
													Gender :
												</td>
												<td>
													<input type="radio" name="gender" value="male" checked=""> Male
													<input type="radio" name="gender" value="female">Female
												</td>
												<td id="genderWarning">
															
												</td>
											</tr>
												<tr>
												<td>
													Profile Picture :
												</td>
												<td>
													 <input type="file" name="fileToUpload" id="fileToUpload">
												</td>
												<td id="fileWarning">
															
												</td>
											</tr>
												<tr>
													<td>									
													</td>
													<td >
														<input type="submit" value="Change"/>
													</td>
												</tr>
											</tbody>
										</table>
									</fieldset>
								</form>
								</td>
								</tr>
								<tr>
								<td>
								<form action="../../request/adminPasswordChangeRequest.php" method="post">
									<fieldset>
										<legend>Change Password</legend>
										<table>
											<tbody>
												<tr>
													<td>
														Current Password :
													</td>
													<td>
														<input type="Password" name="opass">
													</td>
												</tr>
												<tr>
													<td>
														Password :
													</td>
													<td>
														<input type="Password" name="pass">
													</td>
												</tr>
												<tr>
													<td>
														Confirm Password :
													</td>
													<td>
														<input type="Password" name="cpass">
													</td>
												</tr>
												<tr>
													<td>									
													</td>
													<td >
														<input type="submit" value="Change"/>
													</td>
												</tr>
											</tbody>
										</table>
									</fieldset>
								</form>		
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</tbody>
	</table>
</body>
</html>

