<?php 
	define('APP_ROOT', "$_SERVER[DOCUMENT_ROOT]/V.DocTest");

	
	if(isset($_GET['controller']))
	{
		//ChangeController($_REQEUST['controller']);
	}
	else
	{
		
	}
	ChangeController("");
	function ChangeController($Controller)
	{
		switch($Controller)
		{
			case "adminDashboard":
				include_once("/app/view/admin/adminDashboard.php");
				break;
				
			case "user":
				echo "user";
				break;
				
			case "register":
			echo "string";
				include_once("app/view/reg.php");
				break;

			default:
				header("Location: app/view/login.php?root=".APP_ROOT);				
				break;
		}
	}
	

?>