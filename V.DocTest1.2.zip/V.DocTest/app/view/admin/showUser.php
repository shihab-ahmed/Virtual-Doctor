<table>
	<tr>
		<td>
			<input type="text" id="value" placeholder="search" onkeyup="searchUser()">
			<select id="key">
				<option value="fname">First Name</option>
				<option value="lname">Last Name</option>
				<option value="type">Type</option>
				<option value="gender">Gender</option>
			</select>
		</td>
	</tr>
	<tr>
		<table id="list">
			
		</table>
	</tr>
</table>