<?php
	define('APP_ROOT', "$_SERVER[DOCUMENT_ROOT]/V.DocTest");
	$Root=APP_ROOT;
	require_once(APP_ROOT."/core/core_service.php");
	if(isset($_REQUEST['js']))
	{
		if(isset($_REQUEST['request']))
		{	
			if(($_REQUEST['request'])=="nameTaken")
			{	
				if(GetNameTaken("uname",$_REQUEST['uname']))
				{
					echo "Name Taken";
				}
				else
				{
					echo "";
				}
				
			}
			else if(($_REQUEST['request'])=="getAllUser")
			{	
				echo getAllUser();
			}
			else if(($_REQUEST['request'])=="getUserUsingLike")
			{	
				echo getAllUserUsingLike(($_REQUEST['key']),($_REQUEST['value']));
			}
			else if(($_REQUEST['request'])=="deleteUser")
			{	
				echo DeleteUserByKeyValue(($_REQUEST['key']),($_REQUEST['value']),($_REQUEST['type']),($_REQUEST['pic']));
			}
			else if(($_REQUEST['request'])=="getSingleUser")
			{	
				echo getUserByKeyValueJSON($_REQUEST['key'],$_REQUEST['value']);
			}

			else if(($_REQUEST['request'])=="addDoctorPanel")
			{	
				adminPanelCookieUpdate("doctor");
				include_once("/app/view/admin/addDoctor.php");
			}
			else if(($_REQUEST['request'])=="addAdminPanel")
			{	
				adminPanelCookieUpdate("admin");
				include_once("/app/view/admin/addAdmin.php");
			}
			else if(($_REQUEST['request'])=="userListPanel")
			{	
				adminPanelCookieUpdate("userList");
				include_once("/app/view/admin/showUser.php");
			}
			else if(($_REQUEST['request'])=="reportPanel")
			{	
				adminPanelCookieUpdate("report");
			}
			
		}
	}
	if(isset($_GET['controller'])&& !isset($_REQUEST['js']))
	{
		
		$key=$_GET['controller'];
		ChangeController($key);	
	}
	else if(!isset($_GET['controller'])&& !isset($_REQUEST['js']))
	{
		ChangeController("");
	}
	function adminPanelCookieUpdate($panel)
	{
		setcookie("adminPanel",$panel);
	}
	function adminPanelCookieGet()
	{
		return $_COOKIE["adminPanel"];
	}
	function adminPanelCookieSet($panel)
	{
		setcookie("adminPanel",$panel,time()+30000);
	}
	function adminPanelCookieExist()
	{
		
		if(isset($_COOKIE["adminPanel"]))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	function ChangeController($Controller)
	{
		switch($Controller)
		{
			case "adminDashboard":
				include_once("/app/view/admin/adminDashboard.php");
				break;
				
			case "user":
				echo "user";
				break;
				
			case "register":
				include_once("/app/view/reg.php");
				break;

			default:
				include_once("/app/view/login.php");
				
				break;
		}
	}
	

?>