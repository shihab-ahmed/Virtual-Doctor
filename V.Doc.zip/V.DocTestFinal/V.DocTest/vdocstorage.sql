-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 06, 2017 at 10:04 AM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vdocstorage`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `id` int(11) NOT NULL,
  `docUname` varchar(50) NOT NULL,
  `userUname` varchar(50) NOT NULL,
  `startDate` datetime NOT NULL,
  `endDate` datetime NOT NULL,
  `message` varchar(300) NOT NULL,
  `status` varchar(100) NOT NULL,
  `isSeenUser` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`id`, `docUname`, `userUname`, `startDate`, `endDate`, `message`, `status`, `isSeenUser`) VALUES
(35, 'Dr.Adila', 'Shihab', '0002-01-02 14:02:00', '0002-02-02 14:02:00', 'asdsad', 'pending', 0),
(34, 'Dr.Adila', 'Shihab', '0003-12-01 01:01:00', '0003-01-02 01:01:00', 'af', 'pending', 0),
(33, 'Dr.Zerin', 'Shihab', '2017-05-17 00:01:00', '2017-05-02 01:02:00', 'need appointment', 'pending', 0),
(32, 'Dr.Adila', 'Shihab', '2017-05-02 01:02:00', '2017-05-17 01:01:00', 'need appointment plz', 'accept', 0);

-- --------------------------------------------------------

--
-- Table structure for table `chatlog`
--

CREATE TABLE `chatlog` (
  `id` int(11) NOT NULL,
  `sender` varchar(50) NOT NULL,
  `reciever` varchar(50) NOT NULL,
  `message` varchar(300) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chatlog`
--

INSERT INTO `chatlog` (`id`, `sender`, `reciever`, `message`) VALUES
(151, 'Shihab', 'Dr.Adila', 'hey adila'),
(150, 'Dr.Adila', 'Shihab', 'hey shihab'),
(149, 'Dr.Adila', 'Shihab', 'when'),
(148, 'Shihab', 'Dr.Adila', 'i want to request for an appointment'),
(147, 'Dr.Adila', 'Shihab', 'hey what do u need'),
(146, 'Shihab', 'Dr.Adila', 'hello disha');

-- --------------------------------------------------------

--
-- Table structure for table `contactlist`
--

CREATE TABLE `contactlist` (
  `id` int(11) NOT NULL,
  `uname` varchar(50) NOT NULL,
  `docname` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  `isSeenUser` tinyint(1) NOT NULL,
  `isSeen` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contactlist`
--

INSERT INTO `contactlist` (`id`, `uname`, `docname`, `status`, `isSeenUser`, `isSeen`) VALUES
(63, 'Shihab', 'Shahin', 'pending', 0, 0),
(62, 'Shihab', 'Dr.Ayame', 'pending', 0, 0),
(61, 'Shihab', 'Dr.Adila', 'accept', 1, 0),
(60, 'Shihab', 'Dr.Zerin', 'accept', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `id` int(11) NOT NULL,
  `docUname` varchar(50) NOT NULL,
  `specialist` varchar(100) NOT NULL,
  `experience` int(2) NOT NULL,
  `about` varchar(500) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`id`, `docUname`, `specialist`, `experience`, `about`) VALUES
(37, 'Dr.Adila', 'Neonatologist', 2, 'Researchers in medical science have benefited mankind immensely. Medical science provides remedies, cures and safeguards man against various disease, different countries have different systems of medicine. Ayurveda, Homeopathy, Acupuncture, Acupressure etc. are becoming popular today. Diseases like cholera, polio, malaria, pox etc. have almost been eradicated. Once considered incurable, disease like cancer and tuberculosis can be cured today.'),
(36, 'Dr.Zerin', 'Endocrinologists', 3, 'Researchers in medical science have benefited mankind immensely. Medical science provides remedies, cures and safeguards man against various disease, different countries have different systems of medicine. Ayurveda, Homeopathy, Acupuncture, Acupressure etc. are becoming popular today. Diseases like cholera, polio, malaria, pox etc. have almost been eradicated. Once considered incurable, disease like cancer and tuberculosis can be cured today.'),
(38, 'Dr.Ayame', 'Dentist', 5, 'Researchers in medical science have benefited mankind immensely. Medical science provides remedies, cures and safeguards man against various disease, different countries have different systems of medicine. Ayurveda, Homeopathy, Acupuncture, Acupressure etc. are becoming popular today. Diseases like cholera, polio, malaria, pox etc. have almost been eradicated. Once considered incurable, disease like cancer and tuberculosis can be cured today.'),
(39, 'Shahin', 'Audiologist', 1, 'Something new');

-- --------------------------------------------------------

--
-- Table structure for table `doctor_category`
--

CREATE TABLE `doctor_category` (
  `id` int(11) NOT NULL,
  `category` varchar(50) NOT NULL,
  `specialize` varchar(1000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor_category`
--

INSERT INTO `doctor_category` (`id`, `category`, `specialize`) VALUES
(3, 'Audiologist', 'ear,hear,deaf,mute,speak'),
(4, 'Allergist', 'allergies,hay,fever,astma,skin,rash'),
(5, 'Dentist', 'mouth,teeth,gum,cavities,bleeding gums'),
(6, 'Endocrinologists', 'endocrine,gland,hormone'),
(7, 'Gynecologist', 'female,reproductive,sex,fertility,infant,baby'),
(8, 'Neonatologist', 'newborn,infant,baby'),
(9, 'Neurologist', 'human,brain,Azheimer,Parkinson,Dementia,Brain'),
(10, 'Surgeon', 'Surgery,oral,ENT,cardiothoracic,cardiovascular,neuro');

-- --------------------------------------------------------

--
-- Table structure for table `prescribe_medicine`
--

CREATE TABLE `prescribe_medicine` (
  `id` int(11) NOT NULL,
  `prescriptionId` int(11) NOT NULL,
  `medicineName` varchar(100) NOT NULL,
  `time` varchar(10) NOT NULL,
  `howLong` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `prescription`
--

CREATE TABLE `prescription` (
  `id` int(11) NOT NULL,
  `docU` varchar(50) NOT NULL,
  `user` varchar(50) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `status` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `isSeenUser` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `prescription`
--

INSERT INTO `prescription` (`id`, `docU`, `user`, `description`, `status`, `date`, `isSeenUser`) VALUES
(13, 'Dr.Adila', 'Shihab', '[{"description":"ahkjsahdakjsd","morning":"1","afternoon":"1","night":"0"},{"description":"asdasd","morning":"0","afternoon":"1","night":"0"}]', 'no change', '2017-05-03', 1),
(12, 'Dr.Adila', 'Shihab', '[{"description":"Napa","morning":"1","afternoon":"0","night":"0"},{"description":"Fimoxian","morning":"0","afternoon":"1","night":"1"},{"description":"Vave","morning":"1","afternoon":"0","night":"0"}]', 'no change', '2017-05-02', 1);

-- --------------------------------------------------------

--
-- Table structure for table `report`
--

CREATE TABLE `report` (
  `id` int(11) NOT NULL,
  `about` varchar(100) NOT NULL,
  `sender` int(11) NOT NULL,
  `reportedId` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `uname` varchar(50) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(120) DEFAULT NULL,
  `birthdate` date NOT NULL,
  `gender` varchar(10) NOT NULL,
  `age` int(3) NOT NULL,
  `picture` varchar(300) NOT NULL,
  `type` varchar(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `fname`, `lname`, `uname`, `email`, `password`, `birthdate`, `gender`, `age`, `picture`, `type`) VALUES
(145, 'Zerin', 'Mou', 'admin10', 'Astraion@live.com', '4fbd41a36dac3cd79aa1041c9648ab89', '2015-11-30', 'female', 2, '../../../uploads/1.jpg', 'admin'),
(146, 'Zerin', 'mou', 'Dr.Zerin', 'Astraion@live.com', '701cabdd6bce71dab5a11aa150bc10f1', '1988-08-31', 'female', 29, '../../../uploads/d1.jpg', 'doctor'),
(147, 'Disha', 'Adila', 'Dr.Adila', 'Astraion@live.com', '8056d6141672e0bd1d16f0ca354f3702', '1986-10-30', 'female', 31, '../../../uploads/d9.jpg', 'doctor'),
(148, 'Ayame', 'Irruzhuke', 'Dr.Ayame', 'Astraion@live.com', '93815cce7df4c31105c5c94329e49cb1', '1994-11-30', 'female', 23, '../../../uploads/d14.jpg', 'doctor'),
(149, 'Shihab', 'Ahmed', 'Shihab', 'astraion@live.com', 'e019032a0101075a9f7d46aac2bac297', '1999-01-02', 'female', 18, '../../../uploads/11.jpg', 'user'),
(150, 'Shahin', 'Ahmed', 'Shahin', 'astraion@live.com', 'e5ceff7c8a4a80fcad3dae7d23f3ac65', '1999-01-02', 'female', 18, '../../../uploads/d7.jpg', 'doctor');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chatlog`
--
ALTER TABLE `chatlog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contactlist`
--
ALTER TABLE `contactlist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctor_category`
--
ALTER TABLE `doctor_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prescribe_medicine`
--
ALTER TABLE `prescribe_medicine`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prescription`
--
ALTER TABLE `prescription`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `report`
--
ALTER TABLE `report`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `userID` (`uname`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT for table `chatlog`
--
ALTER TABLE `chatlog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=152;
--
-- AUTO_INCREMENT for table `contactlist`
--
ALTER TABLE `contactlist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;
--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
--
-- AUTO_INCREMENT for table `doctor_category`
--
ALTER TABLE `doctor_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `prescribe_medicine`
--
ALTER TABLE `prescribe_medicine`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `prescription`
--
ALTER TABLE `prescription`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `report`
--
ALTER TABLE `report`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=151;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
