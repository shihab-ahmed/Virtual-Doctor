<?php
	define('APP_ROOT', "$_SERVER[DOCUMENT_ROOT]/V.DocTest");
	$Root=APP_ROOT;
	require_once(APP_ROOT."/core/core_service.php");
?>
<?php
	if(isset($_REQUEST['task']))
	{
		if($_REQUEST['task']==1)
		{
			getProfile();
		}
		if($_REQUEST['task']==2)
		{
			getContact();
		}
		if($_REQUEST['task']==3)
		{
			getUserByKey();
		}
		if($_REQUEST['task']==4)
		{
			getAppointment();
		}
		if($_REQUEST['task']==5)
		{
			getPrescription();
		}
		if($_REQUEST['task']==6)
		{
			getContactFromRequest();
		}
		if($_REQUEST['task']==7)
		{
			updateContactToCore();
		}
		if($_REQUEST['task']==8)
		{
			deleteContactToCore();
		}
	}
	function getProfile()
	{
		//echo "string";
		echo getUserByKeyValueJSON($_REQUEST['key'],$_REQUEST['value']);
	}
	function getContact()
	{
		echo getContactListUsingDoubleKey($_REQUEST['key'],$_REQUEST['value'],$_REQUEST['key2'],$_REQUEST['value2']);
	}
	function getUserByKey()
	{
		echo getUserByKeyValueJSON($_REQUEST['key'],$_REQUEST['value']);
	}
	function getAppointment()
	{
		echo getAppointmentListUsingDoubleKey($_REQUEST['key'],$_REQUEST['value'],$_REQUEST['key2'],$_REQUEST['value2']);
	}
	function getPrescription()
	{
		echo getPrescriptionList($_REQUEST['key'],$_REQUEST['value']);
	}
	function getContactFromRequest()
	{
		echo getContactListFromCore($_REQUEST['key'],$_REQUEST['value']);
	}
	function updateContactToCore()
	{
		$notice= updateContactList($_REQUEST['uname'],$_REQUEST['docname'],$_REQUEST['status'],$_REQUEST['isSeenUser']);
		if($notice==1)
		{
			echo "Request updated";
		}
		else
		{
			echo "Request fail to updated";
		}
	}
	
	function deleteContactToCore()
	{
		
		$notice= deleteContactList($_REQUEST['uname'],$_REQUEST['docname']);
		if($notice==1)
		{
			echo "Request deleted";
		}
		else
		{
			echo "Request fail to delete";
		}

	}
	
 ?>