<?php
	define('APP_ROOT', "$_SERVER[DOCUMENT_ROOT]/V.DocTest");
	$Root=APP_ROOT;
	require_once(APP_ROOT."/core/core_service.php");
	session_start();
?>

<?php
	if(isset($_REQUEST['task']))
	{
		if($_REQUEST['task']==1)AddAdmin();
		else if($_REQUEST['task']==2)NameTaken();	
	}
	function AddAdmin()
	{
		if($_SERVER['REQUEST_METHOD']=="POST")
		{
			$isValid = true;
			
			if (validateFirstName(test_input($_POST['fname'])))$fname = test_input($_POST['fname']);
			else
			{
				$isValid = false;
			}
			if (validateLastName(test_input($_POST['lname'])))$lname = test_input($_POST['lname']);
			else
			{
				$isValid = false;
			}
			if (validateUserName($_POST['uname']) && !GetNameTaken("uname",$_POST['uname']))$uname = test_input($_POST['uname']);
			else
			{
				$isValid = false;
			}
			if (validateEmail($_POST['email']))$email = test_input($_POST['email']);
			else
			{
				$isValid = false;
			}
			if (validateDate($_POST['date']))$date = test_input($_POST['date']);
			else
			{
				$isValid = false;
			}
			if (validateGender())$gender = test_input($_POST['gender']);
			else
			{
				$isValid = false;
			}
			if (validatePassword($_POST['pass'],$_POST['cpass']))$pass = md5(test_input($_POST['pass']));
			else
			{
				$isValid = false;

			}
			if (validateImage())$file = $_POST['target_file'];
			else
			{
				$isValid = false;
				
			}
			$type =  $_POST['type'];
			if($isValid)
			{
				if(addUser($fname,$lname,$uname,$email,$pass,$date,$gender,$file,$type,$_POST['previousYear']))
				{
				  if(move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $file)) 
				    {
				        echo "your account has been created";
				       
				    }
				    else
				    {
				       
				    }
					
				}
				else
				{
				
				}			
			}
			
		}
	} 
	function NameTaken()
	{
		if(GetNameTaken("uname",$_REQUEST['uname']))
		{
			echo "Name Taken";
		}
		else
		{
			echo "";
		}
				
	}

 ?>