<?php 
	session_start();
 ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<script type="text/javascript">
		function includeProfile()
			{
				var key = "uname";
				var value = "<?php echo $_SESSION['uname']?>";
				var task="1";
				var xmlhttp = new XMLHttpRequest();
				
		        xmlhttp.onreadystatechange = function()
		        {
		            if (this.readyState == 4 && this.status == 200)
		            {
		            	//alert(this.responseText);
		                var objArr=	JSON.parse(this.responseText);

		            }
		        };
		        xmlhttp.open("GET","../../request/adminProfileRequest?value="+value+"&key="+key, false);
		        xmlhttp.send();
			}
		function SeeIfNameTaken()
		{
			var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function()
	        {
	            if (this.readyState == 4 && this.status == 200)
	            {
	                var objArr=	(this.responseText);
	                document.getElementById("unameWarning").innerHTML=objArr;
	               //alert(this.responseText);
	          
	            }
	        };
	        var uname=document.getElementById("uname").value;
	       
	        xmlhttp.open("GET","../../request/adminDashboardAddDoctorRequest.php?task=2&uname="+uname, true);
	        xmlhttp.send();
		}
		function validate()
		{
			var isValid=true;
			var fname=document.getElementById("fname").value;
			if(fname=="")
			{
				isValid=false;
				var abbr = document.createElement("abbr");
				abbr.title="only alphabet[a-z]"
				abbr.innerHTML="*";
				document.getElementById("fnameWarning").innerHTML="";
				document.getElementById("fnameWarning").appendChild(abbr);
			}
			else
			{
				for (var i = 0; i < fname.length; i++) 
				{
					if( fname.charAt(i).charCodeAt(0)<65 || fname.charAt(i).charCodeAt(0)>122)
					{
						isValid=false;
						var abbr = document.createElement("abbr");
						abbr.title="only alphabet[a-z]"
						abbr.innerHTML="*";
						document.getElementById("fnameWarning").innerHTML="";
						document.getElementById("fnameWarning").appendChild(abbr);
						break;
					}
				}
			}

			if(isValid)
			{
				document.getElementById("fnameWarning").innerHTML="";
			}
			var lname=document.getElementById("lname").value;
			if(lname=="")
			{
				isValid=false;
				var abbr = document.createElement("abbr");
				abbr.title="only alphabet[a-z]"
				abbr.innerHTML="*";
				document.getElementById("lnameWarning").innerHTML="";
				document.getElementById("lnameWarning").appendChild(abbr);
			}
			else
			{
				for (var i = 0; i < lname.length; i++) 
				{
					if( lname.charAt(i).charCodeAt(0)<65 || lname.charAt(i).charCodeAt(0)>122)
					{
						isValid=false;
						var abbr = document.createElement("abbr");
						abbr.title="only alphabet[a-z]"
						abbr.innerHTML="*";
						document.getElementById("lnameWarning").innerHTML="";
						document.getElementById("lnameWarning").appendChild(abbr);
						break;
					}
				}
			}

			if(isValid)
			{
				document.getElementById("lnameWarning").innerHTML="";
			}
			var uname=document.getElementById("uname").value;
			if(uname=="")
			{
				isValid=false;
				var abbr = document.createElement("abbr");
				abbr.title="First letter alphabet[a-z] and Unique name"
				abbr.innerHTML="*";
				document.getElementById("unameWarning").innerHTML="";
				document.getElementById("unameWarning").appendChild(abbr);
			}
			else
			{
				if( uname.charAt(0).charCodeAt(0)<65 || uname.charAt(0).charCodeAt(0)>122)
				{
					isValid=false;
					var abbr = document.createElement("abbr");
					abbr.title="only alphabet[a-z]"
					abbr.innerHTML="*";
					document.getElementById("unameWarning").innerHTML="";
					document.getElementById("unameWarning").appendChild(abbr);
					
				}
			}
			if(isValid)
			{
				document.getElementById("unameWarning").innerHTML="";
			}
			var email=document.getElementById("email").value;
			if(email=="")
			{
				isValid=false;
				var abbr = document.createElement("abbr");
				abbr.title="ex@something.com"
				abbr.innerHTML="*";
				document.getElementById("emailWarning").innerHTML="";
				document.getElementById("emailWarning").appendChild(abbr);
			}
			if(isValid)
			{
				document.getElementById("emailWarning").innerHTML="";
			}
			var date=document.getElementById("date").value;
			if(date=="")
			{
				isValid=false;
				var abbr = document.createElement("abbr");
				abbr.title="required"
				abbr.innerHTML="*";
				document.getElementById("dateWarning").innerHTML="";
				document.getElementById("dateWarning").appendChild(abbr);
			}
			if(isValid)
			{
				document.getElementById("dateWarning").innerHTML="";
			}
			var radios = document.getElementsByName('gender');
			var gender="";
			for (var i = 0, length = radios.length; i < length; i++) 
			{
			    if (radios[i].checked) 
			    {
			        gender=(radios[i].value);
			        break;
			    }
			}
			if(gender=="")
			{
				isValid=false;
				var abbr = document.createElement("abbr");
				abbr.title="required"
				abbr.innerHTML="*";
				document.getElementById("genderWarning").innerHTML="";
				document.getElementById("genderWarning").appendChild(abbr);
			}
			if(isValid)
			{
				document.getElementById("genderWarning").innerHTML="";
			}
			var pass=document.getElementById("pass").value;
			if(pass=="")
			{
				isValid=false;
				var abbr = document.createElement("abbr");
				abbr.title="required(<10 word)"
				abbr.innerHTML="*";
				document.getElementById("passWarning").innerHTML="";
				document.getElementById("passWarning").appendChild(abbr);
			}
			if(isValid)
			{
				document.getElementById("passWarning").innerHTML="";
			}
			var cpass=document.getElementById("cpass").value;
			if(cpass=="")
			{
				isValid=false;
				var abbr = document.createElement("abbr");
				abbr.title="required(<10 word)"
				abbr.innerHTML="*";
				document.getElementById("cpassWarning").innerHTML="";
				document.getElementById("cpassWarning").appendChild(abbr);
			}
			if(isValid)
			{
				document.getElementById("cpassWarning").innerHTML="";
			}
			var fileToUpload = document.getElementById("fileToUpload");
			var file = fileToUpload.files[0];

			if(file!=null)
			{
				var fileName=file.name;
				var fileSize=file.size;
			}
			else
			{
				isValid=false;
				var abbr = document.createElement("abbr");
				abbr.title="only jpg,png"
				abbr.innerHTML="*";
				document.getElementById("fileWarning").innerHTML="";
				document.getElementById("fileWarning").appendChild(abbr);
			}
			if(isValid)
			{
				document.getElementById("fileWarning").innerHTML="";
				if(cpass!=pass)
				{
					isValid=false;
					document.getElementById("status").innerHTML="";
					document.getElementById("status").innerHTML="Confirm pass doesnt match";
				}
			}
			if(isValid)
			{
				var form=document.getElementById("form");
				document.getElementById("status").innerHTML="";
				document.getElementById("status").innerHTML="Account Created";
				form.submit();
			}
		}
		function gotoChangeProfile()
		{
			window.location.href="adminChangeProfile.php"
		}
		function gotoAddAdmin()
		{
			window.location.href="addAdminDashboard.php"
		}
		function gotoAddDoctor()
		{
			window.location.href="addDoctorDashboard.php"
		}
		function gotoShowUser()
		{
			window.location.href="showUser.php"
		}
		function gotoReportUser()
		{
			window.location.href="ReportUser.php"
		}
		function gotoLogout()
		{
			window.location.href="../logout.php"
		}
	</script>
</head>
<body onload="includeProfile()">
	<table border="1">
		<tbody>
			<tr>
				<td>
					<table>
						<tbody>
							<tr>
								<td>
									<div onclick="includePanelProfile()">
										<img src="" id="profilePic">
										<p id="userName"></p>
										</script>
									</div>
								</td>
							</tr>

							<tr>
								<td>
									<ul>
										<li onclick="gotoAddDoctor()">Add Doctor</li>
										<li onclick="gotoAddAdmin()">Add Admin</li>
										<li onclick="gotoShowUser()">Show User</li>
										<li onclick="gotoReportUser()">Report</li>
										<li onclick="gotoLogout()">Logout</li>
									</ul>
								</td>
							</tr>
						</tbody>
					</table>
				</td>
				<td id="panel">	
					<form action="../../request/adminDashboardAddDoctorRequest.php?task=1" method="post" enctype="multipart/form-data" id="form">
						<table>
							<tbody>
								<tr>
									<td>
										First Name :
									</td>
									<td>
										<input type="text" name="fname" id="fname">
										<input type="hidden" name="type" value="doctor">
									</td>
									<td id="fnameWarning">
												
									</td>
								<tr>
									<td>
										Last Name :
									</td>
									<td>
										<input type="text" name="lname" id="lname">
									</td>
									<td id="lnameWarning">
												
									</td>
								</tr>
								<tr>
									<td>
										User Name :
									</td>
									<td>
										<input type="text" name="uname" id="uname" onkeyup="SeeIfNameTaken()">
									</td>
									<td id="unameWarning">
												
									</td>
								</tr>
								<tr>
									<td>
										Email :
									</td>
									<td>
										<input type="Email" name="email" id="email">
									</td>
									<td id="emailWarning">
												
									</td>
								</tr>
								<tr>
									<td>
										Date :
									</td>
									<td>
										<input type="date" name="date" id="date">
									</td>
									<td id="dateWarning">
												
									</td>
								</tr>
								<tr>
									<td>
										Gender :
									</td>
									<td>
										<input type="radio" name="gender" value="male" checked=""> Male
										<input type="radio" name="gender" value="female">Female
									</td>
									<td id="genderWarning">
												
									</td>
								</tr>
								<tr>
									<td>
										Password :
									</td>
									<td>
										<input type="Password" name="pass" id="pass">
									</td>
									<td id="passWarning">
												
									</td>
								</tr>
								<tr>
									<td>
										Confirm Password :
									</td>
									<td>
										<input type="Password" name="cpass" id="cpass">
									</td>
									<td id="cpassWarning">
												
									</td>
								</tr>
								<tr>
									<td>
										Specialist :
									</td>
									<td>
										<select id="category" name="category">
											<option>Audiologist</option>
											<option>Allergist</option>
											<option>Dentist</option>
											<option>Endocrinologists</option>
											<option>Gynecologist</option>
											<option>Neonatologist</option>
											<option>Neurologist</option>
											<option>Surgeon</option>
										</select>

									</td>
								</tr>
								<tr>
									<td>
										Experience(Year) :
									</td>
									<td>
										<input type="text" name="experience">
									</td>
								</tr>
								<tr>
									<td>
										About :
									</td>
									<td>
										<input type="text" name="about">
									</td>
								</tr>
								<tr>
									<td>
										Profile Picture :
									</td>
									<td>
										 <input type="file" name="fileToUpload" id="fileToUpload">
									</td>
									<td id="fileWarning">
												
									</td>
								</tr>
								<tr>
									<td>
									</td>
									<td >
										<input type="button" onclick="validate()" value="Sign Up" name="signUp" />
									</td>
								</tr>
									<tr>
										<td>
											
										</td>
										<td id="status">
											<?php  if(isset( $_POST['success'])) { ?>
											
										    Account created    
										     <?php  }  ?>	  
										       
										</td>
									</tr>
							</tbody>
						</table>
					</form>
	
				</td>
			</tr>
		</tbody>
	</table>
</body>
</html>















