<?php 
	session_start();
 ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<script type="text/javascript">
		function includeProfile()
		{
			var key = "uname";
			var value = "<?php echo $_SESSION['uname']?>";
			var task="1";
			var xmlhttp = new XMLHttpRequest();
			
	        xmlhttp.onreadystatechange = function()
	        {
	            if (this.readyState == 4 && this.status == 200)
	            {
	            	//alert(this.responseText);
	                var objArr=	JSON.parse(this.responseText);
	                
					userList("","");

	            }
	        };
	        xmlhttp.open("GET","../../request/adminProfileRequest?value="+value+"&key="+key, false);
	        xmlhttp.send();
		}
		function userList(key,value)
			{
				var xmlhttp = new XMLHttpRequest();
				xmlhttp.onreadystatechange = function()
		        {
		            if (this.readyState == 4 && this.status == 200)
		            {
		            	document.getElementById("list").innerHTML="";

		               	var objArr=	JSON.parse(this.responseText);
						
				        for(var x in objArr)
						{
							
							var tr = document.createElement("tr");

							var tdName = document.createElement("td");
							var tdEmail = document.createElement("td");
							var tdAge = document.createElement("td");
							var tdGender = document.createElement("td");
							var tdType = document.createElement("td");
							var tdDel = document.createElement("td");

							var btn = document.createElement("input"); 
							btn.type="button";
							btn.value="delete";
							btn.id=objArr[x].uname;
							btn.name=objArr[x].type;
							btn.class=objArr[x].picture;
							btn.onclick = function(){DeleteUser(this.id,this.name,this.class)};
					

							tdName.innerHTML= objArr[x].fname+" "+objArr[x].lname;
							tdEmail.innerHTML= objArr[x].email;
							tdAge.innerHTML= objArr[x].age;
							tdGender.innerHTML= objArr[x].gender;
							tdType.innerHTML= objArr[x].type;
							tdDel.appendChild(btn);	

							tr.appendChild(tdName);
							tr.appendChild(tdEmail);
							tr.appendChild(tdAge);
							tr.appendChild(tdGender);
							tr.appendChild(tdType);
							tr.appendChild(tdDel);

							document.getElementById("list").appendChild(tr);
						}
		               
		            }
		        };
		        if(value=="")
		        {
		        	xmlhttp.open("GET","../../request/adminDashboardShowUserRequest.php?task=1", true);
		        }
		        else
		        {
		        	xmlhttp.open("GET","../../request/adminDashboardShowUserRequest.php?task=2&key="+key+"&value="+value, true);
		        }
		       
		        xmlhttp.send();
			}
			function DeleteUser(value,type,pic)
			{
				//alert(value+" "+type+" "+pic);
				var key="uname";
			    var xmlhttp = new XMLHttpRequest();
				xmlhttp.onreadystatechange = function() 
			 	{
		            if (this.readyState == 4 && this.status == 200) 
		            {
		            	var notice= this.responseText;
		            	alert(notice);
		            	userList("","");
		            }               
		          
			    };
				xmlhttp.open("GET","../../request/adminDashboardShowUserRequest.php?task=3&key="+key+"&value="+value+"&type="+type+"&pic="+pic, false);
		        xmlhttp.send();
			}
			function searchUser()
			{
				var value=document.getElementById("value").value;
				var key=document.getElementById("key").value;
				
				if(value=="")
				{
					userList("","");
				}
				else
				{
					userList(key,value);
				}
			}
		function gotoChangeProfile()
		{
			window.location.href="adminChangeProfile.php"
		}
		function gotoAddAdmin()
		{
			window.location.href="addAdminDashboard.php"
		}
		function gotoAddDoctor()
		{
			window.location.href="addDoctorDashboard.php"
		}
		function gotoShowUser()
		{
			window.location.href="showUser.php"
		}
		function gotoReportUser()
		{
			window.location.href="ReportUser.php"
		}
		function gotoLogout()
		{
			window.location.href="../logout.php"
		}
	</script>
</head>
<body onload="includeProfile()">
	<table border="1">
		<tbody>
			<tr>
				<td>
					<table>
						<tbody>
							<tr>
								<td>
									<div onclick="includePanelProfile()">
										<img src="" id="profilePic">
										<p id="userName"></p>
										</script>
									</div>
								</td>
							</tr>

							<tr>
								<td>
									<ul>
										<li onclick="gotoAddDoctor()">Add Doctor</li>
										<li onclick="gotoAddAdmin()">Add Admin</li>
										<li onclick="gotoShowUser()">Show User</li>
										<li onclick="gotoReportUser()">Report</li>
										<li onclick="gotoLogout()">Logout</li>
									</ul>
								</td>
							</tr>
						</tbody>
					</table>
				</td>
				<td id="panel">	
					<table>
						<tr>
							<td>
								<input type="text" id="value" placeholder="search" onkeyup="searchUser()">
								<select id="key">
									<option value="fname">First Name</option>
									<option value="lname">Last Name</option>
									<option value="type">Type</option>
									<option value="gender">Gender</option>
								</select>
							</td>
						</tr>
						<tr>
							<table id="list">
								
							</table>
						</tr>
					</table>	
				</td>
			</tr>
		</tbody>
	</table>
</body>
</html>

</html>

