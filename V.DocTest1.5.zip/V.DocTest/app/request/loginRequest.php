<?php
	define('APP_ROOT', "$_SERVER[DOCUMENT_ROOT]/V.DocTest");
	$Root=APP_ROOT;
	require_once(APP_ROOT."/core/core_service.php");
?>
<?php
	if($_SERVER['REQUEST_METHOD']=="POST")
	{
		if(!empty(test_input($_POST['unameText']))&&!empty(test_input($_POST['passText'])))
		{
			$key="uname";
			$user=getUserByKeyValue($key,$_POST['unameText']);
			if(md5($_POST['passText'])==$user['password'])
			{
				if($user['type']=="admin")
				{
					setUserInformationToSession($user);
					header("Location: ../view/admin/adminDashboard.php");
				}
				else if($user['type']=="user")
				{
					setUserInformationToSession($user);
					
				}
				else
				{
					setUserInformationToSession($user);
					
				}
			}
			else
			{
				//header("Location: ../view/login.php?status=0");
			}
		
		}
		else
		{
			//header("Location: ../view/reg.php?status=0");
		}
	}
	function RequestFrontController($controller)
	{
		header("Location: ?controller=".$controller);
	}
	function setUserInformationToSession($user)
	{
		$_SESSION['id']  =$user['id'];
		$_SESSION['fname']=$user['fname'];
		$_SESSION['lname']=$user['lname'];
		$_SESSION['uname']=$user['uname'];
		$_SESSION['email']  =$user['email'];
		$_SESSION['birthdate']=$user['birthdate'];
		$_SESSION['gender']=$user['gender'];
		$_SESSION['age']=$user['age'];
		$_SESSION['type']=$user['type'];
		$_SESSION['picture']=$user['picture'];
		$_SESSION['password']=$user['password'];
	}
	
?>