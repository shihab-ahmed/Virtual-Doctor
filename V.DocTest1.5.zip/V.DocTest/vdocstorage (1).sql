-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 29, 2017 at 06:18 AM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vdocstorage`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `id` int(11) NOT NULL,
  `docUname` varchar(50) NOT NULL,
  `userUname` varchar(50) NOT NULL,
  `startDate` datetime NOT NULL,
  `endDate` datetime NOT NULL,
  `message` varchar(300) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`id`, `docUname`, `userUname`, `startDate`, `endDate`, `message`, `status`) VALUES
(12, 'doc3', 'patient3', '2017-04-12 01:01:00', '2017-04-05 01:02:00', 'want appointment', 'pending'),
(13, 'doc3', 'patient2', '2017-04-13 01:02:00', '2017-04-20 00:02:00', 'asdas', 'pending'),
(14, 'doc3', 'patient2', '2017-04-04 02:03:00', '2017-04-11 01:02:00', 'sadas', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `chatlog`
--

CREATE TABLE `chatlog` (
  `id` int(11) NOT NULL,
  `sender` varchar(50) NOT NULL,
  `reciever` varchar(50) NOT NULL,
  `message` varchar(300) NOT NULL,
  `messageTime` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `contactlist`
--

CREATE TABLE `contactlist` (
  `id` int(11) NOT NULL,
  `uname` varchar(50) NOT NULL,
  `docname` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  `isSeenUser` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contactlist`
--

INSERT INTO `contactlist` (`id`, `uname`, `docname`, `status`, `isSeenUser`) VALUES
(15, 'patient1', 'doc3', 'accept', 1);

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `id` int(11) NOT NULL,
  `docUname` varchar(50) NOT NULL,
  `specialist` varchar(100) NOT NULL,
  `experience` int(2) NOT NULL,
  `about` varchar(500) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`id`, `docUname`, `specialist`, `experience`, `about`) VALUES
(28, 'doc', 'Allergist', 2, 'a');

-- --------------------------------------------------------

--
-- Table structure for table `doctor_category`
--

CREATE TABLE `doctor_category` (
  `id` int(11) NOT NULL,
  `category` varchar(50) NOT NULL,
  `specialize` varchar(1000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor_category`
--

INSERT INTO `doctor_category` (`id`, `category`, `specialize`) VALUES
(3, 'Audiologist', 'ear,hear,deaf,mute,speak'),
(4, 'Allergist', 'allergies,hay,fever,astma,skin,rash'),
(5, 'Dentist', 'mouth,teeth,gum,cavities,bleeding gums'),
(6, 'Endocrinologists', 'endocrine,gland,hormone'),
(7, 'Gynecologist', 'female,reproductive,sex,fertility,infant,baby'),
(8, 'Neonatologist', 'newborn,infant,baby'),
(9, 'Neurologist', 'human,brain,Azheimer,Parkinson,Dementia,Brain'),
(10, 'Surgeon', 'Surgery,oral,ENT,cardiothoracic,cardiovascular,neuro');

-- --------------------------------------------------------

--
-- Table structure for table `prescribe_medicine`
--

CREATE TABLE `prescribe_medicine` (
  `id` int(11) NOT NULL,
  `prescriptionId` int(11) NOT NULL,
  `medicineName` varchar(100) NOT NULL,
  `time` varchar(10) NOT NULL,
  `howLong` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `prescription`
--

CREATE TABLE `prescription` (
  `id` int(11) NOT NULL,
  `docU` varchar(50) NOT NULL,
  `user` varchar(50) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `status` varchar(50) NOT NULL,
  `date` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `prescription`
--

INSERT INTO `prescription` (`id`, `docU`, `user`, `description`, `status`, `date`) VALUES
(5, 'doc3', 'patient1', '[{"description":"askdhkjas","morning":"0","afternoon":"1","night":"0"},{"description":"asd asdasd","morning":"0","afternoon":"1","night":"0"}]', 'no change', '1999-01-01');

-- --------------------------------------------------------

--
-- Table structure for table `report`
--

CREATE TABLE `report` (
  `id` int(11) NOT NULL,
  `about` varchar(100) NOT NULL,
  `sender` int(11) NOT NULL,
  `reportedId` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `uname` varchar(50) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(120) DEFAULT NULL,
  `birthdate` date NOT NULL,
  `gender` varchar(10) NOT NULL,
  `age` int(3) NOT NULL,
  `picture` varchar(300) NOT NULL,
  `type` varchar(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `fname`, `lname`, `uname`, `email`, `password`, `birthdate`, `gender`, `age`, `picture`, `type`) VALUES
(119, 'Shihab', 'Ahmed', 'Astraion', 'Astraion@live.com', '0cc175b9c0f1b6a831c399e269772661', '2017-12-31', 'male', 0, 'C:/wamp64/www/V.DocTest/uploads/1.jpg', 'admin'),
(120, 'd', 'd', 'doc', 'Astraion@live.com', '9a09b4dfda82e3e665e31092d1c3ec8d', '2017-12-31', 'male', 0, 'C:/wamp64/www/V.DocTest/uploads/admin.jpg', 'doctor'),
(61, 'dragon', 'dragon', 'admin1', 'Astraion@live.com', 'e00cf25ad42683b3df678c61f42c6bda', '2017-12-31', 'male', 0, 'C:/wamp64/www/V.DocTest/uploads/d3.jpg', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chatlog`
--
ALTER TABLE `chatlog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contactlist`
--
ALTER TABLE `contactlist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctor_category`
--
ALTER TABLE `doctor_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prescribe_medicine`
--
ALTER TABLE `prescribe_medicine`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prescription`
--
ALTER TABLE `prescription`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `report`
--
ALTER TABLE `report`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `userID` (`uname`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `chatlog`
--
ALTER TABLE `chatlog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=106;
--
-- AUTO_INCREMENT for table `contactlist`
--
ALTER TABLE `contactlist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT for table `doctor_category`
--
ALTER TABLE `doctor_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `prescribe_medicine`
--
ALTER TABLE `prescribe_medicine`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `prescription`
--
ALTER TABLE `prescription`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `report`
--
ALTER TABLE `report`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=121;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
