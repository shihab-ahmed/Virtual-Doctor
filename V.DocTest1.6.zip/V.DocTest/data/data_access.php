﻿<?php require_once(APP_ROOT."/lib/data_access_helper.php");?>

<?php
	function getUserByKeyValueFromDb($key,$value)
	{	
		$query = "SELECT `id`, `fname`, `lname`, `uname`, `email`, `password`, `birthdate`, `gender`, `age`, `picture`, `type` FROM `user` WHERE $key='$value'";  
		$result = executeQuery($query);	

		$user = null;
		if($result){

			$user = mysqli_fetch_assoc($result);
		}
		return $user;
	}
	function getUserByKeyValueJSONFromDb($key,$value)
	{	
		$query = "SELECT `id`, `fname`, `lname`, `uname`, `email`, `password`, `birthdate`, `gender`, `age`, `picture`, `type` FROM `user` WHERE $key='$value'";  
		$result = executeQuery($query);	
		return $result;
	}
	function addUserToDb($fname,$lname,$uname,$email,$pass,$date,$gender,$file,$type,$previousYear)
	{
		$currentYear = date("Y");
	 	$age = $currentYear - $previousYear;	 	   
		$query="INSERT INTO user(fname,lname,uname,email,password,birthdate,gender,age,picture,type) VALUES ('$fname','$lname','$uname','$email','$pass','$date','$gender','$age','$file','$type')";
 		$result = executeQuery($query);	
 		return $result;
 	}
 	function addDoctorToDb($fname,$lname,$uname,$email,$pass,$date,$gender,$file,$type,$previousYear,$category,$experience,$about)
	{
		$currentYear = date("Y");
	 	$age = $currentYear - $previousYear;	 	   
		$query="INSERT INTO user(fname,lname,uname,email,password,birthdate,gender,age,picture,type) VALUES ('$fname','$lname','$uname','$email','$pass','$date','$gender','$age','$file','$type')";
 		$result = executeQuery($query);	
 		if($result)
 		{
 			$query2="INSERT INTO `doctor`(`docUname`, `specialist`, `experience`, `about`) VALUES ('$uname','$category',$experience,'$about')";
 			$result2 = executeQuery($query2);	
 		}
 		return $result2;
 	}
	function GetNameTakenFromDb($key,$value)
 	{
 	
 		$query = "SELECT `id`, `fname`, `lname`, `uname`, `email`, `password`, `birthdate`, `gender`, `age`, `picture`, `type` FROM `user` WHERE $key='$value'";  
		$result = executeQuery($query);	
 	    if ($result->num_rows > 0) 
		{
			return true;
		}
		else
		{
			return false;
		}
 	}
 	function DeleteUserByKeyValueFromDb($key,$value,$type,$pic)
 	{	
		$query="DELETE FROM `user` WHERE $key='$value'";
 		$result = executeQuery($query);	
 		if($type=="doctor" && $result)
 		{
 			$query2="DELETE FROM `doctor` WHERE docUname='$value'";
 			$result2 = executeQuery($query2);	
 			return $result2;
 		}
 		if (file_exists($pic)) 
		{
		    unlink($pic);
		}
		if($type=="doctor")return $result2;		
 		else
 			return $result;
 	}
 	function getUserByKeyValueUsingLikeFromDb($key,$value)
	{
		
		$query="SELECT id,fname,lname,uname,email,password,birthdate,gender,age,picture,type,picture FROM `user` WHERE $key LIKE '$value%'";  
		$result = executeQuery($query);	
		return $result;
	}
 	function getAllUserFromDb()
	{
		$query="SELECT id,fname,lname,uname,email,password,birthdate,gender,age,picture,type FROM `user`";
		$result = executeQuery($query);	
		return $result;
	}
	function updateUserProfileToDb($fname,$lname,$uname,$email,$date,$gender,$file,$previousYear)
 	{	
		$currentYear = date("Y");
	 	$age = $currentYear - $previousYear;	 	   
		$query="UPDATE user SET fname='$fname',lname='$lname',email='$email',birthdate='$date',`gender`='$gender',`age`='$age',`picture`='$file' WHERE uname='$uname'";

 		$result = executeQuery($query);
 		if (file_exists($_SESSION['picture'])) 
		{
		    unlink($_SESSION['picture']);
		}		
 		return $result;
 	}
 	
 	function updateUserPasswordToDb($pass,$uname)
 	{		   
		$query="UPDATE user SET password='$pass' WHERE uname='$uname'";
 		$result = executeQuery($query);
 		return $result;
 	}
 	function getDoctorDetailsFromDatabase()
	{
		$query="SELECT `id`, `docUname`, `specialist`, `experience`, `about` FROM `doctor`";
		$result = executeQuery($query);
		return $result;	
	}
	function getDoctorDetailsUsingKeyValueFromDatabase($key,$value)
	{
		
		$query="SELECT `id`, `docUname`, `specialist`, `experience`, `about` FROM `doctor` WHERE $key='$value'";
		$result = executeQuery($query);
		
		return $result;	
	}
	function sendContactRequestToDoctorToDb($uname,$docname,$status,$isSeenUser,$isSeen)
	{
		$query="INSERT INTO `contactlist`(`uname`, `docname`, `status`, `isSeenUser`, `isSeen`) VALUES ('$uname','$docname','$status','$isSeenUser','$isSeen')";
		$result = executeQuery($query);
		return $result;
	}
	function addAppointmentToDb($docUname,$uname,$startDate,$endDate,$message,$status)
	{	 	   
		$query="INSERT INTO `appointment`(`docUname`, `userUname`, `startDate`, `endDate`, `message`, `status`) VALUES ('$docUname','$uname','$startDate','$endDate','$message','$status')";
 		$result = executeQuery($query);
 		return $result;
 	}
?>