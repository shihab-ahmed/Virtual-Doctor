<?php 
session_start();

?>
<!DOCTYPE html>
<html>
<head>
	<title>User Dashboard</title>
	<script type="text/javascript">
		function includeProfile()
		{
			var key = "uname";
			var value = "<?php echo $_SESSION['uname']?>";
			var task="1";
			var xmlhttp = new XMLHttpRequest();

	        xmlhttp.onreadystatechange = function()
	        {
	            if (this.readyState == 4 && this.status == 200)
	            {
	            	//alert(this.responseText);
	                var objArr=	JSON.parse(this.responseText);
	               
	                document.getElementById("userName").innerHTML=objArr[0].fname+" "+objArr[0].lname;
                	document.getElementById("name").innerHTML=objArr[0].fname+" "+objArr[0].lname;
	                document.getElementById("email").innerHTML=objArr[0].email;
	                document.getElementById("birthdate").innerHTML=objArr[0].birthdate;
	                document.getElementById("age").innerHTML=objArr[0].age;
	                document.getElementById("gender").innerHTML=objArr[0].gender;	
					
	            }
	        };
	        xmlhttp.open("GET","../../request/userProfileRequest?value="+value+"&key="+key, false);
	        xmlhttp.send();
		}
		function gotoProfile()
		{
			window.location.href="userDashboard.php";
		}
		function gotoChangeProfile()
		{
			window.location.href="userChangeProfile.php";
		}
		function gotoUserDoctor()
		{
			window.location.href="userDoctor.php";
		}
		function gotoUserAppoinment()
		{
			window.location.href="userAppointment.php";
		}
		function gotoUserPrescription()
		{
			window.location.href="userPrescription.php";
		}
		function gotoLogout()
		{
			window.location.href="../logout.php";
		}
	</script>
</head>
<body onload="includeProfile()">
	<table border="1">
		<tbody>
			<tr>
				<td>
					<table>
						<tbody>
							<tr>
								<td>
									<div onclick="gotoProfile()">
										<img src="" id="profilePic">
										<p id="userName"></p>
										
									</div>
								</td>
							</tr>

							<tr>
								<td>
									<input type="text" name="" placeholder="Search">
								</td>
							</tr>
							<tr>
								<td>
									<ul id="contactList">
										
									</ul>
								</td>
							</tr>
							<tr>
								<td>
									<ul>
										<li onclick="gotoUserDoctor()">Doctor</li>
										<li onclick="gotoUserAppoinment()">Appoinment</li>
										<li onclick="gotoUserContact()">Contact</li>
										<li onclick="gotoUserPrescription()">Prescription</li>
										<li onclick="gotoLogout()">Logout</li>
									</ul>
								</td>
							</tr>
						</tbody>
					</table>
				</td>
				<td>
					<table>
						<p id="name">a</p>
						<p id="email">a</p>
						<p id="birthdate">a</p>
						<p id="age">a</p>
						<p id="gender">a</p>
						<input type="button" value="Change" onclick="gotoChangeProfile()" name="">	
					</table>
				</td>
			</tr>
		</tbody>
	</table>
</body>
</html>