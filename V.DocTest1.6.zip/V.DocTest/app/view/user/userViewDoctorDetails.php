<?php 
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>User Dashboard</title>
	<style type="text/css">
		#chatContainer
		{
			width: 500px;
			height: 500px;
			background-color: #999;
		}
		#textBox
		{
			width: 400px;
		}
	</style>
	<script type="text/javascript">
		function includeProfile()
		{
			var key = "uname";
			var value = "<?php echo $_SESSION['uname']?>";
			var task="1";
			var xmlhttp = new XMLHttpRequest();

	        xmlhttp.onreadystatechange = function()
	        {
	            if (this.readyState == 4 && this.status == 200)
	            {
	            	//alert(this.responseText);
	                var objArr=	JSON.parse(this.responseText);
	               
	                document.getElementById("userName").innerHTML=objArr[0].fname+" "+objArr[0].lname;	
	                loadDoctorDetails();			
	            }
	        };
	        xmlhttp.open("GET","../../request/userProfileRequest?value="+value+"&key="+key, false);
	        xmlhttp.send();
		}
		function loadExtraInfo(docUname)
		{
			var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function() 
		 	{
	            if (this.readyState == 4 && this.status == 200) 
	            {
	                objArr=JSON.parse(this.responseText);
	               	document.getElementById("category").innerHTML=objArr[0].specialist;
	               	document.getElementById("experience").innerHTML=objArr[0].experience;
	            }              
		    };  
			xmlhttp.open("GET", "../../request/userDoctorViewDetailsRequest.php?task=2&key=docUname&value="+docUname, true);
	        xmlhttp.send();
		}
		function loadDoctorDetails()
		{
			var value ="<?php echo $_REQUEST['docUname']; ?>"
			var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function() 
		 	{
	            if (this.readyState == 4 && this.status == 200) 
	            {
	                objArr=JSON.parse(this.responseText);
	               	document.getElementById("name").innerHTML=objArr[0].fname+" "+objArr[0].lname;
					document.getElementById("email").innerHTML=objArr[0].email;
					document.getElementById("birthdate").innerHTML=objArr[0].birthdate;
					document.getElementById("gender").innerHTML=objArr[0].gender;
					document.getElementById("age").innerHTML=objArr[0].age;
					loadExtraInfo(value);
	            }              
		    };  
			xmlhttp.open("GET", "../../request/userDoctorViewDetailsRequest.php?task=1&key=uname&value="+value, true);
	        xmlhttp.send();
		}
		function gotoAppointmentPage()
		{
			var docUname= "<?php echo $_REQUEST['docUname']; ?>";
			window.location.href="userDoctorAppointment.php?docUname="+docUname;
		}
		function sendContactRequest()
		{
			var docname ="<?php echo $_REQUEST['docUname']; ?>"
			var uname ="<?php echo $_SESSION['uname']; ?>"
			var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function() 
		 	{
	            if (this.readyState == 4 && this.status == 200) 
	            {
	               alert(this.responseText);
	            }              
		    };  
			xmlhttp.open("GET", "../../request/userDoctorViewDetailsRequest.php?task=3&docname="+docname+"&uname="+uname, true);
	        xmlhttp.send();
		}
		
	</script>
</head>
<body onload="includeProfile()">
	<table border="1">
		<tbody>
			<tr>
				<td>
					<table>
						<tbody>
							<tr>
								<td>
									<div>
										<img src="" id="profilePic">
										<p id="userName"></p>
									</div>
								</td>
							</tr>

							<tr>
								<td>
									<input type="text" name="" placeholder="Search">
								</td>
							</tr>
							<tr>
								<td>
									<ul id="contactList">
										
									</ul>
								</td>
							</tr>
							<tr>
								<td>
									<ul>
										<li onclick="gotoUserDoctor()">Doctor</li>
										<li onclick="gotoUserAppoinment()">Appoinment</li>
										<li onclick="gotoUserContact()">Contact</li>
										<li onclick="gotoUserPrescription()">Prescription</li>
										<li onclick="gotoLogout()">Logout</li>
									</ul>
								</td>
							</tr>
						</tbody>
					</table>
				</td>
				<td>
					<table>
						<tr>
							<td>
								Name :
							</td>	
							<td>
								<p id="name"></p>
							</td>									
						</tr>

						<tr>
							<td>
								Email :
							</td>	
							<td>
								<p id="email"></p>
							</td>
						</tr>

						<tr>
							<td>
								Birthdate :
							</td>	
							<td>
								<p id="birthdate"></p>
							</td>
						</tr>

						<tr>
							<td>
								Gender :
							</td>	
							<td>
								<p id="gender"></p>
							</td>
						</tr>

						<tr>
							<td>
								Age :
							</td>	
							<td>
								<p id="age"></p>
							</td>
						</tr>
						<tr>
							<td>
								Category :
							</td>	
							<td>
								<p id="category"></p>
							</td>
						</tr>
						<tr>
							<td>
								Experience :
							</td>	
							<td>
								<p id="experience"></p>
							</td>
						</tr>
						<tr>
							<td colspan="2">
								<hr>
							</td>
						</tr>
						<tr>
							<td >
								<input type="button" name="change" value="Add to contact" onclick="sendContactRequest()">	
							</td>
						</tr>
						<tr>
							<td >
								<input type="button" name="change" value="Apply for appointment" onclick="gotoAppointmentPage()">	
							</td>
						</tr>							
					</table>
				</td>
			</tr>
		</tbody>
	</table>
</body>
</html>
