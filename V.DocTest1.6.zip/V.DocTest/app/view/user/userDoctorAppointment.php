<?php 
session_start();
	
?>
<!DOCTYPE html>
<html>
<head>
	<title>User Dashboard</title>
	<style type="text/css">
		#chatContainer
		{
			width: 500px;
			height: 500px;
			background-color: #999;
		}
		#textBox
		{
			width: 400px;
		}
	</style>
	<script type="text/javascript">
		function includeProfile()
		{
			var key = "uname";
			var value = "<?php echo $_SESSION['uname']?>";
			var task="1";
			var xmlhttp = new XMLHttpRequest();

	        xmlhttp.onreadystatechange = function()
	        {
	            if (this.readyState == 4 && this.status == 200)
	            {
	            	//alert(this.responseText);
	                var objArr=	JSON.parse(this.responseText);
	               
	                document.getElementById("userName").innerHTML=objArr[0].fname+" "+objArr[0].lname;				
	            }
	        };
	        xmlhttp.open("GET","../../request/userProfileRequest?value="+value+"&key="+key, false);
	        xmlhttp.send();
		}
		function getData()
		{
			var sdate=(document.getElementById("sdate").value);
			var stime=(document.getElementById("stime").value);
			var edate=(document.getElementById("edate").value);
			var etime=(document.getElementById("etime").value);
			var reason=(document.getElementById("reason").value);
			var form =document.getElementsByName("form")[0];
			form.submit();
		}
		
	</script>
</head>
<body onload="includeProfile()">
	<table border="1">
		<tbody>
			<tr>
				<td>
					<table>
						<tbody>
							<tr>
								<td>
									<div>
										<img src="" id="profilePic">
										<p id="userName"></p>
									</div>
								</td>
							</tr>

							<tr>
								<td>
									<input type="text" name="" placeholder="Search">
								</td>
							</tr>
							<tr>
								<td>
									<ul id="contactList">
										
									</ul>
								</td>
							</tr>
							<tr>
								<td>
									<ul>
										<li onclick="gotoUserDoctor()">Doctor</li>
										<li onclick="gotoUserAppoinment()">Appoinment</li>
										<li onclick="gotoUserContact()">Contact</li>
										<li onclick="gotoUserPrescription()">Prescription</li>
										<li onclick="gotoLogout()">Logout</li>
									</ul>
								</td>
							</tr>
						</tbody>
					</table>
				</td>
				<td>
					<form action="../../request/userAppointmentRequest.php?task=1" method="post">
						<table>
							<tbody>
								<tr>
									<td>
										<p>Start time</p>
										<input type="date" name="sdate" id="sdate">
										<input type="time" name="stime" id="stime">
									</td>
								</tr>	
								<tr>
									<td>
										<p>End time</p>
										<input type="date" name="edate" id="edate">
										<input type="time" name="etime" id="etime">
									</td>
								</tr>
								<tr>
									<td>
										<input type="text" name="reason" placeholder="message">
									</td>
								</tr>	
								<tr>
									<td><input type="submit" name="" value="Request"></td>
									<td><input type="hidden" name="docUname" value="<?php echo $_REQUEST['docUname']; ?>"></td>
									<td><input type="hidden" name="status" value="pending"></td>
								</tr>
							</tbody>							
						</table>
					</form>
				</td>
			</tr>
		</tbody>
	</table>
</body>
</html>
