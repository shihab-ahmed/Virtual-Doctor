<?php 
	session_start();
 ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<script type="text/javascript">
		function includeProfile()
			{
				var key = "uname";
				var value = "<?php echo $_SESSION['uname']?>";
				var task="1";
				var xmlhttp = new XMLHttpRequest();
				
		        xmlhttp.onreadystatechange = function()
		        {
		            if (this.readyState == 4 && this.status == 200)
		            {
		            	//alert(this.responseText);
		                var objArr=	JSON.parse(this.responseText);
		                document.getElementById("userName").innerHTML=objArr[0].fname+" "+objArr[0].lname;	
		                document.getElementById("userName").innerHTML=objArr[0].fname+" "+objArr[0].lname;
	                	document.getElementById("name").innerHTML=objArr[0].fname+" "+objArr[0].lname;
		                document.getElementById("email").innerHTML=objArr[0].email;
		                document.getElementById("birthdate").innerHTML=objArr[0].birthdate;
		                document.getElementById("age").innerHTML=objArr[0].age;
		                document.getElementById("gender").innerHTML=objArr[0].gender;					

		            }
		        };
		        xmlhttp.open("GET","../../request/adminProfileRequest?value="+value+"&key="+key, false);
		        xmlhttp.send();
			}
		function gotoProfile()
		{
			window.location.href="adminDashboard.php";
		}
		function gotoChangeProfile()
		{
			window.location.href="adminChangeProfile.php";
		}
		function gotoAddAdmin()
		{
			window.location.href="addAdminDashboard.php";
		}
		function gotoAddDoctor()
		{
			window.location.href="addDoctorDashboard.php";
		}
		function gotoShowUser()
		{
			window.location.href="showUser.php";
		}
		function gotoReportUser()
		{
			window.location.href="ReportUser.php";
		}
		function gotoLogout()
		{
			window.location.href="../logout.php";
		}
	</script>
</head>
<body onload="includeProfile()">
	<table border="1">
		<tbody>
			<tr>
				<td>
					<table>
						<tbody>
							<tr>
								<td>
									<div onclick="gotoProfile()">
										<img src="" id="profilePic">
										<p id="userName"></p>
										</script>
									</div>
								</td>
							</tr>

							<tr>
								<td>
									<ul>
										<li onclick="gotoAddDoctor()">Add Doctor</li>
										<li onclick="gotoAddAdmin()">Add Admin</li>
										<li onclick="gotoShowUser()">Show User</li>
										<li onclick="gotoReportUser()">Report</li>
										<li onclick="gotoLogout()">Logout</li>
									</ul>
								</td>
							</tr>
						</tbody>
					</table>
				</td>
				<td id="panel">	
					<p id="name">a</p>
					<p id="email">a</p>
					<p id="birthdate">a</p>
					<p id="age">a</p>
					<p id="gender">a</p>
					<input type="button" value="Change" onclick="gotoChangeProfile()" name="">		
				</td>
			</tr>
		</tbody>
	</table>
</body>
</html>

</html>