<?php
	session_destroy();
	header("location: ../View/login.php")
?>