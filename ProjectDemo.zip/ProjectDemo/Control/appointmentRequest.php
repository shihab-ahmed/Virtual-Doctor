<?php
	session_start();
	include("../Model/appointmentTable.php");

	if($_REQUEST['task']==20)
	{
		addApplyForRequest();
	}
	if($_REQUEST['task']==21)
	{
		//echo "string";
		getPendingRequest();
	}
	if($_REQUEST['task']==22)
	{
		//echo "string";
		acceptPendingRequest();
	}
	if($_REQUEST['task']==23)
	{
		
		getAcceptedRequest($_REQUEST['type'],$_REQUEST['uname'],$_REQUEST['status']);
	}
	function validateDate($date)
	{
		$isvalid=true;
		if(empty($date))$isvalid=false;
		return $isvalid;
	}
	function validateTime($time)
	{
		$isvalid=true;
		if(empty($time))$isvalid=false;
		return $isvalid;
	}
	function validateReason($reason)
	{
		$isvalid=true;
		if(empty($reason))$isvalid=false;
		return $isvalid;
	}
	function addApplyForRequest()
	{
		$isvalid=true;

		if(validateDate($_POST['sdate']))$sdate=$_POST['sdate'];
		else
		{
			$isvalid=false;
		}

		if(validateDate($_POST['edate']))$edate=$_POST['edate'];	
		else
		{
			$isvalid=false;
		}

		if(validateTime($_POST['stime']))$stime=$_POST['stime'];	
		else
		{
			$isvalid=false;
		}

		if(validateTime($_POST['etime']))$etime=$_POST['etime'];	
		else
		{
			$isvalid=false;
		}
		if(validateReason($_POST['reason']))$message=$_POST['reason'];	
		else
		{
			$isvalid=false;
		}
		
		if($isvalid)
		{
			$startDate=$sdate." ".$stime;
			$endDate=$edate." ".$etime;
			
			if(addAppointment($_POST['docUname'],$_SESSION['uname'],$startDate,$endDate,$message,$_POST['status']))
			{
				echo "AppointmentRequest sent";
				
			}
			else
			{
				//header("location :applyForAppointment.php?uname=".$_POST['docUname']."&success=0");
			}
		}
		else
		{
			echo "Failed to send request";
		}
		
	}
	function getPendingRequest()
	{
		$result =getAppointmentByID($_REQUEST['docUname'],$_REQUEST['status']);
		$rows = array();
		while($r = mysqli_fetch_assoc($result))
		{
    	 $rows[] = $r;
        }
		echo json_encode($rows);
	}
	function getAcceptedRequest($type,$name,$status)
	{
		$result =getAppointmentForByID($type,$name,$status);
		$rows = array();
		while($r = mysqli_fetch_assoc($result))
		{
    	 $rows[] = $r;
        }
		echo json_encode($rows);
	}
	function acceptPendingRequest()
	{
		
		if(updateSingleAppointmentById($_REQUEST['uname'],$_REQUEST['status']))
		{
			echo "1";
		}
		

	}
	
?>