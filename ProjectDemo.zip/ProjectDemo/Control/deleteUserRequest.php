<?php
	session_start();
	include("../Model/userTable.php");
	if ($_REQUEST['task']==1)
	{
  		deleteUserByValue($_REQUEST['type'],$_REQUEST['value'],$_REQUEST['utype']);
	}
	else if($_REQUEST['task']==2)
	{
  		
	}
	else if($_REQUEST['task']==3)
	{
  		
	}
	function deleteUserByValue($key,$value,$type)
	{	 
		$result= DeleteUserByKeyValue($key,$value,$type);
		if ($result)
		{
			echo "User Deleted";
		}
		else
		{
			echo "User Not Deleted";
		}
		
	}
	?>