<?php
	session_start();
	include("../Model/userTable.php");
	if ($_REQUEST['task']==1)
	{
  		getAllUser();
	}
	else if($_REQUEST['task']==2)
	{
  		getUserByValue($_REQUEST['type'],$_REQUEST['value']);
  		
	}
	else if($_REQUEST['task']==3)
	{
  		getDoctorCategoryRequest();
	}
	else if($_REQUEST['task']==10)
	{
  		getDoctorDetails();
	}
	function getDoctorDetails()
	{
		$result= getDoctorDetailsFromDatabase();
		$rows = array();
		while($r = mysqli_fetch_assoc($result))
		{
    	  $rows[] = $r;
        }
		echo json_encode($rows);
	}
	function getAllUser()
	{	 
		$result= getUsers();
		$rows = array();
		while($r = mysqli_fetch_assoc($result))
		{
    	  $rows[] = $r;
        }
		echo json_encode($rows);
	}
	function getUserByValue($key,$value)
	{	 
		$result= getUsersByKeyValue($key,$value);
		$rows = array();
		while($r = mysqli_fetch_assoc($result))
		{
    	  $rows[] = $r;
        }
		echo json_encode($rows);
	}
	function getDoctorDetailByValue()
	{	 
		$result= getUsersByKeyValue($key,$value);
		$rows = array();
		while($r = mysqli_fetch_assoc($result))
		{
    	  $rows[] = $r;
        }
		echo json_encode($rows);
	}
	function getDoctorCategoryRequest()
	{
		$result= getDoctorCategory();
		$rows = array();
		while($r = mysqli_fetch_assoc($result))
		{
    	  $rows[] = $r;
        }
		echo json_encode($rows);
	}
	?>