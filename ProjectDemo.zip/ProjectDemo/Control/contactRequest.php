<?php
	session_start();
	include("../Model/contactTable.php");
	if($_REQUEST['task']==30)
	{
		addApplyForRequest();
	}
	if($_REQUEST['task']==31)
	{
		getPendingRequest();
	}
	if($_REQUEST['task']==32)
	{

		acceptPendingRequest();
	}
	if($_REQUEST['task']==33)
	{

		getUserPendingInformation();
	}
	if($_REQUEST['task']==34)
	{
		updateContactList($_REQUEST['uname'],$_REQUEST['docName'],$_REQUEST['seen']);
	}
	function updateContactList($uname,$docUname,$seen)
	{
		if(updateSeenStatusById($uname,$docUname,$seen))
		{
			echo "Seen";
		}
	}
	function addApplyForRequest()
	{
		
		if(addContact($_REQUEST['docUname'],$_SESSION['uname'],$_REQUEST['status']))
		{
			echo "request sent";
		}
	}
	function getPendingRequest()
	{
		$result =getAllContactsById($_REQUEST['docUname'],$_REQUEST['status']);
		$rows = array();
		while($r = mysqli_fetch_assoc($result))
		{
    	  $rows[] = $r;
        }
		echo json_encode($rows);
	}
	function getUserPendingInformation()
	{
		//echo $_REQUEST['seen'];
		$result =getAllContactsForUserById($_REQUEST['uname'],$_REQUEST['status'],$_REQUEST['seen']);
		$rows = array();
		while($r = mysqli_fetch_assoc($result))
		{
    	  $rows[] = $r;
        }
		echo json_encode($rows);
	}
	function acceptPendingRequest()
	{
		
		if(updateSingleContactById($_REQUEST['uname'],$_REQUEST['status']))
		{
			echo "1";

		}
		

	}
	
?>