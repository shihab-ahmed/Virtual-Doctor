<?php 
	session_start();
	include("../Model/userTable.php");

	if (isset($_REQUEST['task']))
	{
		verifyUser();
	}
	function verifyUser()
	{
		if(!empty(test_input($_POST['unameText']))&&!empty(test_input($_POST['passText'])))
		{
			if(varifyUser("uname",$_POST['unameText'],$_POST['passText']))
			{
				if($_SESSION['type']=="admin")header('Location: ../View/addDoctor.php');
				else if($_SESSION['type']=="user")header('Location: ../View/userDashboard.php');
				else if($_SESSION['type']=="doctor")header("location:../View/doctorDashboard.php");
				echo $_SESSION['type'];
			}
			else
			{
				echo "Failed";
			}
		
		}
	}
	function test_input($data) 
	{
	  $data = trim($data);
	  $data = stripslashes($data);
	  $data = htmlspecialchars($data);
	  return $data;
	}
	
	
 ?>