<?php
	session_start();
	include("../Model/prescriptionTable.php");
	if ($_REQUEST['task']==1)
	{
  		addPrescription($_REQUEST['uname'],$_REQUEST['docName'],$_REQUEST['description'],$_REQUEST['status'],$_REQUEST['date']);
	}
	else if($_REQUEST['task']==2)
	{
		//echo $_REQUEST['uname'];
		getAllPrescriptionById($_REQUEST['type'],$_REQUEST['uname']);
	}
	function addPrescription($uname,$docName,$description,$status,$date)
	{
		if(addPrescriptionInTable($docName,$uname,$description,$status,$date))
		{
			echo "Precibed";
		}
	}
	function getAllPrescriptionById($key,$value)
	{
		$result= getAllPrescriptionByIdFromTable($key,$value);
		$rows = array();
		while($r = mysqli_fetch_assoc($result))
		{
    	  $rows[] = $r;
        }
		echo json_encode($rows);
	}
?>