<?php
	include("addUserRequest.php");
	if ($_REQUEST['task']==4)
	{
  		updateUserProfileRequest();
	}
	if ($_REQUEST['task']==5)
	{
  		userChangePasswordRequest();
	}
	function updateUserProfileRequest()	
	{	 
		$isValid = true;
		if (validateFirstName($_POST['fname']))$fname = $_POST['fname'];
		else
		{
			$isValid = false;
		}
		if (validateLastName($_POST['lname']))$lname = $_POST['lname'];
		else
		{
			$isValid = false;
		}
		if (validateEmail($_POST['email']))$email = $_POST['email'];
		else
		{
			$isValid = false;
		}
		if (validateDate($_POST['date']))$date = $_POST['date'];
		else
		{
			$isValid = false;
		}
		if (validateGender())$gender = $_POST['gender'];
		else
		{
			$isValid = false;
		}
		if (validateImage())$file = $_POST['target_file'];
		else
		{
			$isValid = false;
		}
		if($isValid)
		{
			if(updateUserProfile($fname,$lname,$_SESSION['uname'],$email,$date,$gender,$file,$_POST['previousYear']))
			{
				  if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $file)) 
				    {
				        //echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
				        echo "your account has been created";
				    }
				    else
				    {
				        echo "Sorry, there was an error uploading your file.";
				    }
				
			}
			else
			{
				echo "Account creation failed";
			}
		}
	}
	function userChangePasswordRequest()
	{
		$isValid = true;
		echo $_SESSION['password'];
		if(md5($_POST['opass'])==$_SESSION['password'])
		{
			if (validatePassword($_POST['pass'],$_POST['cpass']))$pass = md5($_POST['pass']);
			else
			{
				$isValid = false;
			}
			if($isValid)
			{
				if(updateUserPassword($pass,$_SESSION['uname']))
				{
					echo "password change";	
				}
				else
				{
					echo "failed to change password";
				}
			}
		}
		else
		{
			echo "Password incorrect";
		}
		
	}

?>