<?php
	session_start();
	include("../Model/userTable.php");
	if ($_REQUEST['task']==1)
	{
  		createUser();
	}
	else if ($_REQUEST['task']==2)
	{
		createAdmin();
	}
	else if ($_REQUEST['task']==3)
	{
		createDoctor();
	}
	function validateFirstName($fname)
	{
		if(empty($fname))
		{
			echo "First Name Not inserted<br>";
			return false;
		}
		else
		{
			for($i=0;$i<count($fname);$i++)
			{
				if( ord($fname[$i])<65 || ord($fname[$i])>122)
				{
					echo "First name can only contain alphabet <br>";
					return false;
				}
				else
				{
					return true;
				}
			}				
		}
	}
	function validateLastName($lname)
	{
		if(empty($lname))
		{
			echo "Last Name Not inserted<br>";
			return false;
		}
		else
		{
			for($i=0;$i<count($lname);$i++)
			{
				if( ord($lname[$i])<65 || ord($lname[$i])>122)
				{
					echo "Last name can only contain alphabet <br>";
					return false;
				}
				else
				{
					return true;
				}
			}
			
			
		}
	}
	function validateUserName($uname)
	{
		if(empty($uname))
		{
			echo "User Name Not inserted<br>";
			return false;
		}
		else
		{

			if( ord($uname[0])<65 || ord($uname[0])>122)
			{
				echo "User name can only contain alphabet <br>";
				return false;
			}
			else
			{
				if(GetExistedUser("uname",$uname))
				{
					echo "user name already exist";
					return false;
				} 
				else
				{
					return true;
				}				
			}	
			
		}
	}
	function validateEmail($email)
	{
		if(empty($_POST['gender']))return false;
		else
		{
			return true;
		}
	}
	function validateDate($date)
	{
		if(empty($date))
		{
			echo "Date Not inserted<br>";
			return false;
		}
		else
		{
			$dateArr=explode("-", $date);
			$previousYear = $dateArr[0];
			$_POST['previousYear']=$previousYear;
			if(count($dateArr)!=3)
			{
				echo "Insert correct date formate <br>";
				return false;
			}
			else
			{
				if(strlen($dateArr[0])!=4)
				{
					echo "yyyy not in correct formate <br>";
					return false;
				}
				else
				{
					for($i=0;$i<count($dateArr[0]);$i++)
					{
						if( ord($dateArr[$i])<48 || ord($dateArr[$i])>57)
						{
							echo "year can only be number<br>";
							return false;
						}
					}
				}
				if(strlen($dateArr[1])!=2)
				{
					echo "mm not in correct formate <br>";
					return false;
				}
				else
				{
					for($i=0;$i<count($dateArr[1]);$i++)
					{
						if( ord($dateArr[$i])<48 || ord($dateArr[$i])>57)
						{
							echo "month can only be number<br>";
							return false;
						}
					}
				}
				if(strlen($dateArr[2])!=2)
				{
					echo "dd formate <br>";
					return false;
				}
				else
				{
					for($i=0;$i<count($dateArr[2]);$i++)
					{
						if( ord($dateArr[$i])<48 || ord($dateArr[$i])>57)
						{
							echo "day can only be number<br>";
							return false;
						}
						else
						{
							return true;
						}
					}
				}
			}

			
		}
	}
	function validatePassword($pass,$cpass)
	{
		if(empty($pass))
		{
			echo "password is required <br>";
			return false;
		}
		if(empty($cpass))
		{
			echo "confirm password is required <br>";
			return false;
		}
		if(!empty($pass)&&!empty($cpass))
		{
			
			if($pass!=$cpass)
			{
			
				echo "password and confirm password doesnt match <br>";
				return false;
			}
			else
			{
				return true;
			}
		}
	}
	function validateGender()
	{
		if(isset($_POST['gender']))
		{
			return true;
		}
		else
		{
			echo "gender not selected <br>";
			return false;
		}
	}
	function validateYearsOfExperience($exp)
	{
		if(empty($exp))
		{
			echo "Years of experience Not inserted<br>";
			return false;
		}
		else
		{
			for($i=0;$i<count($exp);$i++)
			{
				if( ord($exp[$i])<48 || ord($exp[$i])>57)
				{
					echo "Experience can only be number <br>";
					return false;
				}
				else
				{
					return true;
				}
			}
			
			
		}
	}
	function validateImage()
	{

		if(isset($_FILES['fileToUpload']))
		{
			var_dump($_FILES["fileToUpload"]);
			$target_dir = "../Control/uploads/";
			$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
			$_POST['target_file']=$target_file;
			$uploadOk = 1;
			$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
			// Check if image file is a actual image or fake image
			if(isset($_POST["submit"])) 
			{
			    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
			    if($check !== false)
			     {
			        echo "File is an image - " . $check["mime"] . ".";
			        $uploadOk = 1;
			    } else {
			        echo "File is not an image.";
			        $uploadOk = 0;
			    }
			}

			// Check if file already exists
			if (file_exists($target_file)) 
			{
			    echo "Sorry, file already exists.";
			    $uploadOk = 0;
			}
			// Check file size
			if ($_FILES["fileToUpload"]["size"] > 500000) 
			{
			    echo "Sorry, your file is too large.";
			    $uploadOk = 0;
			}
			// Allow certain file formats
			if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
			&& $imageFileType != "gif" ) 
			{
			    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
			    $uploadOk = 0;
			}
			return $uploadOk;
		}
		else
		{
			return false;
		}
		
	}

	function createUser()
	{
		$isValid = true;
		if (validateFirstName(test_input($_POST['fname'])))$fname = test_input($_POST['fname']);
		else
		{
			$isValid = false;
		}
		if (validateLastName(test_input($_POST['lname'])))$lname = test_input($_POST['lname']);
		else
		{
			$isValid = false;
		}
		if (validateUserName($_POST['uname']))$uname = test_input($_POST['uname']);
		else
		{
			$isValid = false;
		}
		if (validateEmail($_POST['email']))$email = test_input($_POST['email']);
		else
		{
			$isValid = false;
		}
		if (validateDate($_POST['date']))$date = test_input($_POST['date']);
		else
		{
			$isValid = false;
		}
		if (validateGender())$gender = test_input($_POST['gender']);
		else
		{
			$isValid = false;
		}
		if (validatePassword($_POST['pass'],$_POST['cpass']))$pass = md5(test_input($_POST['pass']));
		else
		{
			$isValid = false;
		}
		if (validateImage())$file = $_POST['target_file'];
		else
		{
			$isValid = false;
		}
		$type = "user";
		if($isValid)
			{
				if(addUser($fname,$lname,$uname,$email,$pass,$date,$gender,$file,$type,$_POST['previousYear']))
				{
					  if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $file)) 
					    {
					        //echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
					        echo "your account has been created";
					    }
					    else
					    {
					        echo "Sorry, there was an error uploading your file.";
					    }
					
				}
				else
				{
					echo "Account creation failed";
				}
			}
	}
	function createAdmin()
	{
		$isValid = true;
		if (validateFirstName(test_input($_POST['fname'])))$fname = test_input($_POST['fname']);
		else
		{
			$isValid = false;
		}
		if (validateLastName(test_input($_POST['lname'])))$lname = test_input($_POST['lname']);
		else
		{
			$isValid = false;
		}
		if (validateUserName($_POST['uname']))$uname = test_input($_POST['uname']);
		else
		{
			$isValid = false;
		}
		if (validateEmail($_POST['email']))$email = test_input($_POST['email']);
		else
		{
			$isValid = false;
		}
		if (validateDate($_POST['date']))$date = test_input($_POST['date']);
		else
		{
			$isValid = false;
		}
		if (validateGender())$gender = test_input($_POST['gender']);
		else
		{
			$isValid = false;
		}
		if (validatePassword($_POST['pass'],$_POST['cpass']))$pass = md5(test_input($_POST['pass']));
		else
		{
			$isValid = false;
		}
		if (validateImage())$file = $_POST['target_file'];
		else
		{
			$isValid = false;
		}
		$type = "admin";
		if($isValid)
			{
				if(addAdmin($fname,$lname,$uname,$email,$pass,$date,$gender,$file,$type,$_POST['previousYear']))
				{
					  if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $file)) 
					    {
					        //echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
					        echo "your account has been created";
					    }
					    else
					    {
					        echo "Sorry, there was an error uploading your file.";
					    }
					
				}
				else
				{
					echo "Account creation failed";
				}	
			}
	}
	function createDoctor()
	{
		$isValid = true;

		if (validateFirstName(test_input($_POST['fname'])))$fname = test_input($_POST['fname']);
		else
		{
			$isValid = false;
		}
		if (validateLastName(test_input($_POST['lname'])))$lname = test_input($_POST['lname']);
		else
		{
			$isValid = false;
		}
		if (validateUserName($_POST['uname']))$uname = test_input($_POST['uname']);
		else
		{
			$isValid = false;
		}
		if (validateEmail($_POST['email']))$email = test_input($_POST['email']);
		else
		{
			$isValid = false;
		}
		if (validateDate($_POST['date']))$date = test_input($_POST['date']);
		else
		{
			$isValid = false;
		}
		if (validateGender())$gender = test_input($_POST['gender']);
		else
		{
			$isValid = false;
		}
		if (validatePassword($_POST['pass'],$_POST['cpass']))$pass =  md5(test_input($_POST['pass']));
		else
		{
			$isValid = false;
		}
		$category = $_POST['category'];
		if(validateYearsOfExperience($_POST['experience']))
		{
			$experience = $_POST['experience'];
		}
		else
		{
			$isValid = false;
		}
		$about = $_POST['about'];
		if (validateImage())$file = $_POST['target_file'];
		else
		{
			$isValid = false;
		}
		$type = "doctor";

		if($isValid)
			{
				if(addDoctor($fname,$lname,$uname,$email,$pass,$date,$gender,$file,$type,$_POST['previousYear'],$category,$experience,$about))
				{
					  if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $file)) 
					    {
					        //echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
					        echo "your account has been created";
					    }
					    else
					    {
					        echo "Sorry, there was an error uploading your file.";
					    }
					
				}
				else
				{
					echo "Account creation failed";
				}
			}
	}
	function test_input($data) 
	{
	  $data = trim($data);
	  $data = stripslashes($data);
	  $data = htmlspecialchars($data);
	  return $data;
	}

?>