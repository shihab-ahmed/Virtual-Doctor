<?php 
session_start();

?>
<!DOCTYPE html>
<html>
<head>
	<title>User Dashboard</title>
	<style type="text/css">
		#chatContainer
		{
			width: 500px;
			height: 500px;
			background-color: #999;
		}
		#textBox
		{
			width: 400px;
		}
	</style>
	<script type="text/javascript">
		
		function gotoApplyAppointment()
		{
			var value = "<?php echo $_REQUEST['uname']?>";
			window.location.href = "doctorProfileFromUser.php?uname="+value;
		}
		function requestSend()
		{
			alert("Request send");
		}
		function getData()
		{
			var sdate=(document.getElementById("sdate").value);
			var stime=(document.getElementById("stime").value);
			var edate=(document.getElementById("edate").value);
			var etime=(document.getElementById("etime").value);
			var reason=(document.getElementById("reason").value);
			var form =document.getElementsByName("form")[0];
			form.submit();
		}
	</script>
		<style type="text/css">
			#profilePic{
				width: 70px;
				border-radius: 50%;
			}

		</style>
</head>
<body >
	<div id="table">
		<table border="1" >
			<tbody>
				<tr>
					<td>
						<table>
							<tbody>
								<tr>
									<td>
										<div>
											<img src="" id="profilePic">
											<p id="userName"></p>
											<script>
												document.getElementById("userName").innerHTML = "<?php echo $_SESSION['fname']; ?>";
												document.getElementById("profilePic").src = "<?php echo $_SESSION['picture']; ?>";
											</script>
										</div>
									</td>
								</tr>

								<tr>
									<td>
										<input type="text" name="" placeholder="Search">
									</td>
								</tr>
								<tr>
									<td>
										<ul>
											<li>
												<div>
													
												</div>
											</li>
											<li>
												<div>
													
												</div>
											</li>
											<li>

											</li>
										</ul>
									</td>
								</tr>
								<tr>
									<td>
										<input type="button" value="Agent" name="">
										<input type="button" value="Find Doctor" name="">
									</td>
								</tr>
							</tbody>
						</table>
					</td>
					<td>
						<form action="../control/appointmentRequest.php?task=20" method="post">
						<table>
							<tbody>
								<tr>
								<td>
									<p>Start time</p>
									<input type="date" name="sdate" id="sdate">
									<input type="time" name="stime" id="stime">
								</td>
							</tr>	
							<tr>
								<td>
									<p>End time</p>
									<input type="date" name="edate" id="edate">
									<input type="time" name="etime" id="etime">
								</td>
							</tr>
							<tr>
								<td>
									<input type="text" name="reason" placeholder="message">
								</td>
							</tr>	
							<tr>
								<td>
									<input type="hidden" name="docUname" placeholder="message" value="<?php echo $_REQUEST['uname']; ?>">
									<input type="hidden" name="status" placeholder="message" value="pending">
									<input type="submit" name="" value="send">
								</td>
							</tr>
								
							</tbody>
											
						</table>
						</form>
					</td>
				</tr>
			</tbody>
		</table>
	</div>
</body>
</html>