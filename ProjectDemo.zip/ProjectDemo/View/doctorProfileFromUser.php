<?php 
session_start();

?>
<!DOCTYPE html>
<html>
<head>
	<title>User Dashboard</title>
	<style type="text/css">
		#chatContainer
		{
			width: 500px;
			height: 500px;
			background-color: #999;
		}
		#textBox
		{
			width: 400px;
		}
	</style>
	<script type="text/javascript">
		function loadDoctorDetails()
		{
			var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function() 
		 	{
	            if (this.readyState == 4 && this.status == 200) 
	            {
	                objArr=JSON.parse(this.responseText); 
	               	for(var x in objArr)
	               	{
	               		if(objArr[x].docUname=="<?php echo $_REQUEST['uname']?>")
	               		{
	               		
	               			document.getElementById("category").innerHTML=objArr[x].specialist;
	               			document.getElementById("experience").innerHTML=objArr[x].experience;
	               		}
	   
	               	}
	            }              
		    };
		    xmlhttp.open("GET", "../control/getUserRequest.php?task=10", false);
	        xmlhttp.send();
	    }
		function loadDoctorProfileDetails()
		{

			var xmlhttp = new XMLHttpRequest();
			var value = "<?php echo $_REQUEST['uname']?>";
			var key = "uname";
		 	xmlhttp.onreadystatechange = function() 
		 	{
	            if (this.readyState == 4 && this.status == 200) 
	            {
	                var objArr=	JSON.parse(this.responseText);

					document.getElementById("name").innerHTML=objArr[0].fname+" "+objArr[0].lname;
					document.getElementById("uname").innerHTML=objArr[0].uname;
					document.getElementById("email").innerHTML=objArr[0].email;
					document.getElementById("birthdate").innerHTML=objArr[0].birthdate;
					document.getElementById("gender").innerHTML=objArr[0].gender;
					document.getElementById("age").innerHTML=objArr[0].age;
					
					loadDoctorDetails(); 
	            }               
	          
		    };
		    xmlhttp.open("GET", "../control/getUserRequest.php?task=2&type="+key+"&value="+value, false);
	        xmlhttp.send();
		}
		function gotoApplyAppointment()
		{
			var value = "<?php echo $_REQUEST['uname']?>";
			window.location.href = "applyForAppointment.php?uname="+value;
		}
		function gotoContactRequest()
		{
			var value = "<?php echo $_REQUEST['uname']?>";
			window.location.href = "../control/contactRequest.php?docUname="+value+"&status=pending&task=30";
		}
		function gotoFindDoctor()
		{
			window.location.href = "findDoctor.php";
		}
		function gotoUserContactNotification()
		{
			window.location.href = "userContact.php";
		}
		function gotoUserAppointment()
		{
			window.location.href = "userAppointment.php";
		}
		function gotoUserPrescription()
		{
			window.location.href = "userPrescription.php";
		}
	</script>
		<style type="text/css">
			#profilePic{
				width: 70px;
				border-radius: 50%;
			}

		</style>
</head>
<body onload="loadDoctorProfileDetails()">
	<div id="table">
		<table border="1" >
			<tbody>
				<tr>
					<td>
						<table>
							<tbody>
								<tr>
									<td>
										<div>
											<img src="" id="profilePic">
											<p id="userName"></p>
											<script>
												document.getElementById("userName").innerHTML = "<?php echo $_SESSION['fname']; ?>";
												document.getElementById("profilePic").src = "<?php echo $_SESSION['picture']; ?>";
											</script>
										</div>
									</td>
								</tr>

								<tr>
									<td>
										<input type="text" name="" placeholder="Search">
									</td>
								</tr>
								<tr>
									<td>
										<ul>
											
										</ul>
									</td>
								</tr>
								<tr>
									<td>
										<input type="button" value="Doctor" name="" onclick="gotoFindDoctor()">
										<input type="button" value="Appointment" name="" onclick="gotoUserAppointment()">
										<input type="button" value="Contact" name="" onclick="gotoUserContactNotification()">
										<input type="button" value="Prescription" name="" onclick="gotoUserPrescription()">
									</td>
								</tr>
							</tbody>
						</table>
					</td>
					<td>
						<table>
							<tr>
								<td>
									Name :
								</td>	
								<td>
									<p id="name"></p>
								</td>									
							</tr>
							<tr>
								<td>
									User Name :
								</td>	
								<td>
									<p id="uname"></p>
								</td>
							</tr>	

							<tr>
								<td>
									Email :
								</td>	
								<td>
									<p id="email"></p>
								</td>
							</tr>

							<tr>
								<td>
									Birthdate :
								</td>	
								<td>
									<p id="birthdate"></p>
								</td>
							</tr>

							<tr>
								<td>
									Gender :
								</td>	
								<td>
									<p id="gender"></p>
								</td>
							</tr>

							<tr>
								<td>
									Age :
								</td>	
								<td>
									<p id="age"></p>
								</td>
							</tr>
							<tr>
								<td>
									Category :
								</td>	
								<td>
									<p id="category"></p>
								</td>
							</tr>
							<tr>
								<td>
									Experience :
								</td>	
								<td>
									<p id="experience"></p>
								</td>
							</tr>
							<tr>
								<td colspan="2">
									<hr>
								</td>
							</tr>
							<tr>
								<td >
									<input type="button" name="change" value="Add to contact" onclick="gotoContactRequest()">	
								</td>
							</tr>
							<tr>
								<td >
									<input type="button" name="change" value="Apply for appointment" onclick="gotoApplyAppointment()">	
								</td>
							</tr>							
						</table>
					</td>
				</tr>
			</tbody>
		</table>
	</div>
</body>
</html>