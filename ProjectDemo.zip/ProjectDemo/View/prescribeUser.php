<?php 
session_start();

?>

<!DOCTYPE html>
<html>
<head>
	<title>User Dashboard</title>
	<style type="text/css">
		#chatContainer
		{
			width: 500px;
			height: 500px;
			background-color: #999;
		}
		#textBox
		{
			width: 400px;
		}
		#profilePic{
			width: 70px;
			border-radius: 50%;
		}
		li{
			background-color: red;
			cursor: pointer;
		}
	</style>
	<script type="text/javascript">
		function loadContactList()
		{	
			
			var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function() 
		 	{
	            if (this.readyState == 4 && this.status == 200) 
	            {
	                var objArr=	JSON.parse(this.responseText);
	               
			        for(var x in objArr)
					{
						var li = document.createElement("li");

						li.innerHTML=objArr[x].uname;
						li.id=objArr[x].uname;
												

						document.getElementById("contactList").appendChild(li);

					}     
	            }
	            document.getElementById("selectedUserName").innerHTML=("<?php echo $_REQUEST['name'];?>")               
	          
		    };
		    var docUname="<?php echo $_SESSION['uname']; ?>"
			xmlhttp.open("GET", "../control/contactRequest.php?task=31&docUname="+docUname+"&status=accept", false);
	        xmlhttp.send();
	       
		}
		function gotoDoctorContacts()
		{
			window.location.href = "doctorContactsRequest.php";
		}
		function gotoDoctorAppointments()
		{
			window.location.href = "doctorAppointmentRequest.php";
		}
		function gotoDoctorAppointments()
		{
			window.location.href = "doctorPrescription.php";
		}
		function AddMoreOption()
		{
			var div = document.createElement("div");
			div.name="medicine";

			var inputMedicineName = document.createElement("input");
			inputMedicineName.type="text";
			inputMedicineName.name="medicineDiscriptionText"
			inputMedicineName.placeholder="medicine name"

			var checkBox1 = document.createElement("input");
			checkBox1.type="checkBox";
			checkBox1.name="morningCheckBox"
			
			var checkBox2 = document.createElement("input");
			checkBox2.type="checkBox";
			checkBox2.name="AfternoonCheckBox";

			var checkBox3 = document.createElement("input");
			checkBox3.type="checkBox";
			checkBox3.name="NightCheckBox";

			var inputAdd = document.createElement("input");
			inputAdd.type="button";
			inputAdd.value="+";
			inputAdd.onclick=function(){AddMoreOption()};

			var inputRemove = document.createElement("input");
			inputRemove.type="button";
			inputRemove.value="-";
			inputRemove.onclick=function(){RemoveOption()};

			div.appendChild(inputMedicineName);
			div.appendChild(checkBox1);
			div.appendChild(checkBox2);
			div.appendChild(checkBox3);
			div.appendChild(inputAdd);
			div.appendChild(inputRemove);
			document.getElementById("medicineListContainer").appendChild(div);

		}
		function RemoveOption()
		{
			var medicineContainer=document.getElementById("medicineListContainer");
			//alert(medicineContainer.childNodes.length-1);
			if(medicineContainer.childNodes.length-1>=3)
			{
				medicineContainer.removeChild(medicineContainer.childNodes[medicineContainer.childNodes.length-1]);
			}
			           
		}
		function prescribe()
		{
			var MediList=document.getElementsByName("medicineDiscriptionText");
			var morningList=document.getElementsByName("morningCheckBox");
			var afternoonList=document.getElementsByName("AfternoonCheckBox");
			var nightList=document.getElementsByName("NightCheckBox");

			var jsArray= new Array();
			for (var i = 0; i < MediList.length; i++) 
			{
				if((MediList[i].value!="") &&(morningList[i].checked||afternoonList[i].checked||nightList[i].checked))
				{
					var mediDetail=MediList[i].value;
					var mor,af,ni;
					if(morningList[i].checked)
					{
						mor="1";
					}
					else
					{
						mor="0";
					}
					if(afternoonList[i].checked)
					{
						af="1";
					}
					else
					{
						af="0";
					}
					if(nightList[i].checked)
					{
						ni="1";
					}
					else
					{
						ni="0";
					}
					var jsString={'description':mediDetail,'morning':mor,'afternoon':af,'night':ni};
   					jsArray.push(jsString);

				}
			}
			var uname="<?php echo $_REQUEST['name'];?>"
			var docName="<?php echo $_SESSION['uname'];?>"
			var dateTime="1999-01-01";
			var jsStringArray = JSON.stringify(jsArray);
			var status = "no change";
			if(jsArray.length>=1)
			{
				window.location.href = "../control/prescribeUserRequest.php?task=1&uname="+uname+"&docName="+docName+"&date="+dateTime+"&description="+jsStringArray+"&status="+status;
			}
			
			
			
			
		}
	</script>
</head>
<body onload="loadContactList()">
	<table border="1">
		<tbody>
			<tr>
				<td>
					<table>
						<tbody>
							<tr>
								<td>
									<div>
										<img src="" id="profilePic">
										<p id="userName"></p>
										<script>
											document.getElementById("userName").innerHTML = "<?php echo $_SESSION['fname']; ?>";
											document.getElementById("profilePic").src = "<?php echo $_SESSION['picture']; ?>";
										</script>
									</div>
								</td>
							</tr>

							<tr>
								<td>
									<input type="text" name="" placeholder="Search">
								</td>
							</tr>
							<tr>
								<td>
									<ul id="contactList">
										
									</ul>
								</td>
							</tr>
							<tr>
								<td>
									<input type="button" value="Contacts" name="" onclick="gotoDoctorContacts()">
									<input type="button" value="Appointments" name="" onclick="gotoDoctorAppointments()">
									<input type="button" value="Prescription" name="" onclick="gotoDoctorAppointments()">
								</td>
							</tr>
						</tbody>
					</table>
				</td>
				<td>
					<table>
						<tr>
							<td id="selectedUserName">
								Selected user name
							</td>
							
							<td>
								
							</td>
						</tr>
						
						<tr>
							
						</tr>
						<tr>
							<td id="medicineListContainer">
								<div name="medicine">
									<input type="text" placeholder="medicine name" name="medicineDiscriptionText">
									<input type="checkBox" name="morningCheckBox">
									<input type="checkBox" name="AfternoonCheckBox">
									<input type="checkBox" name="NightCheckBox">
									<input type="button" name="" value="+" onclick="AddMoreOption()">
								</div>
							</td>							
						</tr>
						<tr>
							<td>
								<input type="button" name="" value="prescribe" onclick="prescribe()">
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</tbody>
	</table>
</body>
</html>