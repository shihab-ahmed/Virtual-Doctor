<?php 
	session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>User Dashboard</title>
		<script type="text/javascript">
			function loadCategory()
			{
				var xmlhttp = new XMLHttpRequest();
			 	xmlhttp.onreadystatechange = function() 
			 	{
		            if (this.readyState == 4 && this.status == 200) 
		            {
		                var objArr=	JSON.parse(this.responseText);
				        for(var x in objArr)
						{
							var option=document.createElement("option");
							option.innerHTML=  objArr[x].category;
							document.getElementById("category").appendChild(option);
						}
		                          
		            }               
		          
			    };
			    xmlhttp.open("GET", "../control/getUserRequest.php?task=3", false);
		        xmlhttp.send();
			}
			function gotoProfile()
			{
				window.location.href = "adminProfile.php";
			}
		</script>
		<style type="text/css">
			#profilePic{
				width: 70px;
				height:70px;
				border-radius: 50%
			}
		</style>
</head>
<body onload="loadCategory()">
	<table border="1">
		<tbody>
			<tr>
				<td>
					<table>
						<tbody>
							<tr>
								<td>
									<div onclick="gotoProfile()">
										<img src="" id="profilePic">
										<p id="userName"></p>
										<script>
										document.getElementById("userName").innerHTML="<?php echo $_SESSION['fname']." ".$_SESSION['lname']?>";
										document.getElementById("profilePic").src="<?php echo $_SESSION['picture']?>";
										</script>
									</div>
								</td>
							</tr>

							<tr>
								<td valign="top">
								 	<a href="addAdmin.php">Add Admin</a>
								</td>
							</tr>

							<tr>
								<td valign="top">
									<a href="addDoctor.php">Add Doctor</a>
								</td>
							</tr>

							<tr>
								<td valign="top">
									<a href="showUserList.php">Show User</a>
								</td>
							</tr>

							<tr>
								<td colspan="2" valign="top">
								 <a href="adminDashboardShowReport.php">Report</a>
								</td>
							</tr>
							<tr>
								<td colspan="2" valign="top">
								<a href="../Control/logout.php">logout</a>	
								</td>
							</tr>
						</tbody>
					</table>
				</td>
				<td >	
					<form action="../Control/addUserRequest.php?task=3" method="post"  enctype="multipart/form-data">
						<table>
							<tbody>
								<tr>
									<td>
										First Name :
									</td>
									<td>
										<input type="text" name="fname">
									</td>
								<tr>
									<td>
										Last Name :
									</td>
									<td>
										<input type="text" name="lname">
									</td>
								</tr>
								<tr>
									<td>
										User Name :
									</td>
									<td>
										<input type="text" name="uname">
									</td>
								</tr>
								<tr>
									<td>
										Email :
									</td>
									<td>
										<input type="Email" name="email">
									</td>
								</tr>
								<tr>
									<td>
										Date(yyyy-mm-dd) :
									</td>
									<td>
										<input type="text" name="date">
									</td>
								</tr>
								<tr>
									<td>
										Gender :
									</td>
									<td>
										<input type="radio" name="gender" value="male"> Male
										<input type="radio" name="gender" value="female">Female
									</td>
								</tr>
								<tr>
									<td>
										Password :
									</td>
									<td>
										<input type="Password" name="pass">
									</td>
								</tr>
								<tr>
									<td>
										Confirm Password :
									</td>
									<td>
										<input type="Password" name="cpass">
									</td>
								</tr>
								<tr>
									<td>
										Specialist :
									</td>
									<td>
										<select id="category" name="category"></select>
									</td>
								</tr>
								<tr>
									<td>
										Experience(Year) :
									</td>
									<td>
										<input type="text" name="experience">
									</td>
								</tr>
								<tr>
									<td>
										About :
									</td>
									<td>
										<input type="text" name="about">
									</td>
								</tr>
								<tr>
									<td>
										Profile Picture :
									</td>
									<td>
										 <input type="file" name="fileToUpload" id="fileToUpload">
									</td>
								</tr>
								<tr>
									<td>
									</td>
									<td >
										<input type="submit" value="Sign Up" name="signUp" />
									</td>
								</tr>
							</tbody>
						</table>
					</form>			
				</td>
			</tr>
		</tbody>
	</table>
</body>
</html>
