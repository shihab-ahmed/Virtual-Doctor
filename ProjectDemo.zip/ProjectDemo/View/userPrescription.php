<?php 
session_start();

?>
<!DOCTYPE html>
<html>
<head>
	<title>User Dashboard</title>
	<style type="text/css">
		#chatContainer
		{
			width: 500px;
			height: 500px;
			background-color: #999;
		}
		#textBox
		{
			width: 400px;
		}
		#profilePic{
			width: 70px;
			border-radius: 50%;
		}
	</style>
	<script type="text/javascript">
		function loadContactList()
		{	
			document.getElementById("list").innerHTML="";

			var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function() 
		 	{
	            if (this.readyState == 4 && this.status == 200) 
	            {
	            	
	                var objArr=	JSON.parse(this.responseText);
			        for(var x in objArr)
					{
						var li = document.createElement("li");

						li.innerHTML=objArr[x].uname;							

						document.getElementById("contactList").appendChild(li);

					}     
	            }               
	          
		    };
		    var uname="<?php echo $_SESSION['uname']; ?>"
			xmlhttp.open("GET", "../control/contactRequest.php?task=33&uname="+uname+"&status=accept", true);
	        xmlhttp.send();
	        loadPendingContact();
		}
		function loadPendingContact()
		{	
			document.getElementById("list").innerHTML="";

			var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function() 
		 	{
	            if (this.readyState == 4 && this.status == 200) 
	            {
	                var objArr=	JSON.parse(this.responseText);
			        for(var x in objArr)
					{
						var tr = document.createElement("tr");

						var tdName = document.createElement("td");
						var tdMessage = document.createElement("td");
						

						tdName.innerHTML= objArr[x].docU;
						var desArr=JSON.parse(objArr[x].description)
						tdMessage.innerHTML= desArr[0].morning;							
											
		
						tr.appendChild(tdName);
						tr.appendChild(tdMessage);


						document.getElementById("list").appendChild(tr);

					}   
	            }               
	          
		    };
		    var uname="<?php echo $_SESSION['uname']; ?>"
			xmlhttp.open("GET", "../control/prescribeUserRequest.php?task=2&uname="+uname+"&type=user", true);
	        xmlhttp.send();
		}
		function gotoFindDoctor()
		{
			window.location.href = "findDoctor.php";
		}
		function gotoUserContactNotification()
		{
			window.location.href = "userContact.php";
		}
		function gotoUserAppointment()
		{
			window.location.href = "userAppointment.php";
		}
		function gotoUserPrescription()
		{
			window.location.href = "userPrescription.php";
		}
	</script>
</head>
<body onload="loadContactList()">
	<table border="1">
		<tbody>
			<tr>
				<td>
					<table>
						<tbody>
							<tr>
								<td>
									<div>
										<img src="" id="profilePic">
										<p id="userName"></p>
										<script>
											document.getElementById("userName").innerHTML = "<?php echo $_SESSION['fname']; ?>";
											document.getElementById("profilePic").src = "<?php echo $_SESSION['picture']; ?>";
										</script>
									</div>
								</td>
							</tr>

							<tr>
								<td>
									<input type="text" name="" placeholder="Search">
								</td>
							</tr>
							<tr>
								<td>
									<ul id="contactList">
										
									</ul>
								</td>
							</tr>
							<tr>
								<td>
									<input type="button" value="Doctor" name="" onclick="gotoFindDoctor()">
									<input type="button" value="Appointment" name="" onclick="gotoUserAppointment()">
									<input type="button" value="Contact" name="" onclick="gotoUserContactNotification()">
									<input type="button" value="Prescription" name="" onclick="gotoUserPrescription()">
								</td>
							</tr>
						</tbody>
					</table>
				</td>
				<td>
					<table>
						<table>
								<tr>
									<td>
										<input type="text" id="value" placeholder="search" onkeydown="searchUser()">
										<select id="key">
											<option value="uname">User Name</option>
											<option value="fname">First Name</option>
											<option value="lname">Last Name</option>
										</select>
									</td>
								</tr>
								<tr>
									<table id="list">
										
									</table>
								</tr>
							</table>
					</table>
				</td>
			</tr>
		</tbody>
	</table>
</body>
</html>