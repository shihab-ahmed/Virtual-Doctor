<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<script type="text/javascript">
		function verify()
		{
			var name=  document.getElementById("name").value;
			var pass=  document.getElementById("pass").value;
			var form = document.getElementById("form");
			if(name.length==0||pass.length==0)
			{
				form.onsubmit = function(){return false;}
			}
			else
			{
				//form.submit();
				var xmlhttp = new XMLHttpRequest();
				xmlhttp.open("GET", "loginRequest.php", false);
		        xmlhttp.send();
		        document.getElementById("stat").innerHTML = this.responseText;
				//form.onsubmit = function(){return true;}
			}
		}
	</script>
</head>
<body>
	<table>
		<tbody>
			<tr>
				<td>
					<form action="../control/loginRequest.php?task=verify" method="post" id="form" >
						<fieldset>
							<legend><h1>Login</h1></legend>
							<input type="text" name="unameText" placeholder="User name" id="name">
							<br>
							<br>
							<input type="Password" name="passText" placeholder="user password" id="pass">
							<br>
							<br>
							<input type="submit" value="Login" onclick="verify()" />
							<a href="reg.php">Register</a> 
							<br>
							<p id="stat"></p>
						</fieldset>
					</form>	
				</td>
			</tr>
		</tbody>
	</table>
</body>
</html>

