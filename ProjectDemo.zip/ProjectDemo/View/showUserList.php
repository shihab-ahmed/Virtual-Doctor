<?php
	session_start();
?>

<html>
	<head>
		<title>Dashboard</title>
		<script type="text/javascript">
			function loadUserList()
			{	
				document.getElementById("list").innerHTML="";

				var thPicture= document.createElement("th");
				var thName= document.createElement("th");
				var thEmail= document.createElement("th");
				var thBirthdate= document.createElement("th");
				var thGender= document.createElement("th");
				var thAge= document.createElement("th");
				var thType= document.createElement("th");
				var thOperation= document.createElement("th");

				var trHeader = document.createElement("tr");
				thPicture.innerHTML="Picture";
				thName.innerHTML="Name";
				thEmail.innerHTML="Email";
				thBirthdate.innerHTML="Birthdate";
				thGender.innerHTML="Gender";
				thAge.innerHTML="Age";
				thType.innerHTML="Type";
				thOperation.innerHTML="Operation";

				trHeader.appendChild(thPicture);
				trHeader.appendChild(thName);
				trHeader.appendChild(thEmail);
				trHeader.appendChild(thBirthdate);
				trHeader.appendChild(thGender);
				trHeader.appendChild(thAge);
				trHeader.appendChild(thType);
				trHeader.appendChild(thOperation);

				document.getElementById("list").appendChild(trHeader);

				var xmlhttp = new XMLHttpRequest();
				xmlhttp.onreadystatechange = function() 
			 	{
		            if (this.readyState == 4 && this.status == 200) 
		            {
		                var objArr=	JSON.parse(this.responseText);
				        for(var x in objArr)
						{
							var tr = document.createElement("tr");

							var tdPicture = document.createElement("td");
							var tdName = document.createElement("td");
							var tdEmail = document.createElement("td");
							var tdBirthDate = document.createElement("td");
							var tdGender = document.createElement("td");
							var tdAge = document.createElement("td");
							var tdType = document.createElement("td");
							var tdDel = document.createElement("td");


							var btn = document.createElement("input"); 
							btn.type="button";
							btn.value="delete";
							btn.id=objArr[x].uname;
							btn.name=objArr[x].type;
							btn.onclick = function(){DeleteUser(this.id,this.name)};  
							
							var pic = document.createElement("img");
							pic.src=objArr[x].picture;
							pic.id="Pic";

							tdPicture.appendChild(pic);
							tdName.innerHTML= objArr[x].fname+" "+objArr[x].lname;
							tdEmail.innerHTML= objArr[x].email;
							tdBirthDate.innerHTML= objArr[x].birthdate;
							tdGender.innerHTML= objArr[x].gender;
							tdAge.innerHTML= objArr[x].age;
							tdType.innerHTML= objArr[x].type;							
							tdDel.appendChild(btn);

							tr.appendChild(tdPicture);
							tr.appendChild(tdName);
							tr.appendChild(tdEmail);
							tr.appendChild(tdBirthDate);
							tr.appendChild(tdGender);
							tr.appendChild(tdAge);
							tr.appendChild(tdType);
							tr.appendChild(tdDel);


							document.getElementById("list").appendChild(tr);

						}     
		            }               
		          
			    };
				xmlhttp.open("GET", "../control/getUserRequest.php?task=1", false);
		        xmlhttp.send();
			}
			function gotoProfile()
			{
				window.location.href = "adminProfile.php";
			}
			function searchUser()
			{
				var value=document.getElementById("value").value;
				if(value=="")
				{
					loadUserList();
				}
				else
				{
					document.getElementById("list").innerHTML="";

					var thPicture= document.createElement("th");
					var thName= document.createElement("th");
					var thEmail= document.createElement("th");
					var thBirthdate= document.createElement("th");
					var thGender= document.createElement("th");
					var thAge= document.createElement("th");
					var thType= document.createElement("th");
					var thOperation= document.createElement("th");

					var trHeader = document.createElement("tr");
					thPicture.innerHTML="Picture";
					thName.innerHTML="Name";
					thEmail.innerHTML="Email";
					thBirthdate.innerHTML="Birthdate";
					thGender.innerHTML="Gender";
					thAge.innerHTML="Age";
					thType.innerHTML="Type";
					thOperation.innerHTML="Operation";

					trHeader.appendChild(thPicture);
					trHeader.appendChild(thName);
					trHeader.appendChild(thEmail);
					trHeader.appendChild(thBirthdate);
					trHeader.appendChild(thGender);
					trHeader.appendChild(thAge);
					trHeader.appendChild(thType);
					trHeader.appendChild(thOperation);

					document.getElementById("list").appendChild(trHeader);


					var key=document.getElementById("key").value;
					var xmlhttp = new XMLHttpRequest();
					xmlhttp.onreadystatechange = function() 
				 	{
			            if (this.readyState == 4 && this.status == 200) 
			            {
			                var objArr=	JSON.parse(this.responseText);
					        for(var x in objArr)
							{
								var tr = document.createElement("tr");

								var tdPicture = document.createElement("td");
								var tdName = document.createElement("td");
								var tdEmail = document.createElement("td");
								var tdBirthDate = document.createElement("td");
								var tdGender = document.createElement("td");
								var tdAge = document.createElement("td");
								var tdType = document.createElement("td");
								var tdDel = document.createElement("td");


								var btn = document.createElement("input"); 
								btn.type="button";
								btn.value="delete";
								btn.id=objArr[x].uname;
								btn.name=objArr[x].type;
								btn.onclick = function(){DeleteUser(this.id,this.name)};  
								
								var pic = document.createElement("img");
								pic.src=objArr[x].picture;
								pic.id="Pic";

								tdPicture.appendChild(pic);
								tdName.innerHTML= objArr[x].fname+" "+objArr[x].lname;
								tdEmail.innerHTML= objArr[x].email;
								tdBirthDate.innerHTML= objArr[x].birthdate;
								tdGender.innerHTML= objArr[x].gender;
								tdAge.innerHTML= objArr[x].age;
								tdType.innerHTML= objArr[x].type;							
								tdDel.appendChild(btn);

								tr.appendChild(tdPicture);
								tr.appendChild(tdName);
								tr.appendChild(tdEmail);
								tr.appendChild(tdBirthDate);
								tr.appendChild(tdGender);
								tr.appendChild(tdAge);
								tr.appendChild(tdType);
								tr.appendChild(tdDel);


								document.getElementById("list").appendChild(tr);
							}     
			            }               
			          
				    };
					xmlhttp.open("GET", "../control/getUserRequest.php?task=2&type="+key+"&value="+value, false);
			        xmlhttp.send();
				}			
				
			}
			function DeleteUser(value,type)
			{
				var key="uname";
			    var xmlhttp = new XMLHttpRequest();
				xmlhttp.onreadystatechange = function() 
			 	{
		            if (this.readyState == 4 && this.status == 200) 
		            {
		            	loadUserList();
		            }               
		          
			    };
				xmlhttp.open("GET", "../control/deleteUserRequest.php?task=1&type="+key+"&value="+value+"&utype="+type, false);
		        xmlhttp.send();
			}
		</script>
		<style type="text/css">
			#profilePic
			{
				border-radius: 50%;
				display: inline-block;
				width: 70px;
			}
			#Pic{
				border-radius: 50%;
				width: 50px;
			}
			#userName{
				display: inline-block;
			}
		</style>
	</head>
	
<body onload="loadUserList()">
		<form method="post">	
			<table border="1"    cellpadding="0" cellspacing="0"> 
				<tbody>
					<tr  >
						<td>
							<table>
								<tbody>
									<tr>
										 <td valign="top">
											<div onclick="gotoProfile()">
												<img src="" id="profilePic" class="profilePicClass">
												<p id="userName"></p>
												<script>
												document.getElementById("userName").innerHTML="<?php echo $_SESSION['fname']." ".$_SESSION['lname']?>";
												document.getElementById("profilePic").src="<?php echo $_SESSION['picture']?>";
												</script>
											</div>
										</td>
									</tr>
									<tr>
										 <td valign="top">
											<hr>
										</td>
									</tr>
									<tr>
										<td valign="top">
										 	<a href="addAdmin.php">Add Admin</a>
										</td>
									</tr>

									<tr>
										<td valign="top">
											<a href="addDoctor.php">Add Doctor</a>
										</td>
									</tr>

									<tr>
										<td valign="top">
											<a href="showUserList.php">Show User</a>
										</td>
									</tr>

									<tr>
										<td colspan="2" valign="top">
										 <a href="adminDashboardShowReport.php">Report</a>
										</td>
									</tr>
									<tr>
										<td colspan="2" valign="top">
											<a href="../Control/logout.php">logout</a>	
								
										</td>
									</tr>
								</tbody>
							</table>
						</td>	


						<td>
							<table>
								<tr>
									<td>
										<input type="text" id="value" placeholder="search" onkeydown="searchUser()">
										<select id="key">
											<option value="uname">User Name</option>
											<option value="fname">First Name</option>
											<option value="lname">Last Name</option>
										</select>
									</td>
								</tr>
								<tr>
									<table id="list">
										
									</table>
								</tr>
							</table>
							
						</td>	

					</tr>
				</tbody>
			</table>
		</form>			
	</body>
<html>
