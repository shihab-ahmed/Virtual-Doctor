<?php 
	session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>User Dashboard</title>
		<script type="text/javascript">
			function loadProfileInformation()
			{
				var xmlhttp = new XMLHttpRequest();
				var value = "<?php echo $_SESSION['uname']?>"
				var key = "uname";
			 	xmlhttp.onreadystatechange = function() 
			 	{
		            if (this.readyState == 4 && this.status == 200) 
		            {
		                var objArr=	JSON.parse(this.responseText);
						document.getElementById("name").innerHTML=objArr[0].fname+" "+objArr[0].lname;
						document.getElementById("uname").innerHTML=objArr[0].uname;
						document.getElementById("email").innerHTML=objArr[0].email;
						document.getElementById("birthdate").innerHTML=objArr[0].birthdate;
						document.getElementById("gender").innerHTML=objArr[0].gender;
						document.getElementById("age").innerHTML=objArr[0].age;
						
   
		            }               
		          
			    };
			    xmlhttp.open("GET", "../control/getUserRequest.php?task=2&type="+key+"&value="+value, false);
		        xmlhttp.send();
			}
			function gotoProfile()
			{
				window.location.href = "adminProfile.php";
			}
			function gotoChangeProfile()
			{
				window.location.href = "adminChangeProfile.php";
			}
		</script>
		<style type="text/css">
			#profilePic{
				width: 70px;
				height:70px;
				border-radius: 50%
			}
		</style>
</head>
<body onload="loadProfileInformation()">
	<table border="1">
		<tbody>
			<tr>
				<td>
					<table>
						<tbody>
							<tr>
								<td>
									<div onclick="gotoProfile()">
										<img src="" id="profilePic">
										<p id="userName"></p>
										<script>
										document.getElementById("userName").innerHTML="<?php echo $_SESSION['fname']." ".$_SESSION['lname']?>";
										document.getElementById("profilePic").src="<?php echo $_SESSION['picture']?>";
										</script>
									</div>
								</td>
							</tr>

							<tr>
								<td valign="top">
								 	<a href="addAdmin.php">Add Admin</a>
								</td>
							</tr>

							<tr>
								<td valign="top">
									<a href="addDoctor.php">Add Doctor</a>
								</td>
							</tr>

							<tr>
								<td valign="top">
									<a href="showUserList.php">Show User</a>
								</td>
							</tr>

							<tr>
								<td colspan="2" valign="top">
								 <a href="adminDashboardShowReport.php">Report</a>
								</td>
							</tr>
							<tr>
								<td colspan="2" valign="top">
								<a href="../Control/logout.php">logout</a>	
								</td>
							</tr>
						</tbody>
					</table>
				</td>
				<td >	
					<table>
						<tbody>
							<tr>
								<td>
									Name :
								</td>	
								<td>
									<p id="name"></p>
								</td>									
							</tr>
							<tr>
								<td>
									User Name :
								</td>	
								<td>
									<p id="uname"></p>
								</td>
							</tr>	

							<tr>
								<td>
									Email :
								</td>	
								<td>
									<p id="email"></p>
								</td>
							</tr>

							<tr>
								<td>
									Birthdate :
								</td>	
								<td>
									<p id="birthdate"></p>
								</td>
							</tr>

							<tr>
								<td>
									Gender :
								</td>	
								<td>
									<p id="gender"></p>
								</td>
							</tr>

							<tr>
								<td>
									Age :
								</td>	
								<td>
									<p id="age"></p>
								</td>
							</tr>
							<tr>
								<td colspan="2">
									<hr>
								</td>
							</tr>
							<tr>
								<td w>
									<input type="button" name="change" value="Change" onclick="gotoChangeProfile()">	
								</td>
							</tr>
						</tbody>
					</table>					
				
				</td>
			</tr>
		</tbody>
	</table>
</body>
</html>
