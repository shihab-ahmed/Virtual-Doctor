<?php 
session_start();

?>
<!DOCTYPE html>
<html>
<head>
	<title>User Dashboard</title>
	<style type="text/css">
		#chatContainer
		{
			width: 500px;
			height: 500px;
			background-color: #999;
		}
		#textBox
		{
			width: 400px;
		}
		#profilePic{
			width: 70px;
			border-radius: 50%;
		}
	</style>
	<script type="text/javascript">

		function loadContactList()
		{	
			document.getElementById("list").innerHTML="";

			var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function() 
		 	{
	            if (this.readyState == 4 && this.status == 200) 
	            {
	                var objArr=	JSON.parse(this.responseText);
			        for(var x in objArr)
					{
						var li = document.createElement("li");

						li.innerHTML=objArr[x].uname;							

						document.getElementById("contactList").appendChild(li);

					}     
	            }               
	          
		    };
		    var docUname="<?php echo $_SESSION['uname']; ?>"
			xmlhttp.open("GET", "../control/contactRequest.php?task=31&docUname="+docUname+"&status=accept", false);
	        xmlhttp.send();
	        loadPendingContact();
		}
		function loadPendingContact()
		{	
			document.getElementById("list").innerHTML="";

			var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function() 
		 	{
	            if (this.readyState == 4 && this.status == 200) 
	            {
	                var objArr=	JSON.parse(this.responseText);
			        for(var x in objArr)
					{
						var tr = document.createElement("tr");

						var tdName = document.createElement("td");
						var tdMessage = document.createElement("td");
						var tdBtnR = document.createElement("td");
						var tdBtnA = document.createElement("td");


						var btnA = document.createElement("input"); 
						btnA.type="button";
						btnA.value="Accept";
						btnA.id=objArr[x].uname;
						btnA.onclick=function(){AddToContact(this.id)};
						tdBtnA.appendChild(btnA);

						var btnR = document.createElement("input"); 
						btnR.type="button";
						btnR.value="Reject";
						tdBtnR.appendChild(btnR);


						tdName.innerHTML= objArr[x].uname;
						tdMessage.innerHTML= "Want be added in contact list";							
													
		
						tr.appendChild(tdName);
						tr.appendChild(tdMessage);
						tr.appendChild(tdBtnA);
						tr.appendChild(tdBtnR);


						document.getElementById("list").appendChild(tr);

					}     
	            }               
	          
		    };
		    var docUname="<?php echo $_SESSION['uname']; ?>"
			xmlhttp.open("GET", "../control/contactRequest.php?task=31&docUname="+docUname+"&status=pending", false);
	        xmlhttp.send();
		}
		function AddToContact(uname)
		{
			var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function() 
		 	{

	            if (this.readyState == 4 && this.status == 200) 
	            {
	            	alert(this.responseText);
	            	if(this.responseText=="1")alert(uname+" has been added to contact");    	
	            }
	        };
	        xmlhttp.open("GET", "../control/contactRequest.php?task=32&uname="+uname+"&status=accept", false);
	        xmlhttp.send();
		}
		function gotoDoctorContacts()
		{
			window.location.href = "doctorContactsRequest.php";
		}
		function gotoDoctorAppointments()
		{
			window.location.href = "doctorAppointmentRequest.php";
		}
		function gotoDoctorAppointments()
		{
			window.location.href = "doctorPrescription.php";
		}
	</script>
</head>
<body onload="loadContactList()">
	<table border="1">
		<tbody>
			<tr>
				<td>
					<table>
						<tbody>
							<tr>
								<td>
									<div>
										<img src="" id="profilePic">
										<p id="userName"></p>
										<script>
											document.getElementById("userName").innerHTML = "<?php echo $_SESSION['fname']; ?>";
											document.getElementById("profilePic").src = "<?php echo $_SESSION['picture']; ?>";

										</script>
									</div>
								</td>
							</tr>

							<tr>
								<td>
									<input type="text" name="" placeholder="Search">
								</td>
							</tr>
							<tr>
								<td>
									<ul id="contactList">
										
									</ul>
								</td>
							</tr>
							<tr>
								<td>
									<input type="button" value="Contacts" name="" onclick="gotoDoctorContacts()">
									<input type="button" value="Appointments" name="" onclick="gotoDoctorAppointments()">
									<input type="button" value="Prescription" name="" onclick="gotoDoctorAppointments()">
								</td>
							</tr>
						</tbody>
					</table>
				</td>
				<td>
					<table>
						<table>
								<tr>
									<td>
										<input type="text" id="value" placeholder="search" onkeydown="searchUser()">
										<select id="key">
											<option value="uname">User Name</option>
											<option value="fname">First Name</option>
											<option value="lname">Last Name</option>
										</select>
									</td>
								</tr>
								<tr>
									<table id="list">
										
									</table>
								</tr>
							</table>
					</table>
				</td>
			</tr>
		</tbody>
	</table>
</body>
</html>