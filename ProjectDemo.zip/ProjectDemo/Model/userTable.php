<?php
	include("connection.php");
	


	/*.......................................................................*/
	function addUser($fname,$lname,$uname,$email,$pass,$date,$gender,$file,$type,$previousYear)
	{
		$con = connection_start();
		$currentYear = date("Y");
	 	$age = $currentYear - $previousYear;	 	   
		$query="INSERT INTO user(fname,lname,uname,email,password,birthdate,gender,age,picture,type) VALUES ('$fname','$lname','$uname','$email','$pass','$date','$gender','$age','$file','$type')";
 		$result = mysqli_query($con, $query);
 		connection_close($con);
 		return $result;
 	}
 	function addAdmin($fname,$lname,$uname,$email,$pass,$date,$gender,$file,$type,$previousYear)
	{
		$con = connection_start();
		$currentYear = date("Y");
	 	$age = $currentYear - $previousYear;	 	   
		$query="INSERT INTO user(fname,lname,uname,email,password,birthdate,gender,age,picture,type) VALUES ('$fname','$lname','$uname','$email','$pass','$date','$gender','$age','$file','$type')";
 		$result = mysqli_query($con, $query);
 		connection_close($con);
 		return $result;
 	}
 	function addDoctor($fname,$lname,$uname,$email,$pass,$date,$gender,$file,$type,$previousYear,$category,$experience,$about)
	{
		$con = connection_start();
		$currentYear = date("Y");
	 	$age = $currentYear - $previousYear;	 	   
		$query="INSERT INTO user(fname,lname,uname,email,password,birthdate,gender,age,picture,type) VALUES ('$fname','$lname','$uname','$email','$pass','$date','$gender','$age','$file','$type')";
 		$result = mysqli_query($con, $query);
 		if($result)
 		{
 			$query2="INSERT INTO `doctor`(`docUname`, `specialist`, `experience`, `about`) VALUES ('$uname','$category',$experience,'$about')";
 			$result2 = mysqli_query($con, $query2);
 		}
 		connection_close($con);
 		return $result2;
 	}
 	/*.......................................................................*/
	function getUsers()
	{
		$con = connection_start();
		$query="SELECT id,fname,lname,uname,email,password,birthdate,gender,age,picture,type FROM `user`";
		$result = mysqli_query($con, $query);
		return $result;
		connection_close($con);			
	}
	function getDoctorDetailsFromDatabase()
	{
		$con = connection_start();
		$query="SELECT `id`, `docUname`, `specialist`, `experience`, `about` FROM `doctor`";
		$result = mysqli_query($con, $query);
		return $result;
		connection_close($con);			
	}
	function getDoctorDetailsByKeyValue()
	{
		$con = connection_start();
		$query="SELECT id,category,specialize FROM `doctor_category`";
 		$result = mysqli_query($con, $query);
 		connection_close($con);
 		return $result;
 	}
	function getDoctorCategory()
	{
		$con = connection_start();
		$query="SELECT id,category,specialize FROM `doctor_category`";
 		$result = mysqli_query($con, $query);
 		connection_close($con);
 		return $result;
 	}
	function getUsersByKeyValue($key,$value)
	{
		$con = connection_start();
		$query="SELECT id,fname,lname,uname,email,password,birthdate,gender,age,picture,type,picture FROM `user` WHERE $key LIKE '$value%'";
 		$result = mysqli_query($con, $query);
 		connection_close($con);
 		return $result;
 	}
 	function getSingleUsersByKeyValue($key,$value)
	{
		$con = connection_start();
		$query="SELECT id,fname,lname,uname,email,password,birthdate,gender,age,picture,type,picture FROM `user` WHERE $key='$value'";
 		$result = mysqli_query($con, $query);
 		connection_close($con);
 		return $result;
 	}
 	function GetExistedUser($type,$value)
 	{
 		$result =getUsersByKeyValue($type,$value);
 	    if ($result->num_rows > 0) 
		{
			return true;
		}
		else
		{
			return false;
		}
 	}
 	/*.......................................................................*/
 	function DeleteUserByKeyValue($key,$value,$type)
 	{	
		$con = connection_start();
		$query="DELETE FROM `user` WHERE $key='$value'";
 		$result = mysqli_query($con, $query);
 		if($type=="doctor" && $result)
 		{
 			$query2="DELETE FROM `doctor` WHERE $key='$value'";
 			$result2 = mysqli_query($con, $query2);
 			return $result2;
 		}
 		connection_close($con);
 		return $result;
 	}
 	/*.......................................................................*/
 	function updateUserProfile($fname,$lname,$uname,$email,$date,$gender,$file,$previousYear)
 	{	
		$con = connection_start();
		$currentYear = date("Y");
	 	$age = $currentYear - $previousYear;	 	   
		$query="UPDATE user SET fname='$fname',lname='$lname',email='$email',birthdate='$date',`gender`='$gender',`age`='$age',`picture`='$file' WHERE uname='$uname'";

 		$result = mysqli_query($con, $query);
 		connection_close($con);
 		return $result;
 	}
 	
 	function updateUserPassword($pass,$uname)
 	{	
		$con = connection_start();	 	   
		$query="UPDATE user SET password='$pass' WHERE uname='$uname'";
 		$result = mysqli_query($con, $query);
 		connection_close($con);
 		return $result;
 	}
    /*.......................................................................*/
 	function varifyUser($type,$value,$pass)
 	{
 		$isvalid=false;
 		$result =getSingleUsersByKeyValue($type,$value);
		if ($result->num_rows > 0) 
		{
			
			$row = mysqli_fetch_assoc($result);

			if($row['password']==md5($pass))
			{
				$isvalid=true;
				$_SESSION['id']  =$row['id'];
	    		$_SESSION['fname']=$row['fname'];
	   			$_SESSION['lname']=$row['lname'];
	    		$_SESSION['uname']=$row['uname'];
	    		$_SESSION['email']  =$row['email'];
	    		$_SESSION['birthdate']=$row['birthdate'];
	   			$_SESSION['gender']=$row['gender'];
	    		$_SESSION['age']=$row['age'];
	    		$_SESSION['type']=$row['type'];
	    		$_SESSION['picture']=$row['picture'];
	    		$_SESSION['password']=$row['password'];
	    
			}
		}
		else if($_POST['unameText']=="admin" && $_POST['passText']=="admin")
	 	{
	 		$_SESSION['type']="admin";
	 		$_SESSION['fname']="Default";
	 		$_SESSION['lname']="Admin";
	 		$_SESSION['uname']  ="admin";
	 		$_SESSION['id']  =0;
	 		$_SESSION['email']  ="";
    		$_SESSION['birthdate']="";
   			$_SESSION['gender']="";
    		$_SESSION['age']=0;
	 		$isvalid=true;
	 	}
	 	return $isvalid;					
			
	}
	
?>