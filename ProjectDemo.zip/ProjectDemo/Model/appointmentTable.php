<?php
	include("connection.php");

	function addAppointment($docUname,$userUname,$startDate,$endDate,$message,$status)
	{
		$con = connection_start();	 	   
		$query="INSERT INTO `appointment`(`docUname`, `userUname`, `startDate`, `endDate`, `message`, `status`) VALUES ('$docUname','$userUname','$startDate','$endDate','$message','$status')";
 		$result = mysqli_query($con, $query);
 		connection_close($con);
 		return $result;
 	}
 	function getAppointmentByID($docUname,$status)
	{
		$con = connection_start();	 	   
		$query="SELECT `id`, `docUname`, `userUname`, `startDate`, `endDate`, `message`, `status` FROM `appointment` WHERE docUname='$docUname' AND status='$status'";
 		$result = mysqli_query($con, $query);
 		connection_close($con);
 		return $result;
 	}
 	function getAppointmentForByID($type,$name,$status)
 	{
 		$con = connection_start();	 	   
		$query="SELECT `id`, `docUname`, `userUname`, `startDate`, `endDate`, `message`, `status` FROM `appointment` WHERE $type='$name' AND status='$status'";
 		$result = mysqli_query($con, $query);
 		connection_close($con);
 		return $result;
 	}
 	function updateSingleAppointmentById($uname,$status)
	{
		$con = connection_start();	 	   
		$query="UPDATE `appointment` SET `status`='$status' WHERE userUname='$uname'";
 		$result = mysqli_query($con, $query);
 		connection_close($con);
 		return $result;
 	}
 	
?>