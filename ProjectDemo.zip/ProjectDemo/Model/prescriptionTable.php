<?php
	include("connection.php");

	function addPrescriptionInTable($docName,$uname,$description,$status,$date)
	{
		$con = connection_start();	 	   
		$query="INSERT INTO `prescription`(`docU`, `user`, `description`, `status`, `date`) VALUES ('$docName','$uname','$description','$status','$date')";
 		$result = mysqli_query($con, $query);
 		connection_close($con);
 		return $result;
 	}
 	function getAllPrescriptionByIdFromTable($key,$value)
 	{
 		$con = connection_start();	 	   
		$query="SELECT `id`, `docU`, `user`, `description`, `status`, `date` FROM `prescription` WHERE $key='$value'";
 		$result = mysqli_query($con, $query);
 		connection_close($con);
 		return $result;
 	}
 	function updateSingleAppointmentById($uname,$status)
	{
		$con = connection_start();	 	   
		$query="UPDATE `appointment` SET `status`='$status' WHERE userUname='$uname'";
 		$result = mysqli_query($con, $query);
 		connection_close($con);
 		return $result;
 	}
 	
?>