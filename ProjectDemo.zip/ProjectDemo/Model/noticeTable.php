<?php
	function addNotice($about,$state,$type,$notice_id,$isSeenDoctor,$isSeenUser)
	{
		$con = connection_start();	 	   
		$query="INSERT INTO `notification`(`about`, `stat`, `type`, `notice_id`, `isSeenDoctor`, `isSeenUser`) VALUES ('$about','$state','$type','$notice_id','$isSeenDoctor','$isSeenUser')";
 		$result = mysqli_query($con, $query);
 		connection_close($con);
 		return $result;
 	}
?>