<?php
	include("connection.php");

	function addContact($docUname,$uname,$status)
	{
		$con = connection_start();	 	   
		$query="INSERT INTO `contactlist`(`uname`, `docname`, `status`) VALUES ('$uname','$docUname','$status')";
 		$result = mysqli_query($con, $query);
 		connection_close($con);
 		return $result;
 	}
 	function getAllContactsById($docUname,$status)
	{
		$con = connection_start();	 	   
		$query="SELECT `id`, `uname`, `docname`, `status` FROM `contactlist` WHERE docname='$docUname' AND status='$status'";
 		$result = mysqli_query($con, $query);
 		connection_close($con);
 		return $result;
 	}
 	function getAllContactsForUserById($uname,$status,$seen)
	{
		$con = connection_start();	 	   
		$query="SELECT `id`, `uname`, `docname`, `status`,isSeenUser FROM `contactlist` WHERE uname='$uname' AND status='$status' AND isSeenUser='$seen'";
 		$result = mysqli_query($con, $query);
 		connection_close($con);
 		return $result;
 	}
 	function updateSingleContactById($uname,$status)
	{
		$con = connection_start();	 	   
		$query="UPDATE `contactlist` SET `status`='$status' WHERE uname='$uname'";
 		$result = mysqli_query($con, $query);
 		connection_close($con);
 		return $result;
 	}
 	function updateSeenStatusById($uname,$docUname,$seen)
	{

		$con = connection_start();	 	   
		$query="UPDATE `contactlist` SET `isSeenUser`='$seen' WHERE docname='$docUname' AND uname='$uname'";
 		$result = mysqli_query($con, $query);
 		connection_close($con);

 		return $result;
 	}
 	function getContactByID($docUname,$userUname)
 	{
 		$con = connection_start();	 	   
		$query="SELECT `id`, `uname`, `docname`, `status` FROM `contactlist` WHERE docname='$docUname' AND uname='$userUname'";
 		$result = mysqli_query($con, $query);
 		connection_close($con);
 		return $result;
 	}
?>