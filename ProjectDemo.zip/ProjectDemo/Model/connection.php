<?php
	function connection_start()
	{
		try
		{
			$con = mysqli_connect("localhost", "root", "","vdocstorage");
			return $con;
		}
		catch(Exception $e)
		{
			die("Connection failed: " . mysqli_connect_error());
		}
		
	}
	function connection_close($con)
	{
		mysqli_close($con);
	}
	
?>