<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
 	this is admin dashboard
</body>
</html>