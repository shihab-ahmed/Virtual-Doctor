<?php 
session_start();

?>
<!DOCTYPE html>
<html>
<head>
	<title>User Dashboard</title>
	<style type="text/css">
		#chatContainer
		{
			width: 500px;
			height: 500px;
			background-color: #999;
		}
		#textBox
		{
			width: 400px;
		}
	</style>
	<script type="text/javascript">
		function includeProfile()
		{
			var key = "uname";
			var value = "<?php echo $_SESSION['uname']?>";
			var task="1";
			var xmlhttp = new XMLHttpRequest();

	        xmlhttp.onreadystatechange = function()
	        {
	            if (this.readyState == 4 && this.status == 200)
	            {
	            	
	                var objArr=	JSON.parse(this.responseText);
	               
	                document.getElementById("userName").innerHTML=objArr[0].fname+" "+objArr[0].lname;	
	                loadDoctorList();				
	            }
	        };
	         xmlhttp.open("GET","../../request/userProfileRequest?task=1&value="+value+"&key="+key, false);
	        xmlhttp.send();
		}
		function loadDoctorDetails()
		{
			var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function() 
		 	{
	            if (this.readyState == 4 && this.status == 200) 
	            {
	                objArr=JSON.parse(this.responseText);
	                 
	                for(var x in objArr)
	               	{
	               		
	               		var tdSpecialist = document.createElement("td");
	               		var tdStatus = document.createElement("td");

	               		tdSpecialist.innerHTML=objArr[x].specialist;
	               		document.getElementById(objArr[x].docUname).appendChild(tdSpecialist);

	               		var btn = document.createElement("input"); 
						btn.type="button";
						btn.value="Veiw Details";
						btn.id=objArr[x].docUname;
						tdStatus.appendChild(btn);
						btn.onclick = function(){doctorViewDetails(this.id)};

						document.getElementById(objArr[x].docUname).appendChild(tdStatus);
	               	}
	            }              
		    };
		    
			xmlhttp.open("GET", "../../request/userDoctorRequest.php?task=2", true);
	        xmlhttp.send();
		}
		function doctorViewDetails(docUname)
		{
			window.location.href="userViewDoctorDetails.php?docUname="+docUname;
		}
		function loadDoctorList()
		{	
			document.getElementById("list").innerHTML="";

			var xmlhttp = new XMLHttpRequest();
			var key="type";
			var value="doctor";
			xmlhttp.onreadystatechange = function() 
		 	{
	            if (this.readyState == 4 && this.status == 200) 
	            {
	                var objArr=	JSON.parse(this.responseText);
			        for(var x in objArr)
					{
						var tr = document.createElement("tr");
						var tdfname = document.createElement("td");
					    var tdGender = document.createElement("td");

						tdfname.innerHTML= objArr[x].fname+""+objArr[x].lname;
						tdGender.innerHTML= objArr[x].gender;

						tr.appendChild(tdfname);
						tr.appendChild(tdGender);

						tr.id=objArr[x].uname;
						document.getElementById("list").appendChild(tr);

					}
				loadDoctorDetails();     
	            }               
	          
		    };
			xmlhttp.open("GET", "../../request/userDoctorRequest.php?task=1&key="+key+"&value="+value, true);
	        xmlhttp.send();
		}
		
	</script>
</head>
<body onload="includeProfile()">
	<table border="1">
		<tbody>
			<tr>
				<td>
					<table>
						<tbody>
							<tr>
								<td>
									<div>
										<img src="" id="profilePic">
										<p id="userName"></p>
									</div>
								</td>
							</tr>

							<tr>
								<td>
									<input type="text" name="" placeholder="Search">
								</td>
							</tr>
							<tr>
								<td>
									<ul id="contactList">
										
									</ul>
								</td>
							</tr>
							<tr>
								<td>
									<ul>
										<li onclick="gotoUserDoctor()">Doctor</li>
										<li onclick="gotoUserAppoinment()">Appoinment</li>
										<li onclick="gotoUserContact()">Contact</li>
										<li onclick="gotoUserPrescription()">Prescription</li>
										<li onclick="gotoLogout()">Logout</li>
									</ul>
								</td>
							</tr>
						</tbody>
					</table>
				</td>
				<td>
					<table>
						<tr>
							<td>
								<input type="text" id="value" placeholder="search" onkeydown="searchUser()">
								<select id="key">
									<option value="fname">First Name</option>
									<option value="lname">Last Name</option>
									<option value="type">Type</option>
									<option value="gender">Gender</option>
								</select>
								<select id="category" name="category">
									<option>Audiologist</option>
									<option>Allergist</option>
									<option>Dentist</option>
									<option>Endocrinologists</option>
									<option>Gynecologist</option>
									<option>Neonatologist</option>
									<option>Neurologist</option>
									<option>Surgeon</option>
								</select>
							</td>
						</tr>
						<tr>
							<table id="list" border="1">
								
							</table>
						</tr>
					</table>
				</td>
			</tr>
		</tbody>
	</table>
</body>
</html>