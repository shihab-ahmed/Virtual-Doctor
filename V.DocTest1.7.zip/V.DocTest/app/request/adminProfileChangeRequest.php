<?php
	define('APP_ROOT', "$_SERVER[DOCUMENT_ROOT]/V.DocTest");
	$Root=APP_ROOT;
	require_once(APP_ROOT."/core/core_service.php");
	session_start();
?>
<?php
	if($_SERVER['REQUEST_METHOD']=="POST")
	{
		$isValid = true;
		if (validateFirstName(test_input($_POST['fname'])))$fname = test_input($_POST['fname']);
		else
		{
			$isValid = false;
		}
		if (validateLastName(test_input($_POST['lname'])))$lname = test_input($_POST['lname']);
		else
		{
			$isValid = false;
		}
		if (validateEmail($_POST['email']))$email = test_input($_POST['email']);
		else
		{
			$isValid = false;
		}
		if (validateDate($_POST['date']))$date = test_input($_POST['date']);
		else
		{
			$isValid = false;
		}
		if (validateGender())$gender = test_input($_POST['gender']);
		else
		{
			$isValid = false;
		}
		if (validateImage())$file = $_POST['target_file'];
		else
		{
			$isValid = false;
		}
		echo $_SESSION['picture'];
		$type = "user";
		if($isValid)
		{

			
			if(updateUserProfile($fname,$lname,$_SESSION['uname'],$email,$date,$gender,$file,$_POST['previousYear']))
			{
			  if(move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $file)) 
			    {
			        echo "your account has been updated";
			      	//header("Location: ../view/reg.php?status=1");

			    }
			    else
			    {
			        //echo "Sorry, there was an error uploading your file.";
			    }
				
			}
			else
			{
				echo "Account creation failed";
			}
		}
		function setUserInformationToSession($user)
		{
			
			$_SESSION['fname']=$user['fname'];
			$_SESSION['lname']=$user['lname'];
			
			$_SESSION['email']  =$user['email'];
			$_SESSION['birthdate']=$user['birthdate'];
			$_SESSION['gender']=$user['gender'];
			$_SESSION['age']=$user['age'];
		
			$_SESSION['picture']=$user['picture'];
			
		}
	}	
?>