<?php
	function RequestHandler()
	{
		if($_SERVER['REQUEST_METHOD']=="POST")
		{
			$isValid = true;
			
			if (validateFirstName(test_input($_POST['fname'])))$fname = test_input($_POST['fname']);
			else
			{
				$isValid = false;
			}
			if (validateLastName(test_input($_POST['lname'])))$lname = test_input($_POST['lname']);
			else
			{
				$isValid = false;
			}
			if (validateUserName($_POST['uname']) && !GetNameTaken("uname",$_POST['uname']))$uname = test_input($_POST['uname']);
			else
			{
				$isValid = false;
			}
			if (validateEmail($_POST['email']))$email = test_input($_POST['email']);
			else
			{
				$isValid = false;
			}
			if (validateDate($_POST['date']))$date = test_input($_POST['date']);
			else
			{
				$isValid = false;
			}
			if (validateGender())$gender = test_input($_POST['gender']);
			else
			{
				$isValid = false;
			}
			if (validatePassword($_POST['pass'],$_POST['cpass']))$pass = md5(test_input($_POST['pass']));
			else
			{
				$isValid = false;

			}
			if (validateImage())$file = $_POST['target_file'];
			else
			{
				$isValid = false;
				echo "string";
			}
			$type = $_COOKIE['adminPanel'];
			if($type=="doctor")
			{
				if(isset($_POST['category']))$category = $_POST['category'];
				else
				{
					$isValid=false;
				}
				if(isset($_POST['experience']))
				{
					if(validateYearsOfExperience($_POST['experience']))
					{
						$experience = $_POST['experience'];
					}
					else
					{
						$isValid = false;
					}
				}
				else
				{
					$isValid=false;
				}
				if(isset($_POST['about']))$about = $_POST['about'];
				else
				{
					$isValid=false;
				}
			}

			if($isValid)
			{
				
				if($type=="doctor")
				{

					if(addDoctor($fname,$lname,$uname,$email,$pass,$date,$gender,$file,$type,$_POST['previousYear'],$category,$experience,$about))
					{
						echo "all ok";
						if(move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $file)) 
					    {
					        echo "your account has been created";
					       	$_SESSION['success']=1;
					       
					    }
					    else
					    {
					        //echo "Sorry, there was an error uploading your file.";
					    }
					}
					else
					{

					}
				}
				else
				{
					if(addUser($fname,$lname,$uname,$email,$pass,$date,$gender,$file,$type,$_POST['previousYear']))
					{
					  if(move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $file)) 
					    {
					        echo "your account has been created";
					        $_SESSION['success']=1;
					       // $_SERVER['REQUEST_METHOD']="GasdET";
					    }
					    else
					    {
					        //echo "Sorry, there was an error uploading your file.";
					    }
						
					}
					else
					{
						//echo "Account creation failed";
					}
				}
				
			}
			
		}
	}	
 ?>