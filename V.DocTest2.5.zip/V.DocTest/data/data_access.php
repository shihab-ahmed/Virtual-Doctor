﻿<?php require_once(APP_ROOT."/lib/data_access_helper.php");?>

<?php
	function getUserByKeyValueFromDb($key,$value)
	{	
		$query = "SELECT `id`, `fname`, `lname`, `uname`, `email`, `password`, `birthdate`, `gender`, `age`, `picture`, `type` FROM `user` WHERE $key='$value'";  
		$result = executeQuery($query);	

		$user = null;
		if($result){

			$user = mysqli_fetch_assoc($result);
		}
		return $user;
	}
	function getUserByKeyValueJSONFromDb($key,$value)
	{	
		$query = "SELECT `id`, `fname`, `lname`, `uname`, `email`, `password`, `birthdate`, `gender`, `age`, `picture`, `type` FROM `user` WHERE $key='$value'";  
		$result = executeQuery($query);	
		return $result;
	}
	function addUserToDb($fname,$lname,$uname,$email,$pass,$date,$gender,$file,$type,$previousYear)
	{
		$currentYear = date("Y");
	 	$age = $currentYear - $previousYear;	 	   
		$query="INSERT INTO user(fname,lname,uname,email,password,birthdate,gender,age,picture,type) VALUES ('$fname','$lname','$uname','$email','$pass','$date','$gender','$age','$file','$type')";
 		$result = executeQuery($query);	
 		return $result;
 	}
 	function addDoctorToDb($fname,$lname,$uname,$email,$pass,$date,$gender,$file,$type,$previousYear,$category,$experience,$about)
	{
		$currentYear = date("Y");
	 	$age = $currentYear - $previousYear;	 	   
		$query="INSERT INTO user(fname,lname,uname,email,password,birthdate,gender,age,picture,type) VALUES ('$fname','$lname','$uname','$email','$pass','$date','$gender','$age','$file','$type')";
 		$result = executeQuery($query);	
 		if($result)
 		{
 			$query2="INSERT INTO `doctor`(`docUname`, `specialist`, `experience`, `about`) VALUES ('$uname','$category',$experience,'$about')";
 			$result2 = executeQuery($query2);	
 		}
 		return $result2;
 	}
	function GetNameTakenFromDb($key,$value)
 	{
 	
 		$query = "SELECT `id`, `fname`, `lname`, `uname`, `email`, `password`, `birthdate`, `gender`, `age`, `picture`, `type` FROM `user` WHERE $key='$value'";  
		$result = executeQuery($query);	
 	    if ($result->num_rows > 0) 
		{
			return true;
		}
		else
		{
			return false;
		}
 	}
 	function DeleteUserByKeyValueFromDb($key,$value,$type,$pic)
 	{	
		$query="DELETE FROM `user` WHERE $key='$value'";
 		$result = executeQuery($query);	
 		if($type=="doctor" && $result)
 		{
 			$query2="DELETE FROM `doctor` WHERE docUname='$value'";
 			$result2 = executeQuery($query2);	
 			return $result2;
 		}
 		if (file_exists($pic)) 
		{
		    unlink($pic);
		}
		if($type=="doctor")return $result2;		
 		else
 			return $result;
 	}
 	function getUserByKeyValueUsingLikeFromDb($key,$value)
	{
		
		$query="SELECT id,fname,lname,uname,email,password,birthdate,gender,age,picture,type,picture FROM `user` WHERE $key LIKE '$value%'";  
		$result = executeQuery($query);	
		return $result;
	}
 	function getAllUserFromDb()
	{
		$query="SELECT id,fname,lname,uname,email,password,birthdate,gender,age,picture,type FROM `user`";
		$result = executeQuery($query);	
		return $result;
	}
	function updateUserProfileToDb($fname,$lname,$uname,$email,$date,$gender,$file,$previousYear)
 	{	
		$currentYear = date("Y");
	 	$age = $currentYear - $previousYear;	 	   
		$query="UPDATE user SET fname='$fname',lname='$lname',email='$email',birthdate='$date',`gender`='$gender',`age`='$age',`picture`='$file' WHERE uname='$uname'";

 		$result = executeQuery($query);
 		if (file_exists($_SESSION['picture'])) 
		{
		    unlink($_SESSION['picture']);
		}		
 		return $result;
 	}
 	
 	function updateUserPasswordToDb($pass,$uname)
 	{		   
		$query="UPDATE user SET password='$pass' WHERE uname='$uname'";
 		$result = executeQuery($query);
 		return $result;
 	}
 	function getDoctorDetailsFromDatabase()
	{
		$query="SELECT `id`, `docUname`, `specialist`, `experience`, `about` FROM `doctor`";
		$result = executeQuery($query);
		return $result;	
	}
	function getDoctorDetailsUsingKeyValueFromDatabase($key,$value)
	{
		
		$query="SELECT `id`, `docUname`, `specialist`, `experience`, `about` FROM `doctor` WHERE $key='$value'";
		$result = executeQuery($query);
		
		return $result;	
	}
	function sendContactRequestToDoctorToDb($uname,$docname,$status,$isSeenUser,$isSeen)
	{
		$query="INSERT INTO `contactlist`(`uname`, `docname`, `status`, `isSeenUser`, `isSeen`) VALUES ('$uname','$docname','$status','$isSeenUser','$isSeen')";
		$result = executeQuery($query);
		return $result;
	}
	function addAppointmentToDb($docUname,$uname,$startDate,$endDate,$message,$status,$isSeenUser)
	{	 	   
		$query="INSERT INTO `appointment`(`docUname`, `userUname`, `startDate`, `endDate`, `message`, `status`,`isSeenUser`) VALUES ('$docUname','$uname','$startDate','$endDate','$message','$status','$isSeenUser')";
		echo $query;
 		$result = executeQuery($query);
 		return $result;
 	}
 	function getContactListUsingDoubleKeyFromDb($key,$value,$key2,$value2)
 	{
 		$query="SELECT `id`, `uname`, `docname`, `status`, `isSeenUser`, `isSeen` FROM `contactlist` WHERE $key='$value' AND $key2='$value2'";
 		$result = executeQuery($query);
 		return $result;
 		
 	}
 	function getContactListFromDb($key,$value)
 	{
 		$query="SELECT `id`, `uname`, `docname`, `status`, `isSeenUser`, `isSeen` FROM `contactlist` WHERE $key='$value'";
 		$result = executeQuery($query);
 		return $result;
 		
 	}
 	function getAppointmentListUsingDoubleKeyFromDb($key,$value,$key2,$value2)
 	{
 		$query="SELECT `id`, `docUname`, `userUname`, `startDate`, `endDate`, `message`, `status`, `isSeenUser` FROM `appointment` WHERE $key='$value' AND $key2='$value2'";
 		$result = executeQuery($query);
 		return $result;
 		
 	}
 	function getPrescriptionListFromDb($key,$value)
 	{
 		$query="SELECT `id`, `docU`, `user`, `description`, `status`, `date`, `isSeenUser` FROM `prescription` WHERE $key='$value'";
 		$result = executeQuery($query);
 		return $result;
 		
 	}
 	function getDoctorListUsingDoubleKeyFromDb($key,$value,$key2,$value2)
 	{
 		$query="SELECT `id`, `uname`, `docname`, `status`, `isSeenUser`, `isSeen` FROM `contactlist` WHERE $key LIKE '$value%' AND $key2='$value2'";
 		$result = executeQuery($query);
 		return $result;
 		
 	}
 	function addChatToDb($sender,$reciever,$message)
	{	 	   
		$query="INSERT INTO `chatlog`(`sender`, `reciever`, `message`) VALUES ('$sender','$reciever','$message')";
 		$result = executeQuery($query);	
 		return $result;
 	}
 	function getChatFromDb($sender,$reciever)
	{	 	   
		$query="SELECT id, sender, reciever, message FROM chatlog WHERE sender='$sender' AND reciever='$reciever' OR sender='$reciever' AND reciever='$sender' ORDER BY id ASC";
 		$result = executeQuery($query);	
 		return $result;
 	}
 	function updateContactListToDb($uname,$docname,$status,$isSeenUser)
 	{
 		$query="UPDATE `contactlist` SET `status`='$status',`isSeenUser`='$isSeenUser' WHERE uname='$uname' AND docname='$docname'";
 		$result = executeQuery($query);	
 		return $result;
 	}
 	function updateContactListById($key,$value,$id)
 	{
 		$query="UPDATE `contactlist` SET $key='$value' WHERE id=$id";
 		$result = executeQuery($query);	
 		return $result;
 	}
 	function deleteContactListFromDb($uname,$docname)
 	{
 		$query="DELETE FROM `contactlist` WHERE uname='$uname' AND docname='$docname'";
 		$result = executeQuery($query);	
 		return $result;
 	}
 	function addPrescriptionToDb($docName,$uname,$description,$status,$date,$isSeenUser)
	{ 	   
		$query="INSERT INTO `prescription`(`docU`, `user`, `description`, `status`, `date`, `isSeenUser`) VALUES ('$docName','$uname','$description','$status','$date','$isSeenUser')";
 		$result = executeQuery($query);	
 		return $result;
 	}
 	function getAllPrescriptionFromDb($key,$value)
 	{ 	   
		$query="SELECT `id`, `docU`, `user`, `description`, `status`, `date` FROM `prescription` WHERE $key='$value'";
 		$result = executeQuery($query);	
 		return $result;
 	}
 	function updatePrescriptionToDb($key,$value,$id)
	{ 	   
		$query="UPDATE `prescription` SET $key='$value' WHERE id=$id";
 		$result = executeQuery($query);	
 		return $result;
 	}
 	function updateContactToDb($key,$value,$id)
	{ 	   
		$query="UPDATE `contactlist` SET $key='$value' WHERE id=$id";
 		$result = executeQuery($query);	
 		return $result;
 	}
 	function updateAppointmentToDb($uname,$docname,$isSeenUser)
 	{
 		$query="UPDATE `appointment` SET `isSeenUser`='$isSeenUser' WHERE userUname='$uname' AND docUname='$docname'";
 		$result = executeQuery($query);	
 		return $result;
 	}

?>