<?php 
	define('APP_ROOT', "$_SERVER[DOCUMENT_ROOT]/V.DocTest");

	session_start();
	$_SESSION['frontController']=true;
	header("Location: app/view/login.php?root=".APP_ROOT);	
	

?>