<html>
<head>
	<link rel="stylesheet" href="css/login.css"/>
	<script type="text/javascript">
	
	</script>
</head>
<body>
	<div id="login">
		<form method="post" action="../request/loginRequest.php">
			<h2>Sign In</h2>
			<input type="text" id="username" name="unameText" placeholder="Enter Username" class="textInput" />
			<br>
			<input type="password" id="password" name="passText" placeholder="Enter password" class="textInput" />
			<br>
			<a href="reg.php" id="createAccount">Don't Have Account ?</a>
				<input type="submit" id="login-btn" value="Sign In" onclick="seeError()" />
			<br>
			<div id="error">
				<?php 
				if(isset($_REQUEST['status']))
				{
					if($_REQUEST['status']==0)
					{
						echo "login failed";
					}
				}
				?>
			</div>
		</form>
	</div>	
	</body>
<html>