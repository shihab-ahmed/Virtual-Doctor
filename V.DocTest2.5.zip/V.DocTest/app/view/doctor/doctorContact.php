<?php 
session_start();

?>
<!DOCTYPE html>
<html>
<head>
	<title>User Dashboard</title>
	<script type="text/javascript">
		function includeProfile()
		{
			var key = "uname";
			var value = "<?php echo $_SESSION['uname']?>";
			var task="1";
			var xmlhttp = new XMLHttpRequest();
		
	        xmlhttp.onreadystatechange = function()
	        {
	            if (this.readyState == 4 && this.status == 200)
	            {
	                var objArr=	JSON.parse(this.responseText);
	               
	                document.getElementById("userName").innerHTML=objArr[0].fname+" "+objArr[0].lname;
                	
					loadContactList();
	            }
	        };
	        xmlhttp.open("GET","../../request/userProfileRequest?task=1&value="+value+"&key="+key, false);
	        xmlhttp.send();
		}
		/*----Contact start-----*/
		function loadContactList()
		{
			var key = "docname";
			var value = "<?php echo $_SESSION['uname']?>";
			var xmlhttp = new XMLHttpRequest();
			document.getElementById("list").innerHTML="";
	        xmlhttp.onreadystatechange = function()
	        {
	            if (this.readyState == 4 && this.status == 200)
	            {
	            	 var objArr=JSON.parse(this.responseText);
	            	 document.getElementById("contactList").innerHTML="";
	            	 for(var x in objArr)
	            	 {
	            	 	loadSelectedUserInformation(objArr[x].uname,objArr[x].status);	            	 	
	            	 }
	            	 loadContactNotification(objArr);
					
	            }
	        };
	        xmlhttp.open("GET","../../request/doctorProfileRequest?task=6&key="+key+"&value="+value, true);
	        xmlhttp.send();
		}
		function loadSelectedUserInformation(uname,status)
		{
			var key = "uname";
			var xmlhttp = new XMLHttpRequest();


	        xmlhttp.onreadystatechange = function()
	        {
	            if (this.readyState == 4 && this.status == 200)
	            {
	            	var objArr=JSON.parse(this.responseText);
	            	if(status=="accept")
	            	{
	            		var li=document.createElement("li");
	            	 	li.innerHTML=objArr[0].fname+" "+objArr[0].lname;
	            	 	li.id=objArr[0].uname;

	            	 	li.onclick=function(){gotoUserChatBox(this.id)};
	            	 	document.getElementById("contactList").appendChild(li);
	            	}
	            	else if(status=="pending")
	            	{
	            		var tr=document.createElement("tr");
            	 		var tdName=document.createElement("td");
            	 		var tdMessage=document.createElement("td");
            	 		var tdStatus=document.createElement("td");
            	 		var tdStatus2=document.createElement("td");

            	 		tdName.innerHTML=objArr[0].fname+" "+objArr[0].lname;
            	 		tdMessage.innerHTML="is requesting to be added in contact";
            	 		
            	 		var btnSeen=document.createElement("input");
            	 		btnSeen.type="button";
            	 		btnSeen.value="Accept";
            	 		btnSeen.id=uname;
            	 		btnSeen.onclick=function(){AddToContact(this.id)};

            	 		var btnReject=document.createElement("input");
            	 		btnReject.type="button";
            	 		btnReject.value="Reject";
            	 		btnReject.id=uname;
        				btnReject.onclick=function(){RejectContact(this.id)};
            	 		
            	 		tdStatus.appendChild(btnSeen);
            	 		tdStatus2.appendChild(btnReject);


            	 		tr.appendChild(tdName);
            	 		tr.appendChild(tdMessage);
            	 		tr.appendChild(tdStatus);
            	 		tr.appendChild(tdStatus2);

	            	 	document.getElementById("list").appendChild(tr);
	            	}
	            }
	        };
	        xmlhttp.open("GET","../../request/doctorProfileRequest?task=3&key="+key+"&value="+uname, true);
	        xmlhttp.send();
		}
		function AddToContact(uname)
		{
			var docname = "<?php echo $_SESSION['uname']?>";
			var status="accept";
			var isSeenUser="0"
			var xmlhttp = new XMLHttpRequest();


	        xmlhttp.onreadystatechange = function()
	        {
	            if (this.readyState == 4 && this.status == 200)
	            {
	            	alert(this.responseText);
	            	loadContactList();
	            }
	        };
	        xmlhttp.open("GET","../../request/doctorProfileRequest?task=7&uname="+uname+"&docname="+docname+"&status="+status+"&isSeenUser="+isSeenUser, true);
	        xmlhttp.send();
		}
		function RejectContact(uname)
		{
			var docname = "<?php echo $_SESSION['uname']?>";
			var xmlhttp = new XMLHttpRequest();

			
	        xmlhttp.onreadystatechange = function()
	        {
	            if (this.readyState == 4 && this.status == 200)
	            {
	            	alert(this.responseText);
	            	loadContactList();
	            }
	        };
	        xmlhttp.open("GET","../../request/doctorProfileRequest?task=8&uname="+uname+"&docname="+docname, true);
	        xmlhttp.send();
		}
		function loadContactNotification(objArr)
		{
			var count=0;
			for(var x in objArr)
			{

				if(objArr[0].status=="pending")
				{
					count=count+1;
					
				}
			}
			if(count>0)document.getElementById("Contact").innerHTML="Contact"+count;
			else
			{

				document.getElementById("Contact").innerHTML="Contact";
			}
			

		}
		/*----Contact end-----*/
	</script>
</head>
<body onload="includeProfile()">
	<table border="1">
		<tbody>
			<tr>
				<td>
					<table>
						<tbody>
							<tr>
								<td>
									<div onclick="gotoProfile()">
										<img src="" id="profilePic">
										<p id="userName"></p>
										
									</div>
								</td>
							</tr>

							<tr>
								<td>
									<input type="text" name="" placeholder="Search">
								</td>
							</tr>
							<tr>
								<td>
									<p>Contact List</p>
									<ul id="contactList">
										
									</ul>
								</td>
							</tr>
							<tr>
								<td>
									<ul>
										<li onclick="gotoUserAppoinment()">Appoinment</li>
										<li onclick="gotoUserContact()" id="Contact">Contact</li>
										<li onclick="gotoUserPrescription()">Prescription</li>
										<li onclick="gotoLogout()">Logout</li>
									</ul>
								</td>
							</tr>
						</tbody>
					</table>
				</td>
				<td>
					<table id="list">
						
					</table>
				</td>
			</tr>
		</tbody>
	</table>
</body>
</html>