<?php 
session_start();

?>
<!DOCTYPE html>
<html>
<head>
	<title>User Dashboard</title>
	<script type="text/javascript">
		function includeProfile()
		{
			var key = "uname";
			var value = "<?php echo $_SESSION['uname']?>";
			var task="1";
			var xmlhttp = new XMLHttpRequest();
		
	        xmlhttp.onreadystatechange = function()
	        {
	            if (this.readyState == 4 && this.status == 200)
	            {
	                var objArr=	JSON.parse(this.responseText);
	               
	                document.getElementById("userName").innerHTML=objArr[0].fname+" "+objArr[0].lname;
	                document.getElementById("SelectedUser").innerHTML="Prescribing User:"+"<?php echo $_REQUEST['uname'];?>";
                	
					loadContactList();
	            }
	        };
	        xmlhttp.open("GET","../../request/userProfileRequest?task=1&value="+value+"&key="+key, false);
	        xmlhttp.send();
		}
		/*----Contact start-----*/
		function loadContactList()
		{
			var key = "docname";
			var value = "<?php echo $_SESSION['uname']?>";
			var xmlhttp = new XMLHttpRequest();
	        xmlhttp.onreadystatechange = function()
	        {
	            if (this.readyState == 4 && this.status == 200)
	            {
	            	 var objArr=JSON.parse(this.responseText);
	            	 document.getElementById("contactList").innerHTML="";
	            	 for(var x in objArr)
	            	 {
	            	 	loadSelectedUserInformation(objArr[x].uname,objArr[x].status);	            	 	
	            	 }
	            	 loadContactNotification(objArr);
					
	            }
	        };
	        xmlhttp.open("GET","../../request/doctorProfileRequest?task=6&key="+key+"&value="+value, true);
	        xmlhttp.send();
		}
		function loadSelectedUserInformation(uname,status)
		{
			var key = "uname";
			var xmlhttp = new XMLHttpRequest();


	        xmlhttp.onreadystatechange = function()
	        {
	            if (this.readyState == 4 && this.status == 200)
	            {
	            	var objArr=JSON.parse(this.responseText);
	            	if(status=="accept")
	            	{
	            		var li=document.createElement("li");
	            	 	li.innerHTML=objArr[0].fname+" "+objArr[0].lname;
	            	 	li.id=objArr[0].uname;

	            	 	li.onclick=function(){gotoUserChatBox(this.id)};
	            	 	document.getElementById("contactList").appendChild(li);
	            	}
	            
	            }
	        };
	        xmlhttp.open("GET","../../request/doctorProfileRequest?task=3&key="+key+"&value="+uname, true);
	        xmlhttp.send();
		}
		function loadContactNotification(objArr)
		{
			var count=0;
			for(var x in objArr)
			{

				if(objArr[0].status=="pending")
				{
					count=count+1;
					
				}
			}
			if(count>0)document.getElementById("Contact").innerHTML="Contact"+count;
			else
			{

				document.getElementById("Contact").innerHTML="Contact";
			}
			

		}
		/*----Contact end-----*/

		/* ----Precribe end ------*/
		function AddMoreOption()
		{
			var medicineContainer=document.getElementById("medicineListContainer");
			if(medicineContainer.childNodes.length-1<=8)
			{
				var div = document.createElement("div");
				div.name="medicine";

				var inputMedicineName = document.createElement("input");
				inputMedicineName.type="text";
				inputMedicineName.name="medicineDiscriptionText"
				inputMedicineName.placeholder="medicine name"

				var checkBox1 = document.createElement("input");
				checkBox1.type="checkBox";
				checkBox1.name="morningCheckBox"
				
				var checkBox2 = document.createElement("input");
				checkBox2.type="checkBox";
				checkBox2.name="AfternoonCheckBox";

				var checkBox3 = document.createElement("input");
				checkBox3.type="checkBox";
				checkBox3.name="NightCheckBox";

				var inputAdd = document.createElement("input");
				inputAdd.type="button";
				inputAdd.value="+";
				inputAdd.onclick=function(){AddMoreOption()};

				var inputRemove = document.createElement("input");
				inputRemove.type="button";
				inputRemove.value="-";
				inputRemove.onclick=function(){RemoveOption()};

				div.appendChild(inputMedicineName);
				div.appendChild(checkBox1);
				div.appendChild(checkBox2);
				div.appendChild(checkBox3);
				div.appendChild(inputAdd);
				div.appendChild(inputRemove);
				document.getElementById("medicineListContainer").appendChild(div);
			}
			

		}
		function RemoveOption()
		{
			var medicineContainer=document.getElementById("medicineListContainer");
			if(medicineContainer.childNodes.length-1>=3)
			{
				medicineContainer.removeChild(medicineContainer.childNodes[medicineContainer.childNodes.length-1]);
			}
			           
		}
		function prescribe()
		{
			var MediList=document.getElementsByName("medicineDiscriptionText");
			var morningList=document.getElementsByName("morningCheckBox");
			var afternoonList=document.getElementsByName("AfternoonCheckBox");
			var nightList=document.getElementsByName("NightCheckBox");

			var jsArray= new Array();
			for (var i = 0; i < MediList.length; i++) 
			{
				if((MediList[i].value!="") &&(morningList[i].checked||afternoonList[i].checked||nightList[i].checked))
				{
					var mediDetail=MediList[i].value;
					var mor,af,ni;
					if(morningList[i].checked)
					{
						mor="1";
					}
					else
					{
						mor="0";
					}
					if(afternoonList[i].checked)
					{
						af="1";
					}
					else
					{
						af="0";
					}
					if(nightList[i].checked)
					{
						ni="1";
					}
					else
					{
						ni="0";
					}
					var jsString={'description':mediDetail,'morning':mor,'afternoon':af,'night':ni};
   					jsArray.push(jsString);

				}
			}
			var uname="<?php echo $_REQUEST['uname'];?>"
			var docName="<?php echo $_SESSION['uname'];?>"
			var today = new Date();
			var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
			var jsStringArray = JSON.stringify(jsArray);
			var status = "no change";
			var isSeenUser="0";

			AddPrescription(docName,uname,jsStringArray,status,date,isSeenUser);			
		}
		function AddPrescription(docname,uname,description,status,date,isSeenUser)
		{
			var xmlhttp = new XMLHttpRequest();
	        xmlhttp.onreadystatechange = function()
	        {
	            if (this.readyState == 4 && this.status == 200)
	            {
	            	alert(this.responseText);
	            
	            }
	        };
	        xmlhttp.open("GET","../../request/doctorPrescribeRequest.php?task=1&docname="+docname+"&uname="+uname+"&description="+description+"&status="+status+"&date="+date+"&isSeenUser="+isSeenUser, true);
	        xmlhttp.send();
		}
		/* ----Precribe end ------*/
	</script>
</head>
<body onload="includeProfile()">
	<table border="1">
		<tbody>
			<tr>
				<td>
					<table>
						<tbody>
							<tr>
								<td>
									<div onclick="gotoProfile()">
										<img src="" id="profilePic">
										<p id="userName"></p>
										
									</div>
								</td>
							</tr>

							<tr>
								<td>
									<input type="text" name="" placeholder="Search">
								</td>
							</tr>
							<tr>
								<td>
									<p>Contact List</p>
									<ul id="contactList">
										
									</ul>
								</td>
							</tr>
							<tr>
								<td>
									<ul>
										<li onclick="gotoUserAppoinment()">Appoinment</li>
										<li onclick="gotoUserContact()" id="Contact">Contact</li>
										<li onclick="gotoUserPrescription()">Prescription</li>
										<li onclick="gotoLogout()">Logout</li>
									</ul>
								</td>
							</tr>
						</tbody>
					</table>
				</td>
				<td>
					<table id="list">
						<tr>
							<td>
								<p id="SelectedUser"></p>
							</td>
						</tr>
						<tr>
							<td id="medicineListContainer">
								<div name="medicine">
									<input type="text" placeholder="medicine name" name="medicineDiscriptionText">
									<input type="checkBox" name="morningCheckBox">
									<input type="checkBox" name="AfternoonCheckBox">
									<input type="checkBox" name="NightCheckBox">
									<input type="button" name="" value="+" onclick="AddMoreOption()">
								</div>
							</td>		
						</tr>
						<tr>
							<td>
								<input type="button" name="" value="prescribe" onclick="prescribe()">
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</tbody>
	</table>
</body>
</html>