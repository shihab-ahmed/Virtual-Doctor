<?php 
session_start();

?>
<!DOCTYPE html>
<html>
<head>
	<title>User Dashboard</title>
	<link rel="stylesheet" href="../css/user/showAppointment.css"/>
	<link rel="stylesheet" href="http://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css"/>
	<script type="text/javascript">

		/*.................................................................*/
		//setInterval(function(){ loadContactList("")}, 5000);
		setInterval(function(){ updateNotice("")}, 2000);

		function updateNotice()
		{
			notifyAppointment();
			notifyPrescription();
		}

		function includeProfile()
		{
			var key = "uname";
			var value = "<?php echo $_SESSION['uname']?>";
			var task="1";
			var xmlhttp = new XMLHttpRequest();
		
	        xmlhttp.onreadystatechange = function()
	        {
	            if (this.readyState == 4 && this.status == 200)
	            {
	                var objArr=	JSON.parse(this.responseText);
	               
	                document.getElementById("profilePic").src=objArr[0].picture;
	                
					loadContactList("");
					notifyAppointment();
					notifyPrescription();
	            }
	        };
	        xmlhttp.open("GET","../../request/userProfileRequest?task=1&value="+value+"&key="+key, false);
	        xmlhttp.send();
		}
		function loadContactList(value3)
		{
			var key = "uname";
			var key2 = "status";
			var value = "<?php echo $_SESSION['uname']?>";
			var value2="accept";
			var task="1";
			var xmlhttp = new XMLHttpRequest();

	        xmlhttp.onreadystatechange = function()
	        {
	            if (this.readyState == 4 && this.status == 200)
	            {
	            	 var objArr=JSON.parse(this.responseText);
	            	 document.getElementById("contactList").innerHTML="";
	            	 for(var x in objArr)
	            	 {
	            	 	loadSelectedUserInformation(objArr[x].docname);	            	 	
	            	 }
	            	 loadContactNotification(objArr);
					
	            }
	        };
	        if(value3=="")
	        {
	        	xmlhttp.open("GET","../../request/userProfileRequest?task=2&key="+key+"&key2="+key2+"&value="+value+"&value2="+value2, true);
	        }
	        else
	        {
	        	xmlhttp.open("GET","../../request/userProfileRequest?task=2&key="+key+"&key2="+key2+"&value="+value+"&value2="+value2, true);
	        }
	        xmlhttp.send();
		}
		function loadSelectedUserInformation(docname)
		{
			var key = "uname";
			var xmlhttp = new XMLHttpRequest();

	        xmlhttp.onreadystatechange = function()
	        {
	            if (this.readyState == 4 && this.status == 200)
	            {
	            	

	            	var objArr=JSON.parse(this.responseText);
	            	var li=document.createElement("li");

	            	var div=document.createElement("div");

	            	var img=document.createElement("img");
	            	img.src=objArr[0].picture;

	            	div.innerHTML=objArr[0].fname+" "+objArr[0].lname;

	            	//alert(objArr[0].picture);

	            	li.appendChild(img)
	            	li.appendChild(div);
            	 	li.id=objArr[0].uname;
            	 	li.onclick=function(){gotoUserChatBox(this.id)};
            	 	document.getElementById("contactList").appendChild(li);
	            }
	        };
	        xmlhttp.open("GET","../../request/userProfileRequest?task=3&key="+key+"&value="+docname, true);
	        xmlhttp.send();
		}
		function loadContactNotification(objArr)
		{
			var count=0;
			for(var x in objArr)
			{

				if(objArr[0].isSeenUser=="0")
				{
					count=count+1;
					
				}
			}
			if(count>0)
			{
				document.getElementById("Contact").innerHTML=count;
				document.getElementById("Contact").style.visibility = "visible";
			}
			else
			{

				document.getElementById("Contact").innerHTML="0";
				document.getElementById("Contact").style.visibility = "hidden";
			}

		}
		function notifyAppointment()
		{
			var key = "userUname";
			var key2 = "status";
			var value = "<?php echo $_SESSION['uname']?>";
			var value2="accept";
			var task="1";
			var xmlhttp = new XMLHttpRequest();

	        xmlhttp.onreadystatechange = function()
	        {
	            if (this.readyState == 4 && this.status == 200)
	            {
	            	 var objArr=JSON.parse(this.responseText);
					 loadAppointmentNotification(objArr);
					 for(var x in objArr)
					 {
					 	if(objArr[x].isSeenUser=="0")
						{
							getUserByName(objArr[x].docUname);
							
						}
					 
					 }
	            }
	        };
	        xmlhttp.open("GET","../../request/userProfileRequest?task=4&key="+key+"&key2="+key2+"&value="+value+"&value2="+value2, true);
	        xmlhttp.send();

		}
		function loadAppointmentNotification(objArr)
		{
			var count=0;
			for(var x in objArr)
			{
				if(objArr[x].isSeenUser=="0")
				{
					count=count+1;
					
				}
			}

			if(count>0)
			{
				document.getElementById("Appointment").innerHTML=count;
				document.getElementById("Appointment").style.visibility = "visible";
			}
			else
			{

				document.getElementById("Appointment").innerHTML="0";
				document.getElementById("Appointment").style.visibility = "hidden";
			}			

		}
		function seenAppointment(docname)
		{
			var uname = "<?php echo $_SESSION['uname']; ?>";
			var isSeenUser="1";
			var xmlhttp = new XMLHttpRequest();
	        xmlhttp.onreadystatechange = function()
	        {
	            if (this.readyState == 4 && this.status == 200)
	            {
	            	 alert(this.responseText);
	            	 document.getElementById("unseenAppointmentList").innerHTML="";
	            	 notifyAppointment();
	            }
	        };
	        xmlhttp.open("GET","../../request/userAppointmentRequest?task=2&uname="+uname+"&docname="+docname+"&isSeenUser="+isSeenUser, true);
	        xmlhttp.send();
		}
		function getUserByName(value)
		{

			var key = "uname";
			var xmlhttp = new XMLHttpRequest();
	        xmlhttp.onreadystatechange = function()
	        {
	            if (this.readyState == 4 && this.status == 200)
	            {
	            	 var objArr=JSON.parse(this.responseText);


	            	var exist = document.getElementById(objArr[0].uname);
					if (exist == null)
					{
						 var divContainer= document.createElement("div");
		            	 divContainer.id="divContainer";

		            	 var divPic= document.createElement("div");
		            	 divPic.id="pic";

		            	 var divmsg= document.createElement("div");
		            	 divmsg.id="message";

		            	 var divBtn= document.createElement("div");
		            	 divBtn.id="button";

		            	 var img= document.createElement("img");
		            	 img.src=objArr[0].picture;

		            	 divPic.appendChild(img);

						 divmsg.innerHTML=objArr[0].fname+" "+objArr[0].lname+" has granted your appointment request!  ";


						 var btn = document.createElement("input");
						 btn.id=objArr[0].uname;
						 btn.type="button";
						 btn.value="Seen";
						 btn.onclick = function(){seenAppointment(this.id)};

						 divBtn.appendChild(btn);

						 divContainer.appendChild(divPic);
						 divContainer.appendChild(divmsg);
						 divContainer.appendChild(divBtn);

						 document.getElementById("unseenAppointmentList").appendChild(divContainer);	
					}
	            }
	        };
	        xmlhttp.open("GET","../../request/userProfileRequest?task=1&key="+key+"&value="+value, true);
	        xmlhttp.send();
		}
		function notifyPrescription()
		{
			var key = "user";
			var value = "<?php echo $_SESSION['uname']?>";
			var task="1";
			var xmlhttp = new XMLHttpRequest();
			
	        xmlhttp.onreadystatechange = function()
	        {
	            if (this.readyState == 4 && this.status == 200)
	            {
	            	 var objArr=JSON.parse(this.responseText);
					 
					 loadPrescriptionNotification(objArr);
	            }
	        };
	        xmlhttp.open("GET","../../request/userProfileRequest?task=5&key="+key+"&value="+value, true);
	        xmlhttp.send();

		}
		function loadPrescriptionNotification(objArr)
		{
			var count=0;
			for(var x in objArr)
			{

				if(objArr[0].isSeenUser=="0")
				{
					count=count+1;
					
				}
			}
			if(count>0)
			{
				document.getElementById("Prescription").innerHTML=count;
				document.getElementById("Prescription").style.visibility = "visible";
			}
			else
			{
				document.getElementById("Prescription").innerHTML="0";
				document.getElementById("Prescription").style.visibility = "hidden";
			}
			

		}
		function SearchContact()
		{

		}
		function gotoProfile()
		{
			window.location.href="userDashboard.php";
		}
		function gotoChangeProfile()
		{
			window.location.href="userChangeProfile.php";
		}
		function gotoUserDoctor()
		{
			window.location.href="userDoctor.php";
		}
		function gotoUserAppoinment()
		{
			window.location.href="userAppointment.php";
		}
		function gotoUserContact()
		{
			window.location.href="userContact.php";
		}
		function gotoUserPrescription()
		{
			window.location.href="userPrescription.php";
		}
		function gotoUserChatBox(docUname)
		{
			window.location.href="userCHatBox.php?docUname="+docUname;
		}
		function gotoLogout()
		{
			window.location.href="../logout.php";
		}
		/*.................................................................*/
	</script>
</head>
<body onload="includeProfile()">

	<div id="sideBar">
		<div onclick="gotoProfile()" id="profileDiv">
			<img src="" id="profilePic" >
			<div id="userName"></div>	
		</div>
		<div id="searchDiv">
			<input type="text" name="" placeholder="Search" onkeyup="SearchContact()" id="searchBox">
		</div>
		<div class="containerContactList" id="contactListDiv">
			<ul class="contactList" id="contactList">
				
			</ul>
		</div>
		<div class="bottomMenuDiv">
			<ul class="menubar">
				<li>
					<i class="ion-person" onclick="gotoUserDoctor()"></i>				
					<div>1</div>
				</li>

				<li>
					<i class="ion-calendar" onclick="gotoUserAppoinment()"></i>
					<div id="Appointment">1</div>
				</li>

				<li>
					<i class="ion-clipboard " onclick="gotoUserPrescription()"></i>
					<div id="Prescription">1</div>
				</li>

				<li>
					<i class="ion-email" onclick="gotoUserContact()"></i>
					<div id="Contact">1</div>
				</li>

				<li>
					<i class="ion-log-out" onclick="gotoLogout()"></i>
					<div >1</div>
				</li>
			</ul>
		</div>



	</div>



	<div id="mainPanel">
		<div id="unseenAppointmentList">
			
		</div>		
	</div>
</body>
</html>