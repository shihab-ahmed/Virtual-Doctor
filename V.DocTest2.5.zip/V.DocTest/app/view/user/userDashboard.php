<?php 
session_start();

?>
<!DOCTYPE html>
<html>
<head>
	<title>User Dashboard</title>

	<link rel="stylesheet" href="../css/user/Dashboard.css"/>
	<link rel="stylesheet" href="http://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css"/>
	<script type="text/javascript">

		/*.................................................................*/
		setInterval(function(){ updateNotice("")}, 2000);

		function updateNotice()
		{
			notifyAppointment();
			notifyPrescription();
		}

		function includeProfile()
		{
			var key = "uname";
			var value = "<?php echo $_SESSION['uname']?>";
			var task="1";
			var xmlhttp = new XMLHttpRequest();
		
	        xmlhttp.onreadystatechange = function()
	        {
	            if (this.readyState == 4 && this.status == 200)
	            {
	                var objArr=	JSON.parse(this.responseText);
	               
	                document.getElementById("profilePic").src=objArr[0].picture;
	                document.getElementById("userName").innerHTML=objArr[0].fname+" "+objArr[0].lname;
                	document.getElementById("name").innerHTML=objArr[0].fname+" "+objArr[0].lname;
	                document.getElementById("email").innerHTML="Email :"+objArr[0].email;
	                document.getElementById("birthdate").innerHTML="birthdate :"+objArr[0].birthdate;
	                document.getElementById("age").innerHTML="Age :"+objArr[0].age;
	                document.getElementById("gender").innerHTML="Gender :"+objArr[0].gender;	
					loadContactList("");
					notifyAppointment();
					notifyPrescription();
	            }
	        };
	        xmlhttp.open("GET","../../request/userProfileRequest?task=1&value="+value+"&key="+key, false);
	        xmlhttp.send();
		}
		function loadContactList(value3)
		{
			var key = "uname";
			var key2 = "status";
			var value = "<?php echo $_SESSION['uname']?>";
			var value2="accept";
			var task="1";
			var xmlhttp = new XMLHttpRequest();

	        xmlhttp.onreadystatechange = function()
	        {
	            if (this.readyState == 4 && this.status == 200)
	            {
	            	 var objArr=JSON.parse(this.responseText);
	            	 document.getElementById("contactList").innerHTML="";
	            	 for(var x in objArr)
	            	 {
	            	 	loadSelectedUserInformation(objArr[x].docname);	            	 	
	            	 }
	            	 loadContactNotification(objArr);
					
	            }
	        };
	        if(value3=="")
	        {
	        	xmlhttp.open("GET","../../request/userProfileRequest?task=2&key="+key+"&key2="+key2+"&value="+value+"&value2="+value2, true);
	        }
	        else
	        {
	        	xmlhttp.open("GET","../../request/userProfileRequest?task=2&key="+key+"&key2="+key2+"&value="+value+"&value2="+value2, true);
	        }
	        xmlhttp.send();
		}
		function loadSelectedUserInformation(docname)
		{
			var key = "uname";
			var xmlhttp = new XMLHttpRequest();

	        xmlhttp.onreadystatechange = function()
	        {
	            if (this.readyState == 4 && this.status == 200)
	            {
	            	

	            	var objArr=JSON.parse(this.responseText);
	            	var li=document.createElement("li");

	            	var div=document.createElement("div");

	            	var img=document.createElement("img");
	            	img.src=objArr[0].picture;

	            	div.innerHTML=objArr[0].fname+" "+objArr[0].lname;

	            	//alert(objArr[0].picture);

	            	li.appendChild(img)
	            	li.appendChild(div);
            	 	li.id=objArr[0].uname;
            	 	li.onclick=function(){gotoUserChatBox(this.id)};
            	 	document.getElementById("contactList").appendChild(li);
	            }
	        };
	        xmlhttp.open("GET","../../request/userProfileRequest?task=3&key="+key+"&value="+docname, true);
	        xmlhttp.send();
		}
		function loadContactNotification(objArr)
		{
			var count=0;
			for(var x in objArr)
			{

				if(objArr[0].isSeenUser=="0")
				{
					count=count+1;
					
				}
			}
			if(count>0)
			{
				document.getElementById("Contact").innerHTML=count;
				document.getElementById("Contact").style.visibility = "visible";
			}
			else
			{

				document.getElementById("Contact").innerHTML="0";
				document.getElementById("Contact").style.visibility = "hidden";
			}

		}
		function notifyAppointment()
		{
			var key = "userUname";
			var key2 = "status";
			var value = "<?php echo $_SESSION['uname']?>";
			var value2="accept";
			var task="1";
			var xmlhttp = new XMLHttpRequest();

	        xmlhttp.onreadystatechange = function()
	        {
	            if (this.readyState == 4 && this.status == 200)
	            {
	            	 var objArr=JSON.parse(this.responseText);
					 //alert(this.responseText);
					 loadAppointmentNotification(objArr);
	            }
	        };
	        xmlhttp.open("GET","../../request/userProfileRequest?task=4&key="+key+"&key2="+key2+"&value="+value+"&value2="+value2, true);
	        xmlhttp.send();

		}
		function loadAppointmentNotification(objArr)
		{
			var count=0;
			for(var x in objArr)
			{

				if(objArr[0].isSeenUser=="0")
				{
					count=count+1;
					
				}
			}

			if(count>0)
			{
				document.getElementById("Appointment").innerHTML=count;
				document.getElementById("Appointment").style.visibility = "visible";
			}
			else
			{

				document.getElementById("Appointment").innerHTML="0";
				document.getElementById("Appointment").style.visibility = "hidden";
			}			

		}
		function notifyPrescription()
		{
			var key = "user";
			var value = "<?php echo $_SESSION['uname']?>";
			var task="1";
			var xmlhttp = new XMLHttpRequest();
			
	        xmlhttp.onreadystatechange = function()
	        {
	            if (this.readyState == 4 && this.status == 200)
	            {
	            	 var objArr=JSON.parse(this.responseText);
					 
					 loadPrescriptionNotification(objArr);
	            }
	        };
	        xmlhttp.open("GET","../../request/userProfileRequest?task=5&key="+key+"&value="+value, true);
	        xmlhttp.send();

		}
		function loadPrescriptionNotification(objArr)
		{
			var count=0;
			for(var x in objArr)
			{

				if(objArr[0].isSeenUser=="0")
				{
					count=count+1;
					
				}
			}
			if(count>0)
			{
				document.getElementById("Prescription").innerHTML=count;
				document.getElementById("Prescription").style.visibility = "visible";
			}
			else
			{
				document.getElementById("Prescription").innerHTML="0";
				document.getElementById("Prescription").style.visibility = "hidden";
			}
			

		}
		function SearchContact()
		{

		}
		function gotoProfile()
		{
			window.location.href="userDashboard.php";
		}
		function gotoChangeProfile()
		{
			window.location.href="userChangeProfile.php";
		}
		function gotoUserDoctor()
		{
			window.location.href="userDoctor.php";
		}
		function gotoUserAppoinment()
		{
			window.location.href="userAppointment.php";
		}
		function gotoUserContact()
		{
			window.location.href="userContact.php";
		}
		function gotoUserPrescription()
		{
			window.location.href="userPrescription.php";
		}
		function gotoUserChatBox(docUname)
		{
			window.location.href="userCHatBox.php?docUname="+docUname;
		}
		function gotoLogout()
		{
			window.location.href="../logout.php";
		}
		/*.................................................................*/
	</script>
</head>
<body onload="includeProfile()">

	<div id="sideBar">
		<div onclick="gotoProfile()" id="profileDiv">
			<img src="" id="profilePic" >
			<div id="userName"></div>	
		</div>
		<div id="searchDiv">
			<input type="text" name="" placeholder="Search" onkeyup="SearchContact()" id="searchBox">
		</div>
		<div class="containerContactList" id="contactListDiv">
			<ul class="contactList" id="contactList">
			</ul>
		</div>
		<div class="bottomMenuDiv">
			<ul class="menubar">
				<li>
					<i class="ion-person" onclick="gotoUserDoctor()"></i>				
					<div>1</div>
				</li>

				<li>
					<i class="ion-calendar" onclick="gotoUserAppoinment()"></i>
					<div id="Appointment">1</div>
				</li>

				<li>
					<i class="ion-clipboard " onclick="gotoUserPrescription()"></i>
					<div id="Prescription">1</div>
				</li>

				<li>
					<i class="ion-email" onclick="gotoUserContact()"></i>
					<div id="Contact">1</div>
				</li>

				<li>
					<i class="ion-log-out" onclick="gotoLogout()"></i>
					<div >1</div>
				</li>
			</ul>
		</div>



	</div>



	<div id="mainPanel">
		<div id="profilePanel">
			<img src="11.jpg">
			<div id="name" ></div>
			<div id="email" class="profileDescription"></div>
			<div id="birthdate" class="profileDescription"></div>
			<div id="age" class="profileDescription"></div>
			<div id="gender" class="profileDescription"></div>
			<input type="button" value="Change" onclick="gotoChangeProfile()" name="" id="changeButton">
		</div>		
	</div>
</body>
</html>