<?php 
session_start();

?>
<!DOCTYPE html>
<html>
<head>
	<title>User Dashboard</title>

	<link rel="stylesheet" href="../css/user/doctorProfile.css"/>
	<link rel="stylesheet" href="http://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css"/>
	<script type="text/javascript">

		/*.................................................................*/
		setInterval(function(){ updateNotice("")}, 2000);

		function updateNotice()
		{
			notifyAppointment();
			notifyPrescription();
			NotifyContact();
		}

		function includeProfile()
		{
			var key = "uname";
			var value = "<?php echo $_SESSION['uname']?>";
			var task="1";
			var xmlhttp = new XMLHttpRequest();
		
	        xmlhttp.onreadystatechange = function()
	        {
	            if (this.readyState == 4 && this.status == 200)
	            {
	                var objArr=	JSON.parse(this.responseText);
	               
	                document.getElementById("profilePic").src=objArr[0].picture;
					loadContactList("");
					notifyAppointment();
					notifyPrescription();
					loadDoctorDetails();
	            }
	        };
	        xmlhttp.open("GET","../../request/userProfileRequest?task=1&value="+value+"&key="+key, false);
	        xmlhttp.send();
		}
		function loadContactList(value3)
		{
			var key = "uname";
			var key2 = "status";
			var value = "<?php echo $_SESSION['uname']?>";
			var value2="accept";
			var task="1";
			var xmlhttp = new XMLHttpRequest();

	        xmlhttp.onreadystatechange = function()
	        {
	            if (this.readyState == 4 && this.status == 200)
	            {
	            	 var objArr=JSON.parse(this.responseText);
	            	 document.getElementById("contactList").innerHTML="";
	            	 for(var x in objArr)
	            	 {
	            	 	loadSelectedUserInformation(objArr[x].docname);	            	 	
	            	 }
	            	 loadContactNotification(objArr);
					
	            }
	        };
	        if(value3=="")
	        {
	        	xmlhttp.open("GET","../../request/userProfileRequest?task=2&key="+key+"&key2="+key2+"&value="+value+"&value2="+value2, true);
	        }
	        else
	        {
	        	xmlhttp.open("GET","../../request/userProfileRequest?task=2&key="+key+"&key2="+key2+"&value="+value+"&value2="+value2, true);
	        }
	        xmlhttp.send();
		}
		function NotifyContact()
		{
			var key = "uname";
			var key2 = "status";
			var value = "<?php echo $_SESSION['uname']?>";
			var value2="accept";
			var task="1";
			var xmlhttp = new XMLHttpRequest();

	        xmlhttp.onreadystatechange = function()
	        {
	            if (this.readyState == 4 && this.status == 200)
	            {
	            	 var objArr=JSON.parse(this.responseText);
	            	 loadContactNotification(objArr);
					
	            }
	        };
	        xmlhttp.open("GET","../../request/userProfileRequest?task=2&key="+key+"&key2="+key2+"&value="+value+"&value2="+value2, true);
	        xmlhttp.send();
		}
		function loadSelectedUserInformation(docname)
		{
			var key = "uname";
			var xmlhttp = new XMLHttpRequest();

	        xmlhttp.onreadystatechange = function()
	        {
	            if (this.readyState == 4 && this.status == 200)
	            {
	            	

	            	var objArr=JSON.parse(this.responseText);
	            	var li=document.createElement("li");

	            	var div=document.createElement("div");

	            	var img=document.createElement("img");
	            	img.src=objArr[0].picture;

	            	div.innerHTML=objArr[0].fname+" "+objArr[0].lname;

	            	//alert(objArr[0].picture);

	            	li.appendChild(img)
	            	li.appendChild(div);
            	 	li.id=objArr[0].uname;
            	 	li.onclick=function(){gotoUserChatBox(this.id)};
            	 	document.getElementById("contactList").appendChild(li);
	            }
	        };
	        xmlhttp.open("GET","../../request/userProfileRequest?task=3&key="+key+"&value="+docname, true);
	        xmlhttp.send();
		}
		function loadContactNotification(objArr)
		{
			var count=0;
			for(var x in objArr)
			{

				if(objArr[0].isSeenUser=="0")
				{
					count=count+1;
					
				}
			}
			if(count>0)
			{
				document.getElementById("Contact").innerHTML=count;
				document.getElementById("Contact").style.visibility = "visible";
			}
			else
			{

				document.getElementById("Contact").innerHTML="0";
				document.getElementById("Contact").style.visibility = "hidden";
			}

		}
		function notifyAppointment()
		{
			var key = "userUname";
			var key2 = "status";
			var value = "<?php echo $_SESSION['uname']?>";
			var value2="accept";
			var task="1";
			var xmlhttp = new XMLHttpRequest();

	        xmlhttp.onreadystatechange = function()
	        {
	            if (this.readyState == 4 && this.status == 200)
	            {
	            	 var objArr=JSON.parse(this.responseText);
					 //alert(this.responseText);
					 loadAppointmentNotification(objArr);
	            }
	        };
	        xmlhttp.open("GET","../../request/userProfileRequest?task=4&key="+key+"&key2="+key2+"&value="+value+"&value2="+value2, true);
	        xmlhttp.send();

		}
		function loadAppointmentNotification(objArr)
		{
			var count=0;
			for(var x in objArr)
			{

				if(objArr[0].isSeenUser=="0")
				{
					count=count+1;
					
				}
			}

			if(count>0)
			{
				document.getElementById("Appointment").innerHTML=count;
				document.getElementById("Appointment").style.visibility = "visible";
			}
			else
			{

				document.getElementById("Appointment").innerHTML="0";
				document.getElementById("Appointment").style.visibility = "hidden";
			}			

		}
		function notifyPrescription()
		{
			var key = "user";
			var value = "<?php echo $_SESSION['uname']?>";
			var task="1";
			var xmlhttp = new XMLHttpRequest();
			
	        xmlhttp.onreadystatechange = function()
	        {
	            if (this.readyState == 4 && this.status == 200)
	            {
	            	 var objArr=JSON.parse(this.responseText);
					 
					 loadPrescriptionNotification(objArr);
	            }
	        };
	        xmlhttp.open("GET","../../request/userProfileRequest?task=5&key="+key+"&value="+value, true);
	        xmlhttp.send();

		}
		function loadPrescriptionNotification(objArr)
		{
			var count=0;
			for(var x in objArr)
			{

				if(objArr[0].isSeenUser=="0")
				{
					count=count+1;
					
				}
			}
			if(count>0)
			{
				document.getElementById("Prescription").innerHTML=count;
				document.getElementById("Prescription").style.visibility = "visible";
			}
			else
			{
				document.getElementById("Prescription").innerHTML="0";
				document.getElementById("Prescription").style.visibility = "hidden";
			}
			

		}

		/* -----Doctor details view----*/
		function loadExtraInfo(docUname)
		{
			var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function() 
		 	{
	            if (this.readyState == 4 && this.status == 200) 
	            {
	                objArr=JSON.parse(this.responseText);
	               	document.getElementById("category").innerHTML="Category: "+objArr[0].specialist;
	               	document.getElementById("experience").innerHTML="Experience: "+objArr[0].experience;
	               	document.getElementById("about").innerHTML=objArr[0].about;
	            }              
		    };  
			xmlhttp.open("GET", "../../request/userDoctorViewDetailsRequest.php?task=2&key=docUname&value="+docUname, true);
	        xmlhttp.send();
		}
		function loadDoctorDetails()
		{
			var value ="<?php echo $_REQUEST['docUname']; ?>"
			var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function() 
		 	{
	            if (this.readyState == 4 && this.status == 200) 
	            {
	                objArr=JSON.parse(this.responseText);
	               	document.getElementById("name").innerHTML=objArr[0].fname+" "+objArr[0].lname;
					document.getElementById("email").innerHTML="Email :"+objArr[0].email;
					document.getElementById("birthdate").innerHTML="Birthdate: "+objArr[0].birthdate;
					document.getElementById("gender").innerHTML="Gender :"+objArr[0].gender;
					document.getElementById("age").innerHTML="Age: "+objArr[0].age;
					loadExtraInfo(value);
	            }              
		    };  
			xmlhttp.open("GET", "../../request/userDoctorViewDetailsRequest.php?task=1&key=uname&value="+value, true);
	        xmlhttp.send();
		}
		function gotoAppointmentPage()
		{
			var docUname= "<?php echo $_REQUEST['docUname']; ?>";
			window.location.href="userDoctorAppointment.php?docUname="+docUname;
		}
		function seeIfAlreadyInContact()
		{

			var key ="uname";
			var value ="<?php echo $_SESSION['uname']; ?>";
			var docname ="<?php echo $_REQUEST['docUname']; ?>";
			var xmlhttp = new XMLHttpRequest();
			var isFound = false;
			xmlhttp.onreadystatechange = function() 
		 	{
	            if (this.readyState == 4 && this.status == 200) 
	            {
	               objArr=JSON.parse(this.responseText);
	               for(var x in objArr)
	               {
	               		if(objArr[x].docname==docname)
	               		{
	               			isFound=true;
	               			alert("You sent request once to this user");
	               			break;
	               		}
	               }
	               (!isFound)
	               {
	               	 sendContactRequest();
	               }
	            }              
		    };
		   
			xmlhttp.open("GET", "../../request/userDoctorViewDetailsRequest.php?task=4&key="+key+"&value="+value, false);
	        xmlhttp.send();
		}
		function sendContactRequest()
		{
			var docname ="<?php echo $_REQUEST['docUname']; ?>"
			var uname ="<?php echo $_SESSION['uname']; ?>"
			var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function() 
		 	{
	            if (this.readyState == 4 && this.status == 200) 
	            {
	               alert(this.responseText);
	            }              
		    };  
			xmlhttp.open("GET", "../../request/userDoctorViewDetailsRequest.php?task=3&docname="+docname+"&uname="+uname, false);
	        xmlhttp.send();
		}

		/* -----Doctor details view end----*/



		function SearchContact()
		{

		}
		function gotoProfile()
		{
			window.location.href="userDashboard.php";
		}
		function gotoChangeProfile()
		{
			window.location.href="userChangeProfile.php";
		}
		function gotoUserDoctor()
		{
			window.location.href="userDoctor.php";
		}
		function gotoUserContact()
		{
			window.location.href="userContact.php";
		}
		function gotoUserPrescription()
		{
			window.location.href="userPrescription.php";
		}
		function gotoUserChatBox(docUname)
		{
			window.location.href="userCHatBox.php?docUname="+docUname;
		}
		function gotoLogout()
		{
			window.location.href="../logout.php";
		}
		/*.................................................................*/
	</script>
</head>
<body onload="includeProfile()">

	<div id="sideBar">
		<div onclick="gotoProfile()" id="profileDiv">
			<img src="" id="profilePic" >
			<div id="userName"></div>	
		</div>
		<div id="searchDiv">
			<input type="text" name="" placeholder="Search" onkeyup="SearchContact()" id="searchBox">
		</div>
		<div class="containerContactList" id="contactListDiv">
			<ul class="contactList" id="contactList">
			</ul>
		</div>
		<div class="bottomMenuDiv">
			<ul class="menubar">
				<li>
					<i class="ion-person" onclick="gotoUserDoctor()"></i>				
					<div>1</div>
				</li>

				<li>
					<i class="ion-calendar" onclick="gotoUserAppoinment()"></i>
					<div id="Appointment">1</div>
				</li>

				<li>
					<i class="ion-clipboard " onclick="gotoUserPrescription()"></i>
					<div id="Prescription">1</div>
				</li>

				<li>
					<i class="ion-email" onclick="gotoUserContact()"></i>
					<div id="Contact">1</div>
				</li>

				<li>
					<i class="ion-log-out" onclick="gotoLogout()"></i>
					<div >1</div>
				</li>
			</ul>
		</div>



	</div>



	<div id="mainPanel">
		<div id="profilePanel">
			<img src="11.jpg">
			<div id="doctorDetails">
				<div id="name" ></div>
				<div id="email" class="profileDescription"></div>
				<div id="birthdate" class="profileDescription"></div>
				<div id="age" class="profileDescription"></div>
				<div id="gender" class="profileDescription"></div>
				<div id="category" class="profileDescription"></div>
				<div id="experience" class="profileDescription"></div>
			</div>
			<div id="aboutSection">
				<h3>About :</h3>
				<div id="about" class="profileDescriptionAbout"></div>
			</div>
			<div id="inputSection">
				<div><input type="button" name="change" value="Add to contact" onclick="seeIfAlreadyInContact()"></div>
				<div><input type="button" name="change" value="Apply for appointment" onclick="gotoAppointmentPage()"></div>
			</div>			
		</div>		
	</div>
</body>
</html>

		
