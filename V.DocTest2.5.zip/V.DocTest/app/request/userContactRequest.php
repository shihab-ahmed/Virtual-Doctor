<?php
	define('APP_ROOT', "$_SERVER[DOCUMENT_ROOT]/V.DocTest");
	$Root=APP_ROOT;
	require_once(APP_ROOT."/core/core_service.php");
?>
<?php
	if(isset($_REQUEST['task']))
	{
		if($_REQUEST['task']==1)
		{
			updateContactToCore();
		}
		
	}
	function updateContactToCore()
	{
		$notice=updateContact($_REQUEST['key'],$_REQUEST['value'],$_REQUEST['id']);
		if($notice=="1")
		{
			echo "you have seen this contact request";
		}
		else
		{
			echo "failed";
		}
	}
	
	
 ?>