-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 30, 2017 at 07:12 PM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vdocstorage`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `id` int(11) NOT NULL,
  `docUname` varchar(50) NOT NULL,
  `userUname` varchar(50) NOT NULL,
  `startDate` datetime NOT NULL,
  `endDate` datetime NOT NULL,
  `message` varchar(300) NOT NULL,
  `status` varchar(100) NOT NULL,
  `isSeenUser` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`id`, `docUname`, `userUname`, `startDate`, `endDate`, `message`, `status`, `isSeenUser`) VALUES
(20, 'doc5', 'shihab26284', '2017-04-12 12:59:00', '2017-04-11 11:59:00', 'need appointment', 'accept', 1);

-- --------------------------------------------------------

--
-- Table structure for table `chatlog`
--

CREATE TABLE `chatlog` (
  `id` int(11) NOT NULL,
  `sender` varchar(50) NOT NULL,
  `reciever` varchar(50) NOT NULL,
  `message` varchar(300) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `contactlist`
--

CREATE TABLE `contactlist` (
  `id` int(11) NOT NULL,
  `uname` varchar(50) NOT NULL,
  `docname` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  `isSeenUser` tinyint(1) NOT NULL,
  `isSeen` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contactlist`
--

INSERT INTO `contactlist` (`id`, `uname`, `docname`, `status`, `isSeenUser`, `isSeen`) VALUES
(36, 'Shihab', 'test', 's', 0, 2),
(37, 'shihab26284', 'doc1', 'accept', 0, 0),
(38, 'shihab26284', 'doc1', 'accept', 0, 0),
(39, 'shihab26284', 'doc1', 'accept', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `id` int(11) NOT NULL,
  `docUname` varchar(50) NOT NULL,
  `specialist` varchar(100) NOT NULL,
  `experience` int(2) NOT NULL,
  `about` varchar(500) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`id`, `docUname`, `specialist`, `experience`, `about`) VALUES
(29, 'doc1', 'Audiologist', 2, '1'),
(30, 'doc2', 'Allergist', 2, '1'),
(31, 'doc3', 'Allergist', 2, '1'),
(32, 'doc5', 'Neonatologist', 2, '1');

-- --------------------------------------------------------

--
-- Table structure for table `doctor_category`
--

CREATE TABLE `doctor_category` (
  `id` int(11) NOT NULL,
  `category` varchar(50) NOT NULL,
  `specialize` varchar(1000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor_category`
--

INSERT INTO `doctor_category` (`id`, `category`, `specialize`) VALUES
(3, 'Audiologist', 'ear,hear,deaf,mute,speak'),
(4, 'Allergist', 'allergies,hay,fever,astma,skin,rash'),
(5, 'Dentist', 'mouth,teeth,gum,cavities,bleeding gums'),
(6, 'Endocrinologists', 'endocrine,gland,hormone'),
(7, 'Gynecologist', 'female,reproductive,sex,fertility,infant,baby'),
(8, 'Neonatologist', 'newborn,infant,baby'),
(9, 'Neurologist', 'human,brain,Azheimer,Parkinson,Dementia,Brain'),
(10, 'Surgeon', 'Surgery,oral,ENT,cardiothoracic,cardiovascular,neuro');

-- --------------------------------------------------------

--
-- Table structure for table `prescribe_medicine`
--

CREATE TABLE `prescribe_medicine` (
  `id` int(11) NOT NULL,
  `prescriptionId` int(11) NOT NULL,
  `medicineName` varchar(100) NOT NULL,
  `time` varchar(10) NOT NULL,
  `howLong` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `prescription`
--

CREATE TABLE `prescription` (
  `id` int(11) NOT NULL,
  `docU` varchar(50) NOT NULL,
  `user` varchar(50) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `status` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `isSeenUser` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `prescription`
--

INSERT INTO `prescription` (`id`, `docU`, `user`, `description`, `status`, `date`, `isSeenUser`) VALUES
(8, 'doc1', 'shihab26284', '[{"description":"Napa","morning":"1","afternoon":"0","night":"1"},{"description":"Napa 2","morning":"0","afternoon":"1","night":"0"},{"description":"Napa 3","morning":"1","afternoon":"0","night":"1"}]', 'no change', '2017-04-30', 1),
(7, 'doc1', 'shihab26284', '[{"description":"sadas","morning":"1","afternoon":"0","night":"0"}]', 'no change', '2017-04-30', 1);

-- --------------------------------------------------------

--
-- Table structure for table `report`
--

CREATE TABLE `report` (
  `id` int(11) NOT NULL,
  `about` varchar(100) NOT NULL,
  `sender` int(11) NOT NULL,
  `reportedId` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `uname` varchar(50) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(120) DEFAULT NULL,
  `birthdate` date NOT NULL,
  `gender` varchar(10) NOT NULL,
  `age` int(3) NOT NULL,
  `picture` varchar(300) NOT NULL,
  `type` varchar(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `fname`, `lname`, `uname`, `email`, `password`, `birthdate`, `gender`, `age`, `picture`, `type`) VALUES
(126, 'adilin', 'eddy', 'doc5', 'Astraion@live.com', '84299cc177f9bb24a98417f5b2f23eef', '2017-04-27', 'male', 2017, '../uploads/d9.jpg', 'doctor'),
(125, 'nila', 'emily', 'doc3', 'Astraion@live.com', 'af75c71ac23e1156c0ef1ba6a9deeb03', '2017-04-11', 'male', 2017, '../uploads/d4.jpg', 'doctor'),
(124, 'anna', 'emily', 'doc2', 'Astraion@live.com', '271559ec25268bb9bb2ad7fd8b4cf71a', '2017-04-11', 'male', 2017, '../uploads/d3.jpg', 'doctor'),
(123, 'Doctor', 'Doc', 'doc1', 'doc1@gmail.com', '83e4b1789306d3d1c99140df3827d600', '2016-12-31', 'male', 2017, '../uploads/d2.jpg', 'doctor'),
(122, 'Shihab', 'Ahmed', 'shihab26284', 'Astraion@live.com', 'a853ef750abd5ab6263073bd9821fbb5', '2016-12-31', 'female', 2017, '../uploads/11.jpg', 'user'),
(61, 'dragon', 'dragon', 'admin1', 'Astraion@live.com', 'e00cf25ad42683b3df678c61f42c6bda', '2017-12-31', 'male', 0, '../uploads/d3.jpg', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chatlog`
--
ALTER TABLE `chatlog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contactlist`
--
ALTER TABLE `contactlist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctor_category`
--
ALTER TABLE `doctor_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prescribe_medicine`
--
ALTER TABLE `prescribe_medicine`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prescription`
--
ALTER TABLE `prescription`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `report`
--
ALTER TABLE `report`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `userID` (`uname`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `chatlog`
--
ALTER TABLE `chatlog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=120;
--
-- AUTO_INCREMENT for table `contactlist`
--
ALTER TABLE `contactlist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `doctor_category`
--
ALTER TABLE `doctor_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `prescribe_medicine`
--
ALTER TABLE `prescribe_medicine`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `prescription`
--
ALTER TABLE `prescription`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `report`
--
ALTER TABLE `report`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=127;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
