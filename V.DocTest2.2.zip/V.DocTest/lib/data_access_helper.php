<?php
	function connection_start()
	{
		try
		{
			$con = mysqli_connect("localhost", "root", "","vdocstorage");
			return $con;
		}
		catch(Exception $e)
		{
			die("Connection failed: " . mysqli_connect_error());
		}
		
	}
	function connection_close($con)
	{
		mysqli_close($con);
	}
	
?>
<?php	
	function executeNonQuery($query)
	{
		$result = false;
		$connection = connection_start();		
		if($connection){
			$result = mysqli_query($connection, $query);
		}
		connection_close($connection);
		return $result;
	}
	
	function executeQuery($query)
	{
		$connection = connection_start();	
		$result = mysqli_query($connection, $query);
		connection_close($connection);
		return $result;
	}
?>
<?php 
	function validateFirstName($fname)
	{
		if(empty($fname))
		{
			echo "First Name Not inserted<br>";
			return false;
		}
		else
		{
			for($i=0;$i<count($fname);$i++)
			{
				if( ord($fname[$i])<65 || ord($fname[$i])>122)
				{
					echo "First name can only contain alphabet <br>";
					return false;
				}
				else
				{
					return true;
				}
			}				
		}
	}
	function validateLastName($lname)
	{
		if(empty($lname))
		{
			echo "Last Name Not inserted<br>";
			return false;
		}
		else
		{
			for($i=0;$i<count($lname);$i++)
			{
				if( ord($lname[$i])<65 || ord($lname[$i])>122)
				{
					echo "Last name can only contain alphabet <br>";
					return false;
				}
				else
				{
					return true;
				}
			}
			
			
		}
	}
	function validateUserName($uname)
	{
		if(empty($uname))
		{
			echo "User Name Not inserted<br>";
			return false;
		}
		else
		{

			if( ord($uname[0])<65 || ord($uname[0])>122)
			{
				echo "User name can only contain alphabet <br>";
				return false;
			}
			else
			{
				return true;			
			}	
			
		}
	}
	function validateEmail($email)
	{
		if(empty($_POST['gender']))return false;
		else
		{
			return true;
		}
	}
	function validateDate($date)
	{
		$isvalid=true;
		if(empty($date))$isvalid=false;
		return $isvalid;
	}
	function validateTime($time)
	{
		$isvalid=true;
		if(empty($time))$isvalid=false;
		return $isvalid;
	}
	function validateReason($reason)
	{
		$isvalid=true;
		if(empty($reason))$isvalid=false;
		return $isvalid;
	}
	function validatePassword($pass,$cpass)
	{
		if(empty($pass))
		{
			echo "password is required <br>";
			return false;
		}
		if(empty($cpass))
		{
			echo "confirm password is required <br>";
			return false;
		}
		if(!empty($pass)&&!empty($cpass))
		{
			
			if($pass!=$cpass)
			{
			
				echo "password and confirm password doesnt match <br>";
				return false;
			}
			else
			{
				return true;
			}
		}
	}
	function validateGender()
	{
		if(isset($_POST['gender']))
		{
			return true;
		}
		else
		{
			echo "gender not selected <br>";
			return false;
		}
	}
	function validateYearsOfExperience($exp)
	{
		if(empty($exp))
		{
			echo "Years of experience Not inserted<br>";
			return false;
		}
		else
		{
			for($i=0;$i<count($exp);$i++)
			{
				if( ord($exp[$i])<48 || ord($exp[$i])>57)
				{
					echo "Experience can only be number <br>";
					return false;
				}
				else
				{
					return true;
				}
			}
			
			
		}
	}
	function validateImage()
	{

		if(isset($_FILES['fileToUpload']))
		{

			$target_dir ="../uploads/";
			echo $target_dir;
			$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
			
			$_POST['target_file']=$target_file;
			$uploadOk = 1;
			$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
			// Check if image file is a actual image or fake image
			if(isset($_POST["submit"])) 
			{
			    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
			    echo $check;
			    if($check !== false)
			     {
			        echo "File is an image - " . $check["mime"] . ".";
			        $uploadOk = 1;
			    } else {
			        echo "File is not an image.";
			        $uploadOk = 0;
			    }
			}

			// Check if file already exists
			if (file_exists($target_file)) 
			{
			    echo "Sorry, file already exists.";
			    $uploadOk = 0;
			}
			// Check file size
			if ($_FILES["fileToUpload"]["size"] > 500000) 
			{
			    echo "Sorry, your file is too large.";
			    $uploadOk = 0;
			}
			// Allow certain file formats
			if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
			&& $imageFileType != "gif" ) 
			{
			    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
			    $uploadOk = 0;
			}
			return $uploadOk;
		}
		else
		{
			return false;
		}
		
	}
	function test_input($data) 
	{
	  $data = trim($data);
	  $data = stripslashes($data);
	  $data = htmlspecialchars($data);
	  return $data;
	}
?>