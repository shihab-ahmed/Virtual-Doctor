<?php
	define('APP_ROOT', "$_SERVER[DOCUMENT_ROOT]/V.DocTest");
	$Root=APP_ROOT;
	require_once(APP_ROOT."/core/core_service.php");
?>
<?php
	if(isset($_REQUEST['task']))
	{
		if($_REQUEST['task']==1)
		{
			sendChat();
		}
		if($_REQUEST['task']==2)
		{
			recieveChat();
		}
		
	}
	function sendChat()
	{
		echo addChat($_REQUEST['sender'],$_REQUEST['reciever'],$_REQUEST['message']);
	}
	function recieveChat()
	{
		echo getChat($_REQUEST['sender'],$_REQUEST['reciever']);
	}
	
	
 ?>