<?php
	define('APP_ROOT', "$_SERVER[DOCUMENT_ROOT]/V.DocTest");
	$Root=APP_ROOT;
	require_once(APP_ROOT."/core/core_service.php");
	session_start();
?>
<?php 
	if(isset($_REQUEST['task']))
	{
		if($_REQUEST['task']==1)
		{
			addApplyForRequest();
		}
		if($_REQUEST['task']==2)
		{
			updateAppointmentToCore();
		}
		
	}
	function updateAppointmentToCore()
	{
		$notice=updateAppointment($_REQUEST['uname'],$_REQUEST['docname'],$_REQUEST['isSeenUser']);
		if($notice==1)
		{
			echo "notice update successfull";
		}
		else
		{
			echo "notice update failed";
		}
	}

	function addApplyForRequest()
	{
		$isvalid=true;

		if(validateDate($_POST['sdate']))$sdate=$_POST['sdate'];
		else
		{
			$isvalid=false;
		}

		if(validateDate($_POST['edate']))$edate=$_POST['edate'];	
		else
		{
			$isvalid=false;
		}

		if(validateTime($_POST['stime']))$stime=$_POST['stime'];	
		else
		{
			$isvalid=false;
		}

		if(validateTime($_POST['etime']))$etime=$_POST['etime'];	
		else
		{
			$isvalid=false;
		}
		if(validateReason($_POST['reason']))$message=$_POST['reason'];	
		else
		{
			$isvalid=false;
		}
		
		if($isvalid)
		{
			$startDate=$sdate." ".$stime;
			$endDate=$edate." ".$etime;
			
			echo $_SESSION['uname'];
			if(addAppointment($_POST['docUname'],$_SESSION['uname'],$startDate,$endDate,$message,$_POST['status']))
			{
				echo "AppointmentRequest sent";
				
			}
			else
			{
				//header("location :applyForAppointment.php?uname=".$_POST['docUname']."&success=0");
			}
		}
		else
		{
			echo "Failed to send request";
		}
		
	}
	
 ?>