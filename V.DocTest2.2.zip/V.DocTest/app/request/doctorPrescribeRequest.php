<?php
	define('APP_ROOT', "$_SERVER[DOCUMENT_ROOT]/V.DocTest");
	$Root=APP_ROOT;
	require_once(APP_ROOT."/core/core_service.php");
?>
<?php
	if(isset($_REQUEST['task']))
	{
		if($_REQUEST['task']==1)
		{
			addPrescriptionToCore();
		}
		
	}
	function addPrescriptionToCore()
	{
		$notice= addPrescription($_REQUEST['docname'],$_REQUEST['uname'],$_REQUEST['description'],$_REQUEST['status'],$_REQUEST['date'],$_REQUEST['isSeenUser']);
		if($notice==1)
		{
			echo "added";
		}
		else
		{
			echo "Not added";
		}
	}
	
	
 ?>