<?php 
	if(isset($_REQUEST['status']))
	{
		if($_REQUEST['status']==0)
		{
			echo "login failed";
		}
	}
?>
<html>
<head>
	<link rel="stylesheet" href="app/view/css/log.css"/>
	<script type="text/javascript">
	
	</script>
</head>
<body>
	<div id="login">
		<form method="post" action="../request/loginRequest.php">
			<table>
				<tr>
					<td colspan="2">
						<h2>Sign In</h2>
					</td>
				</tr>
				<tr>
					<td colspan="2">
						<input type="text" id="username" name="unameText" placeholder="Enter Username" class="textInput" />
					</td>
				</tr>
				<tr>
					<td colspan="2">
						<input type="password" id="password" name="passText" placeholder="Enter password" class="textInput" />
					</td>
				</tr>
				<tr>
					<td align="left">
						<a href="reg.php" id="createAccount">Don't Have Account ?</a>
					</td>
					<td align="right">
						<input type="submit" id="login-btn" value="Sign In" onclick="seeError()" />
					</td>
				</tr>
				<tr>
					<td colspan="2" align="center">
 					
					</td>
				</tr>
			</table>		
		</form>
	</body>
<html>