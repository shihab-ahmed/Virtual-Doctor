<?php
	require_once(APP_ROOT."/data/data_access.php");
?>
<?php
	function getUserByKeyValue($key,$value)
	{	
		return getUserByKeyValueFromDb($key,$value);
	}
	function  getDoctorDetailsUsingKeyValue($key,$value)
	{	
		$result=getDoctorDetailsUsingKeyValueFromDatabase($key,$value);
		$rows = array();
		while($r = mysqli_fetch_assoc($result))
		{
    	  $rows[] = $r;
        }

		return json_encode($rows);
	}
	function getUserByKeyValueJSON($key,$value)
	{	 
		$result= getUserByKeyValueJSONFromDb($key,$value);
		
		$rows = array();
		while($r = mysqli_fetch_assoc($result))
		{
    	  $rows[] = $r;
        }
		return json_encode($rows);
	}
	function getAllUserUsingLike($key,$value)
	{	 
		$result= getUserByKeyValueUsingLikeFromDb($key,$value);
		//echo $key;
		$rows = array();
		while($r = mysqli_fetch_assoc($result))
		{
    	  $rows[] = $r;
        }
		return json_encode($rows);
	}
	 
	function DeleteUserByKeyValue($key,$value,$type,$pic)
	{
		return DeleteUserByKeyValueFromDb($key,$value,$type,$pic);
	}
	function GetNameTaken($key,$value)
	{
		return GetNameTakenFromDb($key,$value);
	}
	function addUser($fname,$lname,$uname,$email,$pass,$date,$gender,$file,$type,$previousYear)
	{
		return addUserToDb($fname,$lname,$uname,$email,$pass,$date,$gender,$file,$type,$previousYear);
	}
	function addDoctor($fname,$lname,$uname,$email,$pass,$date,$gender,$file,$type,$previousYear,$category,$experience,$about)
	{
		return addDoctorToDb($fname,$lname,$uname,$email,$pass,$date,$gender,$file,$type,$previousYear,$category,$experience,$about);
	}
	function updateUserProfile($fname,$lname,$uname,$email,$date,$gender,$file,$previousYear)
	{
		return updateUserProfileToDb($fname,$lname,$uname,$email,$date,$gender,$file,$previousYear);
	}
	function updateUserPassword($pass,$uname)
	{
		return updateUserPasswordToDb($pass,$uname);
	}
	function sendContactRequestToDoctor($uname,$docname,$status,$isSeenUser,$isSeen)
	{
		return sendContactRequestToDoctorToDb($uname,$docname,$status,$isSeenUser,$isSeen);
	}
	function getAllUser()
	{
		$result=getAllUserFromDb();
		$rows = array();
		while($r = mysqli_fetch_assoc($result))
		{
    	  $rows[] = $r;
        }
		return json_encode($rows);
	}
	function getDoctorDetails()
	{
		$result=getDoctorDetailsFromDatabase();
		$rows = array();
		while($r = mysqli_fetch_assoc($result))
		{
    	  $rows[] = $r;
        }
		return json_encode($rows);
	}
	function addAppointment($docUname,$uname,$startDate,$endDate,$message,$status)
	{
		return addAppointmentToDb($docUname,$uname,$startDate,$endDate,$message,$status);
	}
	function getContactListUsingDoubleKey($key,$value,$key2,$value2)
	{
		$result=getContactListUsingDoubleKeyFromDb($key,$value,$key2,$value2);
		$rows = array();
		while($r = mysqli_fetch_assoc($result))
		{
    	  $rows[] = $r;
        }
		return json_encode($rows);
	}
	function getContactListFromCore($key,$value)
	{
		$result=getContactListFromDb($key,$value);
		$rows = array();
		while($r = mysqli_fetch_assoc($result))
		{
    	  $rows[] = $r;
        }
		return json_encode($rows);
	}
	
	function getAppointmentListUsingDoubleKey($key,$value,$key2,$value2)
	{
		$result=getAppointmentListUsingDoubleKeyFromDb($key,$value,$key2,$value2);
		$rows = array();
		while($r = mysqli_fetch_assoc($result))
		{
    	  $rows[] = $r;
        }
		return json_encode($rows);
	}
	function getPrescriptionList($key,$value)
	{
		$result=getPrescriptionListFromDb($key,$value);
		$rows = array();
		while($r = mysqli_fetch_assoc($result))
		{
    	  $rows[] = $r;
        }
		return json_encode($rows);
	}
	function getDoctorListUsingDoubleKey($key,$value,$key2,$value2)
	{
		$result=getDoctorListUsingDoubleKeyFromDb($key,$value,$key2,$value2);
		$rows = array();
		while($r = mysqli_fetch_assoc($result))
		{
    	  $rows[] = $r;
        }
		return json_encode($rows);
	}
	
	function addChat($sender,$reciever,$message)
	{
		return addChatToDb($sender,$reciever,$message);
	}
	function getChat($sender,$reciever)
	{
		$result=getChatFromDb($sender,$reciever);
		$rows = array();
		while($r = mysqli_fetch_assoc($result))
		{
    	  $rows[] = $r;
        }
		return json_encode($rows);
	}
	function updateContactList($uname,$docname,$status,$isSeenUser)
	{
		return updateContactListToDb($uname,$docname,$status,$isSeenUser);
	}
	function deleteContactList($uname,$docname)
	{
		return deleteContactListFromDb($uname,$docname);
	}
	function addPrescription($docName,$uname,$description,$status,$date,$isSeenUser)
	{
		return addPrescriptionToDb($docName,$uname,$description,$status,$date,$isSeenUser);
	}
?>