<?php 
session_start();

?>
<!DOCTYPE html>
<html>
<head>
	<title>User Dashboard</title>
	<script type="text/javascript">

		/*.................................................................*/
		//setInterval(function(){ loadContactList("")}, 5000);

		function includeProfile()
		{
			var key = "uname";
			var value = "<?php echo $_SESSION['uname']?>";
			var task="1";
			var xmlhttp = new XMLHttpRequest();
		
	        xmlhttp.onreadystatechange = function()
	        {
	            if (this.readyState == 4 && this.status == 200)
	            {
	                var objArr=	JSON.parse(this.responseText);
	               
	                document.getElementById("userName").innerHTML=objArr[0].fname+" "+objArr[0].lname;
                	
					loadContactList("");
					notifyAppointment();
					notifyPrescription();
	            }
	        };
	        xmlhttp.open("GET","../../request/userProfileRequest?task=1&value="+value+"&key="+key, false);
	        xmlhttp.send();
		}
		function loadContactList(value3)
		{
			var key = "uname";
			var key2 = "status";
			var value = "<?php echo $_SESSION['uname']?>";
			var value2="accept";
			var task="1";
			var xmlhttp = new XMLHttpRequest();

	        xmlhttp.onreadystatechange = function()
	        {
	            if (this.readyState == 4 && this.status == 200)
	            {
	            	 var objArr=JSON.parse(this.responseText);
	            	 document.getElementById("contactList").innerHTML="";
	            	 for(var x in objArr)
	            	 {
	            	 	loadSelectedUserInformation(objArr[x].docname);	            	 	
	            	 }
	            	 loadContactNotification(objArr);
					
	            }
	        };
	        if(value3=="")
	        {
	        	xmlhttp.open("GET","../../request/userProfileRequest?task=2&key="+key+"&key2="+key2+"&value="+value+"&value2="+value2, true);
	        }
	        else
	        {
	        	xmlhttp.open("GET","../../request/userProfileRequest?task=2&key="+key+"&key2="+key2+"&value="+value+"&value2="+value2, true);
	        }
	        xmlhttp.send();
		}
		function loadSelectedUserInformation(docname)
		{
			var key = "uname";
			var xmlhttp = new XMLHttpRequest();

	        xmlhttp.onreadystatechange = function()
	        {
	            if (this.readyState == 4 && this.status == 200)
	            {
	            	var objArr=JSON.parse(this.responseText);
	            	var li=document.createElement("li");
            	 	li.innerHTML=objArr[0].fname+" "+objArr[0].lname;
            	 	li.id=objArr[0].uname;
            	 	li.onclick=function(){gotoUserChatBox(this.id)};
            	 	document.getElementById("contactList").appendChild(li);
	            }
	        };
	        xmlhttp.open("GET","../../request/userProfileRequest?task=3&key="+key+"&value="+docname, true);
	        xmlhttp.send();
		}
		function loadContactNotification(objArr)
		{
			var count=0;
			for(var x in objArr)
			{

				if(objArr[0].isSeenUser=="0")
				{
					count=count+1;
					
				}
			}
			if(count>0)document.getElementById("Contact").innerHTML="Contact"+count;
			else
			{

				document.getElementById("Contact").innerHTML="Contact";
			}
			

		}
		function notifyAppointment()
		{
			var key = "userUname";
			var key2 = "status";
			var value = "<?php echo $_SESSION['uname']?>";
			var value2="accept";
			var task="1";
			var xmlhttp = new XMLHttpRequest();

	        xmlhttp.onreadystatechange = function()
	        {
	            if (this.readyState == 4 && this.status == 200)
	            {
	            	 var objArr=JSON.parse(this.responseText);
					 //alert(this.responseText);
					 loadAppointmentNotification(objArr);
	            }
	        };
	        xmlhttp.open("GET","../../request/userProfileRequest?task=4&key="+key+"&key2="+key2+"&value="+value+"&value2="+value2, true);
	        xmlhttp.send();

		}
		function loadAppointmentNotification(objArr)
		{
			var count=0;
			for(var x in objArr)
			{

				if(objArr[0].isSeenUser=="0")
				{
					count=count+1;
					
				}
			}
			if(count>0)document.getElementById("Appointment").innerHTML="Appointment"+count;
			else
			{

				document.getElementById("Appointment").innerHTML="Appointment";
			}
			

		}
		function notifyPrescription()
		{
			var key = "user";
			var value = "<?php echo $_SESSION['uname']?>";
			var task="1";
			var xmlhttp = new XMLHttpRequest();

	        xmlhttp.onreadystatechange = function()
	        {
	            if (this.readyState == 4 && this.status == 200)
	            {
	            	 var objArr=JSON.parse(this.responseText);
					 
	            	 for(var x in objArr)
	            	 {
	            	 	var tr = document.createElement("tr");
	            	 	var td = document.createElement("tr");
		            	var pSentBy=document.createElement("p");
		            	var divDetails=document.createElement("div");
		            	
		            	pSentBy.innerHTML="Doctor :"+objArr[x].docU+" Date :"+objArr[x].date+" Status: "+objArr[x].status;

		            	var objArr2=JSON.parse(objArr[x].description);

		            	for(var y in objArr2)
		            	{
		            		var pDetails=document.createElement("p");
		            		var pMorning=document.createElement("p");
			            	var pAfternoon=document.createElement("p");
			            	var pNight=document.createElement("p");

			            	pDetails.innerHTML="Details: "+objArr2[y].description+" "+"Timing :"+objArr2[y].morning+" "+objArr2[y].afternoon+" "+objArr2[y].night;
			        

		            		divDetails.appendChild(pDetails);
		            		divDetails.appendChild(pMorning);
		            		divDetails.appendChild(pAfternoon);
		            		divDetails.appendChild(pNight);
		            	}




		            	td.appendChild(pSentBy);
		            	td.appendChild(divDetails);
		            	tr.appendChild(td);
	            		// var objArr=JSON.parse(this.responseText);
	            	 	document.getElementById("list").appendChild(tr);
	            	 }











					 loadPrescriptionNotification(objArr);
	            }
	        };
	        xmlhttp.open("GET","../../request/userProfileRequest?task=5&key="+key+"&value="+value, true);
	        xmlhttp.send();

		}
		function loadPrescriptionNotification(objArr)
		{
			var count=0;
			for(var x in objArr)
			{

				if(objArr[0].isSeenUser=="0")
				{
					count=count+1;
					
				}
			}
			if(count>0)document.getElementById("Prescription").innerHTML="Prescription"+count;
			else
			{

				document.getElementById("Prescription").innerHTML="Prescription";
			}
			

		}
		function SearchContact()
		{

		}
		function gotoProfile()
		{
			window.location.href="userDashboard.php";
		}
		function gotoChangeProfile()
		{
			window.location.href="userChangeProfile.php";
		}
		function gotoUserDoctor()
		{
			window.location.href="userDoctor.php";
		}
		function gotoUserAppoinment()
		{
			window.location.href="userAppointment.php";
		}
		function gotoUserContact()
		{
			window.location.href="userContact.php";
		}
		function gotoUserPrescription()
		{
			window.location.href="userPrescription.php";
		}
		function gotoUserChatBox(docUname)
		{
			window.location.href="userCHatBox.php?docUname="+docUname;
		}
		function gotoLogout()
		{
			window.location.href="../logout.php";
		}
		/*.................................................................*/
	</script>
</head>
<body onload="includeProfile()">
	<table >
		<tbody>
			<tr>
				<td>
					<table>
						<tbody>
							<tr>
								<td>
									<div onclick="gotoProfile()">
										<img src="" id="profilePic">
										<p id="userName"></p>
										
									</div>
								</td>
							</tr>

							<tr>
								<td>
									<input type="text" name="" placeholder="Search" onkeyup="SearchContact()">
								</td>
							</tr>
							<tr>
								<td>
									<p>Contact List</p>
									<ul id="contactList">
										
									</ul>
								</td>
							</tr>
							<tr>
								<td>
									<ul>
										<li onclick="gotoUserDoctor()">Doctor</li>
										<li onclick="gotoUserAppoinment()" id="Appointment">Appoinment</li>
										<li onclick="gotoUserContact()" id="Contact">Contact</li>
										<li onclick="gotoUserPrescription()" id="Prescription">Prescription</li>
										<li onclick="gotoLogout()">Logout</li>
									</ul>
								</td>
							</tr>
						</tbody>
					</table>
				</td>
				<td>
					<table id="list">
						
					</table>
				</td>
			</tr>
		</tbody>
	</table>
</body>
</html>