<?php
	define('APP_ROOT', "$_SERVER[DOCUMENT_ROOT]/V.DocTest");
	$Root=APP_ROOT;
	require_once(APP_ROOT."/core/core_service.php");
?>
<?php 
	if(isset($_REQUEST['task']))
	{
		if($_REQUEST['task']==1)
		{
			showUserByKeyValue($_REQUEST['key'],$_REQUEST['value']);
		}
		if($_REQUEST['task']==2)
		{
			getDoctorInformation();
		}
		if($_REQUEST['task']==3)
		{
			getDoctorUsingKeys();
		}
	}
	function showUserByKeyValue($key,$value)
	{
		echo getAllUserUsingLike($key,$value);
	}
	function getDoctorInformation()
	{
		echo getDoctorDetails();
	} 
	function getDoctorUsingKeys()
	{
		echo getDoctorListUsingDoubleKey($_REQUEST['key'],$_REQUEST['value'],$_REQUEST['key2'],$_REQUEST['value2']);
	}
	
 ?>