<?php
	define('APP_ROOT', "$_SERVER[DOCUMENT_ROOT]/V.DocTest");
	$Root=APP_ROOT;
	require_once(APP_ROOT."/core/core_service.php");
	session_start();
?>
<?php
	if($_SERVER['REQUEST_METHOD']=="POST")
	{
		$isValid = true;
		if(md5($_POST['opass'])==$_SESSION['password'])
		{
			if (validatePassword($_POST['pass'],$_POST['cpass']))$pass = md5($_POST['pass']);
			else
			{
				$isValid = false;
			}
			if($isValid)
			{
				if(updateUserPassword($pass,$_SESSION['uname']))
				{
					echo "password change";	
				}
				else
				{
					echo "failed to change password";
				}
			}
		}
		else
		{
			echo "Password incorrect";
		}
	}	
?>