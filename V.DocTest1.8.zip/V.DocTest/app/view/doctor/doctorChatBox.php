<?php 
session_start();

?>
<!DOCTYPE html>
<html>
<head>
	<title>User Dashboard</title>
	<script type="text/javascript">
		function includeProfile()
		{
			var key = "uname";
			var value = "<?php echo $_SESSION['uname']?>";
			var task="1";
			var xmlhttp = new XMLHttpRequest();
		
	        xmlhttp.onreadystatechange = function()
	        {
	            if (this.readyState == 4 && this.status == 200)
	            {
	                var objArr=	JSON.parse(this.responseText);
	     			document.getElementById("userName").innerHTML=objArr[0].fname+" "+objArr[0].lname;
					loadContactList();
					showSelectedUser("<?php echo $_REQUEST['uname']; ?>");
					loadMessageToChatContainer();
	            }
	        };
	        xmlhttp.open("GET","../../request/userProfileRequest?task=1&value="+value+"&key="+key, false);
	        xmlhttp.send();
		}
		function showSelectedUser(uname)
		{
			var key = "uname";
			var xmlhttp = new XMLHttpRequest();

	        xmlhttp.onreadystatechange = function()
	        {
	            if (this.readyState == 4 && this.status == 200)
	            {
	            	var objArr=JSON.parse(this.responseText);
	            	document.getElementById("selectedUser").innerHTML=objArr[0].fname+" "+objArr[0].lname;
	            }
	        };
	        xmlhttp.open("GET","../../request/userProfileRequest?task=3&key="+key+"&value="+uname, true);
	        xmlhttp.send();
		}
		function loadContactList()
		{
			var key = "uname";
			var key2 = "status";
			var value = "<?php echo $_SESSION['uname']?>";
			var value2="accept";
			var task="1";
			var xmlhttp = new XMLHttpRequest();

	        xmlhttp.onreadystatechange = function()
	        {
	            if (this.readyState == 4 && this.status == 200)
	            {
	            	 var objArr=JSON.parse(this.responseText);
	            	 document.getElementById("contactList").innerHTML="";
	            	 for(var x in objArr)
	            	 {
	            	 	loadSelectedUserInformation(objArr[x].docname);	            	 	
	            	 }
					
	            }
	        };
	        xmlhttp.open("GET","../../request/userProfileRequest?task=2&key="+key+"&key2="+key2+"&value="+value+"&value2="+value2, true);
	        xmlhttp.send();
		}
		function loadSelectedUserInformation(docname)
		{
			var key = "uname";
			var xmlhttp = new XMLHttpRequest();

	        xmlhttp.onreadystatechange = function()
	        {
	            if (this.readyState == 4 && this.status == 200)
	            {
	            	var objArr=JSON.parse(this.responseText);
	            	var li=document.createElement("li");
            	 	li.innerHTML=objArr[0].fname+" "+objArr[0].lname;
            	 	li.id=objArr[0].uname;
            	 	li.onclick=function(){gotoUserChatBox(this.id)};
            	 	document.getElementById("contactList").appendChild(li);
	            }
	        };
	        xmlhttp.open("GET","../../request/userProfileRequest?task=3&key="+key+"&value="+docname, true);
	        xmlhttp.send();
		}
		function sendChatMessage()
		{
			var sender = "<?php echo $_SESSION['uname']; ?>";
			var reciever = "<?php echo $_REQUEST['uname']; ?>";
			var message = document.getElementById("textBox").value;
			if(message!="")
			{
				document.getElementById("textBox").value="";
				var xmlhttp = new XMLHttpRequest();

		        xmlhttp.onreadystatechange = function()
		        {
		            if (this.readyState == 4 && this.status == 200)
		            {
		            	loadMessageToChatContainer();
		            }
		        };
		        xmlhttp.open("GET","../../request/doctorChatRequest?task=1&sender="+sender+"&reciever="+reciever+"&message="+message, true);
		        xmlhttp.send();
			}
			
		}
		function loadMessageToChatContainer()
		{
			var sender = "<?php echo $_SESSION['uname']; ?>";
			var reciever = "<?php echo $_REQUEST['uname']; ?>";

			var xmlhttp = new XMLHttpRequest();

	        xmlhttp.onreadystatechange = function()
	        {
	            if (this.readyState == 4 && this.status == 200)
	            {
	            	var objArr=JSON.parse(this.responseText);
	            	for(var x in objArr)
	            	{
	            		if(!seeIfTheMessageExist(objArr[x].id))
	            		{
	            			var p = document.createElement("p");
		            		p.innerHTML=objArr[x].message;
		            		p.id=objArr[x].id;
		            		document.getElementById("chatContainer").appendChild(p);
	            		}
	            	}
	            }
	        };
	        xmlhttp.open("GET","../../request/doctorChatRequest?task=2&sender="+sender+"&reciever="+reciever, true);
	        xmlhttp.send();
		}
		function seeIfTheMessageExist(id)
		{
			var isExist=false;
			var chat = document.getElementById(id);
			if (chat != null)
			{
				isExist=true;
			}
			return isExist;	    
		}
		function gotoProfile()
		{
			window.location.href="userDashboard.php";
		}
		function gotoChangeProfile()
		{
			window.location.href="userChangeProfile.php";
		}
		function gotoUserDoctor()
		{
			window.location.href="userDoctor.php";
		}
		function gotoUserAppoinment()
		{
			window.location.href="userAppointment.php";
		}
		function gotoUserPrescription()
		{
			window.location.href="userPrescription.php";
		}
		function gotoUserChatBox(docUname)
		{
			window.location.href="userCHatBox.php?docUname="+docUname;
		}
		function gotoLogout()
		{
			window.location.href="../logout.php";
		}
	</script>
</head>
<body onload="includeProfile()">
	<table border="1">
		<tbody>
			<tr>
				<td>
					<table>
						<tbody>
							<tr>
								<td>
									<div onclick="gotoProfile()">
										<img src="" id="profilePic">
										<p id="userName"></p>
										
									</div>
								</td>
							</tr>

							<tr>
								<td>
									<input type="text" name="" placeholder="Search">
								</td>
							</tr>
							<tr>
								<td>
									<p>Contact List</p>
									<ul id="contactList">
										
									</ul>
								</td>
							</tr>
							<tr>
								<td>
									<ul>
										<li onclick="gotoUserDoctor()">Doctor</li>
										<li onclick="gotoUserAppoinment()">Appoinment</li>
										<li onclick="gotoUserContact()">Contact</li>
										<li onclick="gotoUserPrescription()">Prescription</li>
										<li onclick="gotoLogout()">Logout</li>
									</ul>
								</td>
							</tr>
						</tbody>
					</table>
				</td>
				<td>
					<table>
							<tr>
								<td>
									<p id="selectedUser"></p>
								</td>
								<td>
									<input type="Button" name="" value="Report">
								</td>
								<td>
									
								</td>
							</tr>
							<tr>
								<td colspan="3">
									<div id="chatContainer">
										<p>Something</p>
										<p>Something</p>
										<p>Something</p>
										<p>Something</p>
										<p>Something</p>
										<p>Something</p>
										<p>Something</p>
										<p>Something</p>
										<p>Something</p>
										<p>Something</p>
										<p>Something</p>
									</div>
								</td>
							</tr>
							<tr>
								<td colspan="2">
									<input type="text" name="" placeholder="Enter your message here" id="textBox">
								</td>
								<td>
									<input type="button" name="" value="send" onclick="sendChatMessage()">
								</td>
							</tr>
						</table>
				</td>
			</tr>
		</tbody>
	</table>
</body>
</html>