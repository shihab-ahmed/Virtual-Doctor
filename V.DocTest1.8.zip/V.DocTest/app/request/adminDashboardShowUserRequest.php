<?php
	define('APP_ROOT', "$_SERVER[DOCUMENT_ROOT]/V.DocTest");
	$Root=APP_ROOT;
	require_once(APP_ROOT."/core/core_service.php");
	session_start();
?>
<?php
	
	if(isset($_REQUEST['task']))
	{
		if($_REQUEST['task']==1)
		{
			showUser();
		}
		else if($_REQUEST['task']==2)
		{

			showUserByKeyValue($_REQUEST['key'],$_REQUEST['value']);
		}
		else if($_REQUEST['task']==3)
		{

			DeleteSingleUser($_REQUEST['key'],$_REQUEST['value'],$_REQUEST['type'],$_REQUEST['pic']);
		}
	}

	function showUser()
	{
		echo getAllUser();
	}
	function showUserByKeyValue($key,$value)
	{
		//echo $key;
		echo getAllUserUsingLike($key,$value);
	}
	function DeleteSingleUser($key,$value,$type,$pic)
	{
		//echo $key." ".$value." ".$type;
		return DeleteUserByKeyValue($key,$value,$type,$pic);
	}
	
?>