<?php require_once("/data/data_access.php"); ?>
<?php
	function getUserByKeyValue($key,$value)
	{	
		return getUserByKeyValueFromDb($key,$value);
	}
	function GetNameTaken($key,$value)
	{
		return GetNameTakenFromDb($key,$value);
	}
	function addDoctor()
	{

	}
	function addAdmin()
	{
		
	}
	function addUser($fname,$lname,$uname,$email,$pass,$date,$gender,$file,$type,$previousYear)
	{
		return addUserToDb($fname,$lname,$uname,$email,$pass,$date,$gender,$file,$type,$previousYear);
	}
	function getAllUser()
	{

	}
?>