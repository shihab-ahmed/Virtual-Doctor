
<!DOCTYPE html>
<html>
<head>
	<title>User Dashboard</title>
		<script type="text/javascript">
			function loadProfileInformation()
			{
				//alert("something");
				
			}

			function includeProfile()
			{
				var key = "uname";
				var value = "<?php echo $_SESSION['uname']?>";
				var task="1";
				var xmlhttp = new XMLHttpRequest();
				var Root = "<?php echo APP_ROOT;?>";
				document.getElementById("panel").innerHTML="";
		        xmlhttp.onreadystatechange = function()
		        {
		            if (this.readyState == 4 && this.status == 200)
		            {
		                var objArr=	JSON.parse(this.responseText);

		                var pName= document.createElement("p");
		                var pEmail= document.createElement("p");
		                var pBirthdate= document.createElement("p");
		                var pGender= document.createElement("p");
		                var pAge= document.createElement("p");
		                
		                pName.innerHTML=objArr[0].fname+" "+objArr[0].lname;
		                pEmail.innerHTML=objArr[0].email;
		                pBirthdate.innerHTML=objArr[0].birthdate;
		                pAge.innerHTML=objArr[0].age;
		                pGender.innerHTML=objArr[0].gender;
						
						var panel = document.getElementById("panel");
						panel.appendChild(pName);
						panel.appendChild(pEmail);
						panel.appendChild(pBirthdate);
						panel.appendChild(pAge);
						panel.appendChild(pGender);

		            }
		        };
		        xmlhttp.open("GET","app/controller/admin_panel_controller.php?root="+Root+"&task="+task+"&key="+key+"&value="+value, false);
		        xmlhttp.send();
			}
			function includeAddDoctor()
			{
				var task="2";
				var xmlhttp = new XMLHttpRequest();
				var Root = "<?php echo APP_ROOT;?>";
				document.getElementById("panel").innerHTML="";
		        xmlhttp.onreadystatechange = function()
		        {
		            if (this.readyState == 4 && this.status == 200)
		            {
		               document.getElementById("panel").innerHTML=this.responseText;
		            }
		        };
		        xmlhttp.open("GET","app/controller/admin_panel_controller.php?root="+Root+"&task="+task, false);
		        xmlhttp.send();
			}
			function includeUserTable(key,value)
			{
				var xmlhttp = new XMLHttpRequest();
				var Root = "<?php echo APP_ROOT;?>";
				document.getElementById("list").innerHTML="";
		        xmlhttp.onreadystatechange = function()
		        {
		            if (this.readyState == 4 && this.status == 200)
		            {

		                var objArr=	JSON.parse(this.responseText);
		               
				        for(var x in objArr)
						{

							var tr = document.createElement("tr");

							var tdPicture = document.createElement("td");
							var tdName = document.createElement("td");
							var tdEmail = document.createElement("td");
							var tdBirthDate = document.createElement("td");
							var tdGender = document.createElement("td");
							var tdAge = document.createElement("td");
							var tdType = document.createElement("td");
							var tdDel = document.createElement("td");


							var btn = document.createElement("input"); 
							btn.type="button";
							btn.value="delete";
							btn.id=objArr[x].uname;
							btn.name=objArr[x].type;
							btn.onclick = function(){DeleteUser(this.id,this.name)};  
							
							var pic = document.createElement("img");
							pic.src=objArr[x].picture;
							pic.id="Pic";

							tdPicture.appendChild(pic);
							tdName.innerHTML= objArr[x].fname+" "+objArr[x].lname;
							tdEmail.innerHTML= objArr[x].email;
							tdBirthDate.innerHTML= objArr[x].birthdate;
							tdGender.innerHTML= objArr[x].gender;
							tdAge.innerHTML= objArr[x].age;
							tdType.innerHTML= objArr[x].type;							
							tdDel.appendChild(btn);

							tr.appendChild(tdPicture);
							tr.appendChild(tdName);
							tr.appendChild(tdEmail);
							tr.appendChild(tdBirthDate);
							tr.appendChild(tdGender);
							tr.appendChild(tdAge);
							tr.appendChild(tdType);
							tr.appendChild(tdDel);

							document.getElementById("list").appendChild(tr);
						}     
		            }
		        };
		        if(value.trim()=="")
		        {
		        	var task="4";
		        	xmlhttp.open("GET","app/controller/admin_panel_controller.php?root="+Root+"&task="+task, true);
		        }
		       	else
		       	{
		       		var task="5";
		       		xmlhttp.open("GET","app/controller/admin_panel_controller.php?root="+Root+"&task="+task+"&key="+key+"&value="+value, true);
		       	}
		        xmlhttp.send();
			}
			function includeShowUser()
			{
				document.getElementById("panel").innerHTML="";

				var textInput = document.createElement("input");
				textInput.type="text";
				textInput.placeholder="search";
				textInput.id="value";
				textInput.onkeydown=function(){search();}
				/*.............................................*/
				var SelectElement = document.createElement("select");
				SelectElement.id="key";

				var option1 = document.createElement("option");
				option1.value="type";
				option1.innerHTML="Type";

				var option2 = document.createElement("option");
				option2.value="fname";
				option2.innerHTML="First name";

				var option3 = document.createElement("option");
				option3.value="gender";
				option3.innerHTML="Gender";

				SelectElement.appendChild(option1);
				SelectElement.appendChild(option2);
				SelectElement.appendChild(option3);
				/*.............................................*/

				var tableSearchBar = document.createElement("table");
				var trSearch = document.createElement("tr");
				var tdTextbox = document.createElement("td");
				var tdComboBox = document.createElement("td");

				tdTextbox.appendChild(textInput);
				tdComboBox.appendChild(SelectElement);

				trSearch.appendChild(tdTextbox);
				trSearch.appendChild(tdComboBox);

				tableSearchBar.appendChild(trSearch);

				document.getElementById("panel").appendChild(tableSearchBar);

				var tableList = document.createElement("table");
				tableList.id="list";
				document.getElementById("panel").appendChild(tableList);

				includeUserTable("","");
			}
			function search()
			{
				var value=document.getElementById("value").value;
				var key=document.getElementById("key").value;
				includeUserTable(key,value);
			}
			function includeAddAdmin()
			{
				var task="3";
				var xmlhttp = new XMLHttpRequest();
				var Root = "<?php echo APP_ROOT;?>";
				document.getElementById("panel").innerHTML="";
		        xmlhttp.onreadystatechange = function()
		        {
		            if (this.readyState == 4 && this.status == 200)
		            {
		               document.getElementById("panel").innerHTML=this.responseText;
		            }
		        };
		        xmlhttp.open("GET","app/controller/admin_panel_controller.php?root="+Root+"&task="+task, false);
		        xmlhttp.send();
			}
			function includeReport()
			{
				alert("report");
			}
			function requestToAddAdmin()
			{
				
				var fname=document.getElementById("fname").value;
				var lname=document.getElementById("lname").value;
				var uname=document.getElementById("uname").value;
				var email=document.getElementById("email").value;
				var date=document.getElementById("date").value;
				var radios = document.getElementsByName('gender');
				var gender="";
				for (var i = 0, length = radios.length; i < length; i++) 
				{
				    if (radios[i].checked) 
				    {
				        gender=(radios[i].value);
				        break;
				    }
				}
				var pass=document.getElementById("pass").value;
				var cpass=document.getElementById("cpass").value;
				var fileToUpload = document.getElementById("fileToUpload");
				var file = fileToUpload.files[0];

				if(file!=null)
				{
					var fileName=file.name;
					var fileSize=file.size;
				}
				else
				{
					fileName="";
					fileSize="";
				}
				var extension = fileName.split('.').pop();
				var name = fileName.split('.')[0];

				

				var task="6";
				var xmlhttp = new XMLHttpRequest();
				var Root = "<?php echo APP_ROOT;?>";
				//document.getElementById("panel").innerHTML="";
		        xmlhttp.onreadystatechange = function()
		        {
		            if (this.readyState == 4 && this.status == 200)
		            {
		              document.getElementById("panel").innerHTML=this.responseText;
		            }
		        };
		        xmlhttp.open("GET","app/controller/admin_panel_controller.php?root="+Root+"&task="+task+"&fname="+fname+"&lname="+lname+"&uname="+uname+"&email="+email+"&date="+date+"&gender="+gender+"&pass="+pass+"&cpass="+cpass+"&fileName="+fileName+"&fileSize="+fileSize, false);
		        xmlhttp.send();

			}
		</script>
		<style type="text/css">
			#profilePic{
				width: 70px;
				height:70px;
				border-radius: 50%
			}
		</style>
</head>
<body onload="includeProfile()">
	<table border="1">
		<tbody>
			<tr>
				<td>
					<table>
						<tbody>
							<tr>
								<td>
									<div onclick="includeProfile()">
										<img src="" id="profilePic">
										<p id="userName"></p>
										<script>
										document.getElementById("userName").innerHTML="<?php echo $_SESSION['fname']." ".$_SESSION['lname']?>";
										document.getElementById("profilePic").src="<?php echo $_SESSION['picture']?>";
										</script>
									</div>
								</td>
							</tr>

							<tr>
								<td>
									<ul>
										<li onclick="includeAddDoctor()">Add Doctor</li>
										<li onclick="includeAddAdmin()">Add Admin</li>
										<li onclick="includeShowUser()">Show User</li>
										<li onclick="includeReport()">Report</li>
										<li >Logout</li>
									</ul>
								</td>
							</tr>
						</tbody>
					</table>
				</td>
				<td id="panel">					
				</td>
			</tr>
		</tbody>
	</table>
</body>
</html>
