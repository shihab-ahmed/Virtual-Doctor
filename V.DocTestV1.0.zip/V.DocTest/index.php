<?php
	define('APP_ROOT', "$_SERVER[DOCUMENT_ROOT]/V.DocTest");
	$Root=APP_ROOT;

	require_once(APP_ROOT."/core/core_service.php");
	if(isset($_REQUEST['js']))
	{
		if(isset($_REQUEST['request']))
		{	
			if(($_REQUEST['request'])=="nameTaken")
			{	
				if(GetNameTaken("uname",$_REQUEST['uname']))
				{
					echo "Name Taken";
				}
				else
				{
					echo "";
				}
				
			}
			
		}
	}
	if(isset($_GET['controller'])&& !isset($_REQUEST['js']))
	{
		$key=$_GET['controller'];
		ChangeController($key);	
	}
	else if(!isset($_GET['controller'])&& !isset($_REQUEST['js']))
	{
		ChangeController("");
	}
	function ChangeController($Controller)
	{
		switch($Controller)
		{
			case "admin":

				break;
				
			case "user":
				echo "user";
				break;
				
			case "register":
				include_once("/app/view/reg.php");
				break;

			default:
				include_once("/app/view/login.php");
				
				break;
		}
	}
	

?>