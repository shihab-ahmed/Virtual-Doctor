﻿<?php require_once("/lib/data_access_helper.php");?>

<?php
	function getUserByKeyValueFromDb($key,$value)
	{	
		$query = "SELECT `id`, `fname`, `lname`, `uname`, `email`, `password`, `birthdate`, `gender`, `age`, `picture`, `type` FROM `user` WHERE $key='$value'";  
		$result = executeQuery($query);	
		$user = null;
		if($result){

			$user = mysqli_fetch_assoc($result);
		}
		return $user;
	}
	function addUserToDb($fname,$lname,$uname,$email,$pass,$date,$gender,$file,$type,$previousYear)
	{
		$currentYear = date("Y");
	 	$age = $currentYear - $previousYear;	 	   
		$query="INSERT INTO user(fname,lname,uname,email,password,birthdate,gender,age,picture,type) VALUES ('$fname','$lname','$uname','$email','$pass','$date','$gender','$age','$file','$type')";
 		$result = executeQuery($query);	
 		return $result;
 	}
	function GetNameTakenFromDb($key,$value)
 	{
 	
 		$query = "SELECT `id`, `fname`, `lname`, `uname`, `email`, `password`, `birthdate`, `gender`, `age`, `picture`, `type` FROM `user` WHERE $key='$value'";  
		$result = executeQuery($query);	
 	    if ($result->num_rows > 0) 
		{
			return true;
		}
		else
		{
			return false;
		}
 	}
?>