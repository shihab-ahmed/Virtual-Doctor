<?php 
	session_start();
	var_dump($GLOBALS);
?>
<?php
	if($_SERVER['REQUEST_METHOD']=="POST")
	{
		$isValid = true;
		echo $_POST['date'];
		if (validateFirstName(test_input($_POST['fname'])))$fname = test_input($_POST['fname']);
		else
		{
			$isValid = false;
		}
		if (validateLastName(test_input($_POST['lname'])))$lname = test_input($_POST['lname']);
		else
		{
			$isValid = false;
		}
		if (validateUserName($_POST['uname']) && !GetNameTaken("uname",$_POST['uname']))$uname = test_input($_POST['uname']);
		else
		{
			$isValid = false;
		}
		if (validateEmail($_POST['email']))$email = test_input($_POST['email']);
		else
		{
			$isValid = false;
		}
		if (validateDate($_POST['date']))$date = test_input($_POST['date']);
		else
		{
			$isValid = false;
		}
		if (validateGender())$gender = test_input($_POST['gender']);
		else
		{
			$isValid = false;
		}
		if (validatePassword($_POST['pass'],$_POST['cpass']))$pass = md5(test_input($_POST['pass']));
		else
		{
			$isValid = false;
		}
		if (validateImage())$file = $_POST['target_file'];
		else
		{
			$isValid = false;
		}
		$type = "user";
		if($isValid)
		{
			
			if(addUser($fname,$lname,$uname,$email,$pass,$date,$gender,$file,$type,$_POST['previousYear']))
			{
			  if(move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $file)) 
			    {
			        //echo "your account has been created";
			        $_POST['success']="1";

			    }
			    else
			    {
			        //echo "Sorry, there was an error uploading your file.";
			    }
				
			}
			else
			{
				//echo "Account creation failed";
			}
		}
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Registration</title>
	<script type="text/javascript">
		function validateUser()
		{
			var isValid=true;
			var fname=document.getElementById("fname").value;
			if(fname=="")
			{
				isValid=false;
				var abbr = document.createElement("abbr");
				abbr.title="only alphabet[a-z]"
				abbr.innerHTML="*";
				document.getElementById("fnameWarning").innerHTML="";
				document.getElementById("fnameWarning").appendChild(abbr);
			}
			else
			{
				for (var i = 0; i < fname.length; i++) 
				{
					if( fname.charAt(i).charCodeAt(0)<65 || fname.charAt(i).charCodeAt(0)>122)
					{
						isValid=false;
						var abbr = document.createElement("abbr");
						abbr.title="only alphabet[a-z]"
						abbr.innerHTML="*";
						document.getElementById("fnameWarning").innerHTML="";
						document.getElementById("fnameWarning").appendChild(abbr);
						break;
					}
				}
			}

			if(isValid)
			{
				document.getElementById("fnameWarning").innerHTML="";
			}
			var lname=document.getElementById("lname").value;
			if(lname=="")
			{
				isValid=false;
				var abbr = document.createElement("abbr");
				abbr.title="only alphabet[a-z]"
				abbr.innerHTML="*";
				document.getElementById("lnameWarning").innerHTML="";
				document.getElementById("lnameWarning").appendChild(abbr);
			}
			else
			{
				for (var i = 0; i < lname.length; i++) 
				{
					if( lname.charAt(i).charCodeAt(0)<65 || lname.charAt(i).charCodeAt(0)>122)
					{
						isValid=false;
						var abbr = document.createElement("abbr");
						abbr.title="only alphabet[a-z]"
						abbr.innerHTML="*";
						document.getElementById("lnameWarning").innerHTML="";
						document.getElementById("lnameWarning").appendChild(abbr);
						break;
					}
				}
			}

			if(isValid)
			{
				document.getElementById("lnameWarning").innerHTML="";
			}
			var uname=document.getElementById("uname").value;
			if(uname=="")
			{
				isValid=false;
				var abbr = document.createElement("abbr");
				abbr.title="First letter alphabet[a-z] and Unique name"
				abbr.innerHTML="*";
				document.getElementById("unameWarning").innerHTML="";
				document.getElementById("unameWarning").appendChild(abbr);
			}
			else
			{
				if( uname.charAt(0).charCodeAt(0)<65 || uname.charAt(0).charCodeAt(0)>122)
				{
					isValid=false;
					var abbr = document.createElement("abbr");
					abbr.title="only alphabet[a-z]"
					abbr.innerHTML="*";
					document.getElementById("unameWarning").innerHTML="";
					document.getElementById("unameWarning").appendChild(abbr);
					
				}
			}
			if(isValid)
			{
				document.getElementById("unameWarning").innerHTML="";
			}
			var email=document.getElementById("email").value;
			if(email=="")
			{
				isValid=false;
				var abbr = document.createElement("abbr");
				abbr.title="ex@something.com"
				abbr.innerHTML="*";
				document.getElementById("emailWarning").innerHTML="";
				document.getElementById("emailWarning").appendChild(abbr);
			}
			if(isValid)
			{
				document.getElementById("emailWarning").innerHTML="";
			}
			var date=document.getElementById("date").value;
			if(date=="")
			{
				isValid=false;
				var abbr = document.createElement("abbr");
				abbr.title="required"
				abbr.innerHTML="*";
				document.getElementById("dateWarning").innerHTML="";
				document.getElementById("dateWarning").appendChild(abbr);
			}
			if(isValid)
			{
				document.getElementById("dateWarning").innerHTML="";
			}
			var radios = document.getElementsByName('gender');
			var gender="";
			for (var i = 0, length = radios.length; i < length; i++) 
			{
			    if (radios[i].checked) 
			    {
			        gender=(radios[i].value);
			        break;
			    }
			}
			if(gender=="")
			{
				isValid=false;
				var abbr = document.createElement("abbr");
				abbr.title="required"
				abbr.innerHTML="*";
				document.getElementById("genderWarning").innerHTML="";
				document.getElementById("genderWarning").appendChild(abbr);
			}
			if(isValid)
			{
				document.getElementById("genderWarning").innerHTML="";
			}
			var pass=document.getElementById("pass").value;
			if(pass=="")
			{
				isValid=false;
				var abbr = document.createElement("abbr");
				abbr.title="required(<10 word)"
				abbr.innerHTML="*";
				document.getElementById("passWarning").innerHTML="";
				document.getElementById("passWarning").appendChild(abbr);
			}
			if(isValid)
			{
				document.getElementById("passWarning").innerHTML="";
			}
			var cpass=document.getElementById("cpass").value;
			if(cpass=="")
			{
				isValid=false;
				var abbr = document.createElement("abbr");
				abbr.title="required(<10 word)"
				abbr.innerHTML="*";
				document.getElementById("cpassWarning").innerHTML="";
				document.getElementById("cpassWarning").appendChild(abbr);
			}
			if(isValid)
			{
				document.getElementById("cpassWarning").innerHTML="";
			}
			var fileToUpload = document.getElementById("fileToUpload");
			var file = fileToUpload.files[0];

			if(file!=null)
			{
				var fileName=file.name;
				var fileSize=file.size;
			}
			else
			{
				isValid=false;
				var abbr = document.createElement("abbr");
				abbr.title="only alphabet[a-z]"
				abbr.innerHTML="*";
				document.getElementById("fileWarning").innerHTML="";
				document.getElementById("fileWarning").appendChild(abbr);
			}
			if(isValid)
			{
				document.getElementById("fileWarning").innerHTML="";
				if(cpass!=pass)
				{
					isValid=false;
					document.getElementById("status").innerHTML="";
					document.getElementById("status").innerHTML="Confirm pass doesnt match";
				}
			}
			if(isValid)
			{
				var form=document.getElementById("form");
				document.getElementById("status").innerHTML="";
				document.getElementById("status").innerHTML="Account Created";
				form.submit();
			}

		}
		function validate()
		{

		}
		function SeeIfNameTaken()
		{
			var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function()
	        {
	            if (this.readyState == 4 && this.status == 200)
	            {
	                var objArr=	(this.responseText);
	                document.getElementById("unameWarning").innerHTML=objArr;
	          
	            }
	        };
	        var uname=document.getElementById("uname").value;
	        xmlhttp.open("GET","?js&request=nameTaken&uname="+uname, true);
	        xmlhttp.send();
		}
	</script>
</head>
<body>
	<form method="post"  enctype="multipart/form-data" id="form">
		<fieldset>
			<legend><h2>Registration</h2></legend>
			<table>
				<tbody>
					<tr>
						<td>
							First Name :
						</td>
						<td>
							<input type="text" name="fname" id="fname">
						</td>
						<td id="fnameWarning">
							
						</td>
					</tr>
					<tr>
						<td>
							Last Name :
						</td>
						<td>
							<input type="text" name="lname" id="lname">
						</td>
						<td id="lnameWarning">
							
						</td>
					</tr>
					<tr>
						<td>
							User Name :
						</td>
						<td>
							<input type="text" name="uname" id="uname" onkeyup="SeeIfNameTaken()">
						</td>
						<td id="unameWarning">
							
						</td>
					</tr>
					<tr>
						<td>
							Email :
						</td>
						<td>
							<input type="Email" name="email" id="email">
						</td>
						<td id="emailWarning">
							
						</td>
					</tr>
					<tr>
						<td>
							Date(yyyy-mm-dd) :
						</td>
						<td>
							<input type="date" name="date" id="date">
						</td>
						<td id="dateWarning">
							
						</td>
					</tr>
					<tr>
						<td>
							Gender :
						</td>
						<td>
							<input type="radio" name="gender" value="male"> Male
							<input type="radio" name="gender" value="female">Female
						</td>
						<td id="genderWarning">
							
						</td>
					</tr>
					<tr>
						<td>
							Password :
						</td>
						<td>
							<input type="Password" name="pass" id="pass">
						</td>
						<td id="passWarning">
							
						</td>
					</tr>
					<tr>
						<td>
							Confirm Password :
						</td>
						<td>
							<input type="Password" name="cpass" id="cpass">
						</td>
						<td id="cpassWarning">
							
						</td>
					</tr>
					<tr>
						<td>
							Profile Picture :
						</td>
						<td>
							 <input type="file" name="fileToUpload" id="fileToUpload">
						</td>
						<td id="fileWarning">
							
						</td>
					</tr>
					<tr>
						<td>
							
						</td>
						<td >
							<input type="button" value="Sign Up" onclick="validateUser()" />
							<a href="?controller=">Sign In</a> 
						</td>
					</tr>
					<tr>
						<td>
							
						</td>
						<td id="status">
							<?php  if(isset( $_POST['success'])) { ?>
							
						    Account created    
						     <?php  }  ?>	  
						       
						</td>
					</tr>
				</tbody>
			</table>
		</fieldset>
	</form>	
</body>
</html>