<?php require_once("/data/data_access.php"); ?>
<?php
	function getUserByKeyValue($key,$value)
	{	
		return getUserByKeyValueFromDb($key,$value);
	}
	function getUserByKeyValueJSON($key,$value)
	{	 
		$result= getUserByKeyValueJSONFromDb($key,$value);
		
		$rows = array();
		while($r = mysqli_fetch_assoc($result))
		{
    	  $rows[] = $r;
        }
		return json_encode($rows);
	}
	function getAllUserUsingLike($key,$value)
	{	 
		$result= getUserByKeyValueUsingLikeFromDb($key,$value);
		//echo $key;
		$rows = array();
		while($r = mysqli_fetch_assoc($result))
		{
    	  $rows[] = $r;
        }
		return json_encode($rows);
	}
	 
	function DeleteUserByKeyValue($key,$value,$type,$pic)
	{
		return DeleteUserByKeyValueFromDb($key,$value,$type,$pic);
	}
	function GetNameTaken($key,$value)
	{
		return GetNameTakenFromDb($key,$value);
	}
	function addUser($fname,$lname,$uname,$email,$pass,$date,$gender,$file,$type,$previousYear)
	{
		return addUserToDb($fname,$lname,$uname,$email,$pass,$date,$gender,$file,$type,$previousYear);
	}
	function addDoctor($fname,$lname,$uname,$email,$pass,$date,$gender,$file,$type,$previousYear,$category,$experience,$about)
	{
		return addDoctorToDb($fname,$lname,$uname,$email,$pass,$date,$gender,$file,$type,$previousYear,$category,$experience,$about);
	}
	
	function getAllUser()
	{
		$result=getAllUserFromDb();
		$rows = array();
		while($r = mysqli_fetch_assoc($result))
		{
    	  $rows[] = $r;
        }
		return json_encode($rows);
	}
?>